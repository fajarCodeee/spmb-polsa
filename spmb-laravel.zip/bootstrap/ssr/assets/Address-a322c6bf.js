import { unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$3 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$1 } from "./InputLabel-5e383564.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$4 } from "./TextInput-f08fe8c3.js";
import "./Combobox-8f85dcc2.js";
import { usePage, useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./TextareaInput-ea5736c3.js";
import { _ as _sfc_main$5 } from "./NumberInput-74774052.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Address",
  __ssrInlineRender: true,
  props: {
    mustVerifyEmail: {
      type: Boolean
    },
    status: {
      type: String
    }
  },
  setup(__props) {
    const form_data = usePage().props.form;
    const form = useForm({
      address: form_data.address || ``,
      city: form_data.city || ``,
      province: form_data.province || ``,
      subdistrict: form_data.subdistrict || ``,
      country: form_data.country || ``,
      postal_code: form_data.postal_code || ``,
      rt: form_data.rt || ``,
      rw: form_data.rw || ``,
      phone_number: form_data.phone_number || ``,
      phone_number_alt: form_data.phone_number_alt || ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(_attrs)}><header><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"> Alamat </h2><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"> Isi alamat sesuai dengan KTP anda. </p></header><form class="mt-6 space-y-6"><div class="grid grid-cols-2 gap-4"><div class="col-span-2">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "address",
        value: "Alamat"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "address",
        class: "mt-1 block w-full",
        type: "text",
        modelValue: unref(form).address,
        "onUpdate:modelValue": ($event) => unref(form).address = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.address
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "city",
        value: "Kota"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "city",
        class: "mt-1 block w-full",
        type: "text",
        modelValue: unref(form).city,
        "onUpdate:modelValue": ($event) => unref(form).city = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.city
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "province",
        value: "Provinsi"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "province",
        class: "mt-1 block w-full",
        type: "text",
        modelValue: unref(form).province,
        "onUpdate:modelValue": ($event) => unref(form).province = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.province
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "subdistrict",
        value: "Kecamatan"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "subdistrict",
        class: "mt-1 block w-full",
        type: "text",
        modelValue: unref(form).subdistrict,
        "onUpdate:modelValue": ($event) => unref(form).subdistrict = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.subdistrict
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "country",
        value: "Negara"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "country",
        class: "mt-1 block w-full",
        type: "text",
        modelValue: unref(form).country,
        "onUpdate:modelValue": ($event) => unref(form).country = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.country
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "postal_code",
        value: "Kode Pos"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$5, {
        id: "postal_code",
        class: "mt-1 block w-full",
        modelValue: unref(form).postal_code,
        "onUpdate:modelValue": ($event) => unref(form).postal_code = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.postal_code
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "rt",
        value: "RT"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "rt",
        class: "mt-1 block w-full",
        modelValue: unref(form).rt,
        "onUpdate:modelValue": ($event) => unref(form).rt = $event,
        placeholder: "000"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.rt
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "rw",
        value: "RW"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "rw",
        class: "mt-1 block w-full",
        modelValue: unref(form).rw,
        "onUpdate:modelValue": ($event) => unref(form).rw = $event,
        placeholder: "000"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.rw
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "phone_number",
        value: "Nomer Whatsapp Aktif"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "phone_number",
        class: "mt-1 block w-full",
        type: "text",
        modelValue: unref(form).phone_number,
        "onUpdate:modelValue": ($event) => unref(form).phone_number = $event,
        placeholder: "Cth: 08xxxxxxxx"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.phone_number
      }, null, _parent));
      _push(`</div></div><div class="flex justify-end gap-4">`);
      _push(ssrRenderComponent(PrimaryButton, {
        disabled: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Save`);
          } else {
            return [
              createTextVNode("Save")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></form></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Form/Partials/Address.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
