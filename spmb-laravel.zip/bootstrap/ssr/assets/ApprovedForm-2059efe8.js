import { withCtx, createVNode, createTextVNode, toDisplayString, unref, openBlock, createBlock, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { C as Container, _ as _sfc_main$1 } from "./Card-8fb49bd9.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { Link, useForm } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "ApprovedForm",
  __ssrInlineRender: true,
  props: {
    form: {
      default: null,
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(Container, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$1, {
              title: "Pendaftaran",
              description: `Data anda sudah di finalisasi pada pendaftaran tahun ajaran ${__props.form.wave.tahun_akademik}, silahkan melanjutkan ke tahap selanjutnya.`
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid grid-cols-3 gap-2"${_scopeId2}><div class="col-span-3 md:col-span-1 flex justify-center"${_scopeId2}><img${ssrRenderAttr("src", __props.form.foto)} alt="Foto" class="w-60 h-80 rounded-lg"${_scopeId2}></div><div class="col-span-3 md:col-span-2 flex flex-col gap-4"${_scopeId2}><div class="font-bold text-lg text-gray-500 dark:text-gray-300"${_scopeId2}> No Ujian : <span${_scopeId2}>${ssrInterpolate(__props.form.no_exam)}</span></div><div class="font-bold text-lg text-gray-500 dark:text-gray-300"${_scopeId2}><div class="font-bold text-lg text-gray-500 dark:text-gray-300"${_scopeId2}> Nama : <span${_scopeId2}>${ssrInterpolate(__props.form.name)}</span></div><div class="font-bold text-lg text-gray-500 dark:text-gray-300"${_scopeId2}> NISN : <span${_scopeId2}>${ssrInterpolate(__props.form.education_number)}</span></div></div><div class="font-bold text-lg text-gray-500 dark:text-gray-300"${_scopeId2}> Tempat, Tanggal Lahir : <span${_scopeId2}>${ssrInterpolate(__props.form.birth_place_city)}, ${ssrInterpolate(__props.form.birth_date)}</span></div><div class="font-bold text-lg text-gray-500 dark:text-gray-300"${_scopeId2}> Pilihan Program Studi : <span${_scopeId2}>${ssrInterpolate(__props.form.prodi)}</span></div><div class="font-bold text-lg text-gray-500 dark:text-gray-300"${_scopeId2}> Gelombang : <span${_scopeId2}>${ssrInterpolate(__props.form.wave.code)}</span></div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "grid grid-cols-3 gap-2" }, [
                      createVNode("div", { class: "col-span-3 md:col-span-1 flex justify-center" }, [
                        createVNode("img", {
                          src: __props.form.foto,
                          alt: "Foto",
                          class: "w-60 h-80 rounded-lg"
                        }, null, 8, ["src"])
                      ]),
                      createVNode("div", { class: "col-span-3 md:col-span-2 flex flex-col gap-4" }, [
                        createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                          createTextVNode(" No Ujian : "),
                          createVNode("span", null, toDisplayString(__props.form.no_exam), 1)
                        ]),
                        createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                          createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                            createTextVNode(" Nama : "),
                            createVNode("span", null, toDisplayString(__props.form.name), 1)
                          ]),
                          createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                            createTextVNode(" NISN : "),
                            createVNode("span", null, toDisplayString(__props.form.education_number), 1)
                          ])
                        ]),
                        createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                          createTextVNode(" Tempat, Tanggal Lahir : "),
                          createVNode("span", null, toDisplayString(__props.form.birth_place_city) + ", " + toDisplayString(__props.form.birth_date), 1)
                        ]),
                        createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                          createTextVNode(" Pilihan Program Studi : "),
                          createVNode("span", null, toDisplayString(__props.form.prodi), 1)
                        ]),
                        createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                          createTextVNode(" Gelombang : "),
                          createVNode("span", null, toDisplayString(__props.form.wave.code), 1)
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$1, {
              title: "Tahap Selanjutnya",
              description: "Silahkan melanjutkan ke tahap selanjutnya."
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<ol class="relative border-s border-gray-200 dark:border-gray-700"${_scopeId2}>`);
                  if (_ctx.$page.props.auth.exams.knowledge) {
                    _push3(`<li class="mb-10 ms-4"${_scopeId2}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId2}></div><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId2}> Tes Pengetahuan </h3><p class="mb-4 text-base font-normal text-gray-500 dark:text-gray-400"${_scopeId2}> Tes pengetahuan akan dilaksanakan secara online dengan waktu yang telah ditentukan. Silahkan melanjutkan ke menu `);
                    _push3(ssrRenderComponent(unref(Link), {
                      href: _ctx.route("exams.knowledge"),
                      class: "text-blue-600 hover:underline"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Tes Pengetahuan`);
                        } else {
                          return [
                            createTextVNode("Tes Pengetahuan")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`. </p></li>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  if (_ctx.$page.props.auth.exams.health) {
                    _push3(`<li class="mb-10 ms-4"${_scopeId2}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId2}></div><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId2}> Tes Kesehatan </h3><p class="text-base font-normal text-gray-500 dark:text-gray-400"${_scopeId2}> Tes kesehatan akan dilaksanakan secara online, isi semua form yang ada di menu `);
                    _push3(ssrRenderComponent(unref(Link), {
                      class: "text-blue-600 hover:underline",
                      href: _ctx.route("exams.health")
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Tes Kesehatan `);
                        } else {
                          return [
                            createTextVNode(" Tes Kesehatan ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`</p></li>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  if (_ctx.$page.props.auth.exams.interview) {
                    _push3(`<li class="mb-10 ms-4"${_scopeId2}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId2}></div><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId2}> Wawancara </h3><p class="text-base font-normal text-gray-500 dark:text-gray-800"${_scopeId2}> Wawancara akan dilaksanakan secara online, silahkan melanjutkan ke menu `);
                    _push3(ssrRenderComponent(unref(Link), {
                      class: "text-blue-600 hover:underline",
                      href: _ctx.route("exams.interview")
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`wawancara`);
                        } else {
                          return [
                            createTextVNode("wawancara")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`. </p></li>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`<li class="mb-10 ms-4"${_scopeId2}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId2}></div><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId2}> Akhir </h3><p class="text-base font-normal text-gray-500 dark:text-gray-800"${_scopeId2}> Jika sudah mengikuti semua tes, silahkan mengajukan pengumpulan formulir di tombol dibawah. </p></li></ol><div class="flex justify-end mt-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(PrimaryButton, {
                    onClick: ($event) => unref(useForm)({}).post(_ctx.route("form.submission.final"))
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` ajukan pengumpulan `);
                      } else {
                        return [
                          createTextVNode(" ajukan pengumpulan ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("ol", { class: "relative border-s border-gray-200 dark:border-gray-700" }, [
                      _ctx.$page.props.auth.exams.knowledge ? (openBlock(), createBlock("li", {
                        key: 0,
                        class: "mb-10 ms-4"
                      }, [
                        createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                        createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Tes Pengetahuan "),
                        createVNode("p", { class: "mb-4 text-base font-normal text-gray-500 dark:text-gray-400" }, [
                          createTextVNode(" Tes pengetahuan akan dilaksanakan secara online dengan waktu yang telah ditentukan. Silahkan melanjutkan ke menu "),
                          createVNode(unref(Link), {
                            href: _ctx.route("exams.knowledge"),
                            class: "text-blue-600 hover:underline"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Tes Pengetahuan")
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createTextVNode(". ")
                        ])
                      ])) : createCommentVNode("", true),
                      _ctx.$page.props.auth.exams.health ? (openBlock(), createBlock("li", {
                        key: 1,
                        class: "mb-10 ms-4"
                      }, [
                        createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                        createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Tes Kesehatan "),
                        createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-400" }, [
                          createTextVNode(" Tes kesehatan akan dilaksanakan secara online, isi semua form yang ada di menu "),
                          createVNode(unref(Link), {
                            class: "text-blue-600 hover:underline",
                            href: _ctx.route("exams.health")
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Tes Kesehatan ")
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ])
                      ])) : createCommentVNode("", true),
                      _ctx.$page.props.auth.exams.interview ? (openBlock(), createBlock("li", {
                        key: 2,
                        class: "mb-10 ms-4"
                      }, [
                        createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                        createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Wawancara "),
                        createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-800" }, [
                          createTextVNode(" Wawancara akan dilaksanakan secara online, silahkan melanjutkan ke menu "),
                          createVNode(unref(Link), {
                            class: "text-blue-600 hover:underline",
                            href: _ctx.route("exams.interview")
                          }, {
                            default: withCtx(() => [
                              createTextVNode("wawancara")
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createTextVNode(". ")
                        ])
                      ])) : createCommentVNode("", true),
                      createVNode("li", { class: "mb-10 ms-4" }, [
                        createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                        createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Akhir "),
                        createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-800" }, " Jika sudah mengikuti semua tes, silahkan mengajukan pengumpulan formulir di tombol dibawah. ")
                      ])
                    ]),
                    createVNode("div", { class: "flex justify-end mt-4" }, [
                      createVNode(PrimaryButton, {
                        onClick: ($event) => unref(useForm)({}).post(_ctx.route("form.submission.final"))
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" ajukan pengumpulan ")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$1, {
                title: "Pendaftaran",
                description: `Data anda sudah di finalisasi pada pendaftaran tahun ajaran ${__props.form.wave.tahun_akademik}, silahkan melanjutkan ke tahap selanjutnya.`
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "grid grid-cols-3 gap-2" }, [
                    createVNode("div", { class: "col-span-3 md:col-span-1 flex justify-center" }, [
                      createVNode("img", {
                        src: __props.form.foto,
                        alt: "Foto",
                        class: "w-60 h-80 rounded-lg"
                      }, null, 8, ["src"])
                    ]),
                    createVNode("div", { class: "col-span-3 md:col-span-2 flex flex-col gap-4" }, [
                      createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                        createTextVNode(" No Ujian : "),
                        createVNode("span", null, toDisplayString(__props.form.no_exam), 1)
                      ]),
                      createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                        createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                          createTextVNode(" Nama : "),
                          createVNode("span", null, toDisplayString(__props.form.name), 1)
                        ]),
                        createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                          createTextVNode(" NISN : "),
                          createVNode("span", null, toDisplayString(__props.form.education_number), 1)
                        ])
                      ]),
                      createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                        createTextVNode(" Tempat, Tanggal Lahir : "),
                        createVNode("span", null, toDisplayString(__props.form.birth_place_city) + ", " + toDisplayString(__props.form.birth_date), 1)
                      ]),
                      createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                        createTextVNode(" Pilihan Program Studi : "),
                        createVNode("span", null, toDisplayString(__props.form.prodi), 1)
                      ]),
                      createVNode("div", { class: "font-bold text-lg text-gray-500 dark:text-gray-300" }, [
                        createTextVNode(" Gelombang : "),
                        createVNode("span", null, toDisplayString(__props.form.wave.code), 1)
                      ])
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["description"]),
              createVNode(_sfc_main$1, {
                title: "Tahap Selanjutnya",
                description: "Silahkan melanjutkan ke tahap selanjutnya."
              }, {
                default: withCtx(() => [
                  createVNode("ol", { class: "relative border-s border-gray-200 dark:border-gray-700" }, [
                    _ctx.$page.props.auth.exams.knowledge ? (openBlock(), createBlock("li", {
                      key: 0,
                      class: "mb-10 ms-4"
                    }, [
                      createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                      createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Tes Pengetahuan "),
                      createVNode("p", { class: "mb-4 text-base font-normal text-gray-500 dark:text-gray-400" }, [
                        createTextVNode(" Tes pengetahuan akan dilaksanakan secara online dengan waktu yang telah ditentukan. Silahkan melanjutkan ke menu "),
                        createVNode(unref(Link), {
                          href: _ctx.route("exams.knowledge"),
                          class: "text-blue-600 hover:underline"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Tes Pengetahuan")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createTextVNode(". ")
                      ])
                    ])) : createCommentVNode("", true),
                    _ctx.$page.props.auth.exams.health ? (openBlock(), createBlock("li", {
                      key: 1,
                      class: "mb-10 ms-4"
                    }, [
                      createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                      createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Tes Kesehatan "),
                      createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-400" }, [
                        createTextVNode(" Tes kesehatan akan dilaksanakan secara online, isi semua form yang ada di menu "),
                        createVNode(unref(Link), {
                          class: "text-blue-600 hover:underline",
                          href: _ctx.route("exams.health")
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Tes Kesehatan ")
                          ]),
                          _: 1
                        }, 8, ["href"])
                      ])
                    ])) : createCommentVNode("", true),
                    _ctx.$page.props.auth.exams.interview ? (openBlock(), createBlock("li", {
                      key: 2,
                      class: "mb-10 ms-4"
                    }, [
                      createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                      createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Wawancara "),
                      createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-800" }, [
                        createTextVNode(" Wawancara akan dilaksanakan secara online, silahkan melanjutkan ke menu "),
                        createVNode(unref(Link), {
                          class: "text-blue-600 hover:underline",
                          href: _ctx.route("exams.interview")
                        }, {
                          default: withCtx(() => [
                            createTextVNode("wawancara")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createTextVNode(". ")
                      ])
                    ])) : createCommentVNode("", true),
                    createVNode("li", { class: "mb-10 ms-4" }, [
                      createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                      createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Akhir "),
                      createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-800" }, " Jika sudah mengikuti semua tes, silahkan mengajukan pengumpulan formulir di tombol dibawah. ")
                    ])
                  ]),
                  createVNode("div", { class: "flex justify-end mt-4" }, [
                    createVNode(PrimaryButton, {
                      onClick: ($event) => unref(useForm)({}).post(_ctx.route("form.submission.final"))
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" ajukan pengumpulan ")
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Submission/Partials/ApprovedForm.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
