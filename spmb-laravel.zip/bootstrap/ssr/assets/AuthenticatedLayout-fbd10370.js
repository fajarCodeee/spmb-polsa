import { ssrRenderComponent, ssrRenderClass, ssrRenderSlot, ssrRenderTeleport, ssrRenderList, ssrInterpolate, ssrRenderAttrs, ssrRenderStyle } from "vue/server-renderer";
import { computed, unref, mergeProps, withCtx, createVNode, createTextVNode, renderSlot, useSSRContext, ref, onMounted, watch, toDisplayString, openBlock, createBlock, createCommentVNode } from "vue";
import "./ApplicationLogo-9c97dc09.js";
import { _ as _sfc_main$a, a as _sfc_main$b } from "./ResponsiveNavLink-f6fd3af7.js";
import { Link, usePage } from "@inertiajs/vue3";
import { v4 } from "uuid";
import axios from "axios";
const _sfc_main$9 = {
  __name: "ResponsiveSideBar",
  __ssrInlineRender: true,
  props: {
    href: {
      type: String,
      required: true
    },
    active: {
      type: Boolean
    },
    icon: {
      type: String
    }
  },
  setup(__props) {
    const props = __props;
    const classes = computed(
      () => props.active ? "flex items-center p-2 text-gray-900 bg-gray-200 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group transition duration-150 ease-in-out" : "flex items-center p-2 text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group transition duration-150 ease-in-out"
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Link), mergeProps({
        href: __props.href,
        class: classes.value
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<i class="${ssrRenderClass(__props.icon)}"${_scopeId}></i> <span class="ms-3"${_scopeId}>`);
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
            _push2(`</span>`);
          } else {
            return [
              createVNode("i", { class: __props.icon }, null, 2),
              createTextVNode(),
              createVNode("span", { class: "ms-3" }, [
                renderSlot(_ctx.$slots, "default")
              ])
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/ResponsiveSideBar.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const alerts = ref([]);
function useAlerts() {
  const removeAlertTimeout = (id) => {
    setTimeout(() => {
      alerts.value = alerts.value.filter((alert) => alert.id !== id);
    }, 3e3);
  };
  const addAlert = (alert) => {
    const id = v4();
    alerts.value.push({
      id,
      ...alert
    });
    removeAlertTimeout(id);
    if (alerts.value.length > 5) {
      alerts.value = alerts.value.slice(1);
    }
  };
  const removeAlert = (id) => {
    alerts.value = alerts.value.filter((alert) => alert.id !== id);
  };
  return {
    alerts,
    addAlert,
    removeAlert
  };
}
const _sfc_main$8 = {
  __name: "AlertHandler",
  __ssrInlineRender: true,
  setup(__props) {
    const { addAlert, alerts: alerts2, removeAlert } = useAlerts();
    const alert = computed(() => usePage().props.flash.alert);
    onMounted(() => {
      if (alert.value) {
        addAlert(alert.value);
      }
    });
    watch(alert, (newVal) => {
      if (newVal) {
        addAlert(newVal);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      ssrRenderTeleport(_push, (_push2) => {
        if (unref(alerts2).length) {
          _push2(`<div class="fixed top-0 right-0 z-50 p-3 flex flex-col gap-3"><!--[-->`);
          ssrRenderList(unref(alerts2), (alert2) => {
            _push2(`<div class="${ssrRenderClass([{
              "bg-teal-100 border border-teal-200 text-teal-800 dark:bg-teal-800/10 dark:border-teal-900 dark:text-teal-500": alert2.type === "success",
              "bg-yellow-100 border border-yellow-200 text-yellow-800 dark:bg-yellow-800/10 dark:border-yellow-900 dark:text-yellow-500": alert2.type === "warning",
              "bg-red-100 border-red-200 text-red-800 dark:bg-red-800/10 dark:border-red-900 dark:text-red-500": alert2.type === "danger"
            }, "max-w-xs text-sm rounded-lg"])}" role="alert"><div class="flex p-4">${ssrInterpolate(alert2.message)} <div class="ms-auto"><button type="button" class="inline-flex flex-shrink-0 justify-center items-center h-5 w-5 rounded-lg text-yellow-800 opacity-50 hover:opacity-100 focus:outline-none focus:opacity-100 dark:text-yellow-200"><span class="sr-only">Close</span><i class="fas fa-times flex-shrink-0 w-4 h-4"></i></button></div></div></div>`);
          });
          _push2(`<!--]--></div>`);
        } else {
          _push2(`<!---->`);
        }
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/AlertHandler.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = {
  __name: "User",
  __ssrInlineRender: true,
  props: {
    check: {
      type: Boolean,
      required: true,
      default: true
    }
  },
  setup(__props) {
    const showingListForm = ref(
      route().current("form.edit") || route().current("documents.index") || false
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="mb-8"><header class="px-3 mb-4 text-xs font-semibold tracking-wider text-gray-500 uppercase dark:text-gray-400"> Menu </header><ul class="space-y-2 font-medium"><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        icon: "fa-solid fa-house",
        href: _ctx.route("dashboard"),
        active: _ctx.route().current("dashboard")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Dashboard `);
          } else {
            return [
              createTextVNode(" Dashboard ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li>`);
      if (__props.check) {
        _push(`<!--[--><li>`);
        _push(ssrRenderComponent(_sfc_main$9, {
          icon: "fa-solid fa-file-invoice",
          href: _ctx.route("form.submission"),
          active: _ctx.route().current("form.submission")
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Pendaftaran `);
            } else {
              return [
                createTextVNode(" Pendaftaran ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li>`);
        if (_ctx.$page.props.auth.form.is_paid_registration) {
          _push(`<li><button type="button" class="flex items-center w-full p-2 text-base text-gray-900 transition duration-75 rounded-lg group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"><i class="fa-solid fa-address-card"></i><span class="flex-1 ms-3 text-left rtl:text-right whitespace-nowrap capitalize">Data diri</span><i class="${ssrRenderClass([{
            "fa-chevron-up": showingListForm.value,
            "fa-chevron-down": !showingListForm.value
          }, "fa-solid"])}"></i></button><ul class="${ssrRenderClass([{
            block: showingListForm.value,
            hidden: !showingListForm.value
          }, "py-2 space-y-2"])}"><li>`);
          _push(ssrRenderComponent(_sfc_main$9, {
            href: _ctx.route("form.edit", {
              id: "personal"
            }),
            active: _ctx.route().current("form.edit", {
              id: "personal"
            }),
            class: "flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Personal`);
              } else {
                return [
                  createTextVNode("Personal")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</li><li>`);
          _push(ssrRenderComponent(_sfc_main$9, {
            href: _ctx.route("form.edit", {
              id: "address"
            }),
            active: _ctx.route().current("form.edit", {
              id: "address"
            }),
            class: "flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Alamat`);
              } else {
                return [
                  createTextVNode("Alamat")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</li><li>`);
          _push(ssrRenderComponent(_sfc_main$9, {
            href: _ctx.route("form.edit", {
              id: "disability"
            }),
            active: _ctx.route().current("form.edit", {
              id: "disability"
            }),
            class: "flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Disabilitas`);
              } else {
                return [
                  createTextVNode("Disabilitas")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</li><li>`);
          _push(ssrRenderComponent(_sfc_main$9, {
            href: _ctx.route("form.edit", {
              id: "education"
            }),
            active: _ctx.route().current("form.edit", {
              id: "education"
            }),
            class: "flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Pendidikan`);
              } else {
                return [
                  createTextVNode("Pendidikan")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</li><li>`);
          _push(ssrRenderComponent(_sfc_main$9, {
            href: _ctx.route("form.edit", {
              id: "parent"
            }),
            active: _ctx.route().current("form.edit", {
              id: "parent"
            }),
            class: "flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Orang tua / wali`);
              } else {
                return [
                  createTextVNode("Orang tua / wali")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</li><li>`);
          _push(ssrRenderComponent(_sfc_main$9, {
            href: _ctx.route("documents.index"),
            active: _ctx.route().current("documents.index"),
            class: "flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Dokumen`);
              } else {
                return [
                  createTextVNode("Dokumen")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</li></ul></li>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<li>`);
        _push(ssrRenderComponent(_sfc_main$9, {
          icon: "fa-solid fa-money-bill",
          href: _ctx.route("form.payment"),
          active: _ctx.route().current("form.payment")
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Pembayaran `);
            } else {
              return [
                createTextVNode(" Pembayaran ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li><!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</ul></div>`);
      if (_ctx.$page.props.auth.form.status == "approved") {
        _push(`<div class="mb-8"><header class="px-3 mb-4 text-xs font-semibold tracking-wider text-gray-500 uppercase dark:text-gray-400"> Ujian </header><ul class="pt-4 mt-4 space-y-2 font-medium border-t border-gray-200 dark:border-gray-700">`);
        if (_ctx.$page.props.auth.exams.knowledge) {
          _push(`<li>`);
          _push(ssrRenderComponent(_sfc_main$9, {
            href: _ctx.route("exams.knowledge"),
            active: _ctx.route().current("exams.knowledge"),
            icon: "fas fa-clipboard"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Ujian pengetahuan `);
              } else {
                return [
                  createTextVNode(" Ujian pengetahuan ")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</li>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.$page.props.auth.exams.health) {
          _push(`<li>`);
          _push(ssrRenderComponent(_sfc_main$9, {
            href: _ctx.route("exams.health"),
            active: _ctx.route().current("exams.health"),
            icon: "fas fa-stethoscope"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Pemeriksaan kesehatan `);
              } else {
                return [
                  createTextVNode(" Pemeriksaan kesehatan ")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</li>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.$page.props.auth.exams.interview) {
          _push(`<li>`);
          _push(ssrRenderComponent(_sfc_main$9, {
            href: _ctx.route("exams.interview"),
            active: _ctx.route().current("exams.interview"),
            icon: "fas fa-microphone"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Wawancara `);
              } else {
                return [
                  createTextVNode(" Wawancara ")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</li>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Partials/Menu/User.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "Panitia",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "mb-8" }, _attrs))}><header class="px-3 mb-4 text-xs font-semibold tracking-wider text-gray-500 uppercase dark:text-gray-400"> Panitia </header><ul class="pt-4 mt-4 space-y-2 font-medium border-t border-gray-200 dark:border-gray-700"><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.daftar_peserta"),
        active: _ctx.route().current("admin.daftar_peserta"),
        icon: "fa-solid fa-users"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Daftar Peserta `);
          } else {
            return [
              createTextVNode(" Daftar Peserta ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.data_mahasiswa"),
        active: _ctx.route().current("admin.data_mahasiswa"),
        icon: "fas fa-file-alt"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Laporan Mahasiswa `);
          } else {
            return [
              createTextVNode(" Laporan Mahasiswa ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.prodi"),
        active: _ctx.route().current("admin.prodi"),
        icon: "fa-solid fa-university"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Prodi `);
          } else {
            return [
              createTextVNode(" Prodi ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.kelas"),
        active: _ctx.route().current("admin.kelas"),
        icon: "fa-solid fa-graduation-cap"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Kelas `);
          } else {
            return [
              createTextVNode(" Kelas ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.wave"),
        active: _ctx.route().current("admin.wave"),
        icon: "fa-solid fa-wave-square"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Gelombang `);
          } else {
            return [
              createTextVNode(" Gelombang ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.exams"),
        active: _ctx.route().current("admin.exams"),
        icon: "fa-solid fa-book"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Soal `);
          } else {
            return [
              createTextVNode(" Soal ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Partials/Menu/Panitia.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = {
  __name: "Verifikasi",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "mb-8" }, _attrs))}><header class="px-3 mb-4 text-xs font-semibold tracking-wider text-gray-500 uppercase dark:text-gray-400"> Verifikasi </header><ul class="pt-4 mt-4 space-y-2 font-medium border-t border-gray-200 dark:border-gray-700"><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.verification"),
        active: _ctx.route().current("admin.verification"),
        icon: "fa-solid fa-book-open"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Formulir `);
          } else {
            return [
              createTextVNode(" Formulir ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.end-validation"),
        active: _ctx.route().current("admin.end-validation"),
        icon: "fa-solid fa-check"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Penentuan `);
          } else {
            return [
              createTextVNode(" Penentuan ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Partials/Menu/Verifikasi.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  __name: "Keuangan",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "mb-8" }, _attrs))}><header class="px-3 mb-4 text-xs font-semibold tracking-wider text-gray-500 uppercase dark:text-gray-400"> Keuangan </header><ul class="pt-4 mt-4 space-y-2 font-medium border-t border-gray-200 dark:border-gray-700"><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.payment"),
        active: _ctx.route().current("admin.payment"),
        icon: "fa-solid fa-money-bill"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Pembayaran `);
          } else {
            return [
              createTextVNode(" Pembayaran ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Partials/Menu/Keuangan.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "Admin",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "mb-8" }, _attrs))}><header class="px-3 mb-4 text-xs font-semibold tracking-wider text-gray-500 uppercase dark:text-gray-400"> Admin </header><ul class="pt-4 mt-4 space-y-2 font-medium border-t border-gray-200 dark:border-gray-700"><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.web-setting"),
        active: _ctx.route().current("admin.web-setting"),
        icon: "fa-solid fa-cog"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Web Setting `);
          } else {
            return [
              createTextVNode(" Web Setting ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_sfc_main$9, {
        href: _ctx.route("admin.media"),
        active: _ctx.route().current("admin.media"),
        icon: "fas fa-images"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Media `);
          } else {
            return [
              createTextVNode(" Media ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Partials/Menu/Admin.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const notification = ref([]);
function useNotif() {
  const addNotif = (notif) => {
    notification.value.push(notif);
    notification.value = notification.value.sort((a, b) => {
      return new Date(b.created_at) - new Date(a.created_at);
    });
  };
  const removeNotif = async (id) => {
    await axios.patch(route("notifications.destroy", id));
  };
  const readNotif = async (id) => {
    await axios.patch(route("notifications.read", id));
    notification.value = notification.value.map((notif) => {
      if (notif.id === id) {
        notif.read_at = (/* @__PURE__ */ new Date()).toISOString();
      }
      return notif;
    });
  };
  const unreadNotif = () => {
    return notification.value.filter((notif) => !notif.read_at).length;
  };
  return {
    notification,
    addNotif,
    removeNotif,
    unreadNotif,
    readNotif
  };
}
const _sfc_main$2 = {
  __name: "NotifsHandler",
  __ssrInlineRender: true,
  setup(__props) {
    const { addNotif, notification: notification2, removeNotif, readNotif } = useNotif();
    const notif = computed(() => usePage().props.notifications);
    onMounted(() => {
      if (notif.value) {
        for (let i = 0; i < notif.value.length; i++) {
          if (notification2.value.filter((e) => e.id === notif.value[i].id).length)
            continue;
          addNotif(notif.value[i]);
        }
      }
    });
    watch(notif, (newVal) => {
      if (newVal) {
        for (let i = 0; i < newVal.length; i++) {
          if (notification2.value.filter((e) => e.id === newVal[i].id).length)
            continue;
          addNotif(newVal[i]);
        }
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(notification2).length) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-h-96 overflow-y-auto shadow-md sm:rounded-lg" }, _attrs))}><!--[-->`);
        ssrRenderList(unref(notification2), (x) => {
          _push(`<div class="w-full text-sm"><div class="${ssrRenderClass([{
            "bg-white": x.read_at,
            "bg-gray-100": !x.read_at
          }, "flex p-4 border-b"])}"><div><div class="font-semibold">${ssrInterpolate(x.data.subject)}</div><div class="text-sm text-gray-500 lowercase">${ssrInterpolate(x.data.message)}</div><div class="text-xs text-gray-400">${ssrInterpolate(x.created_at.split("T")[0])}</div></div><div class="ms-auto flex items-center"><button type="button" class="inline-flex flex-shrink-0 justify-center items-center h-5 w-5 rounded-lg text-yellow-800 opacity-50 hover:opacity-100 focus:outline-none focus:opacity-100 dark:text-yellow-200">`);
          if (!x.read_at) {
            _push(`<span class="sr-only">Check</span>`);
          } else {
            _push(`<!---->`);
          }
          if (!x.read_at) {
            _push(`<i class="fas fa-check flex-shrink-0 w-4 h-4"></i>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</button></div></div></div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<div${ssrRenderAttrs(_attrs)}><div class="w-full text-sm rounded-lg"><div class="flex p-4">Tidak ada notifikasi</div></div></div>`);
      }
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/NotifsHandler.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    modelValue: Boolean
  },
  emits: ["update:modelValue"],
  setup(__props) {
    const { unreadNotif } = useNotif();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs(mergeProps({ class: "fixed top-0 z-50 w-full bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700" }, _attrs))}><div class="max-w-full mx-auto px-4 sm:px-6 lg:px-8"><div class="flex justify-between h-16"><div class="flex"><div class="shrink-0 flex items-center text-black dark:text-white text-2xl font-bold leading-7"><button type="button" class="inline-flex items-center p-2 mt-2 ms-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"><span class="sr-only">Open sidebar</span><svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path></svg></button>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("dashboard"),
        class: "ml-3"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$page.props.web_settings.title_dashboard)}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$page.props.web_settings.title_dashboard), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="hidden space-x-8 sm:-my-px sm:ms-10 sm:flex"></div></div><div class="flex items-center ms-6"><div class="ms-3 relative">`);
      _push(ssrRenderComponent(_sfc_main$a, {
        align: "right",
        width: "responsive"
      }, {
        trigger: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="inline-flex rounded-md"${_scopeId}><button type="button" class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none transition ease-in-out duration-150"${_scopeId}><i class="fa-solid fa-bell text-2xl"${_scopeId}>`);
            if (unref(unreadNotif)() > 0) {
              _push2(`<div class="absolute inline-flex items-center justify-center w-6 h-6 text-xs font-bold text-white bg-red-500 border-2 border-white rounded-full top-0 end-0 dark:border-gray-900"${_scopeId}>${ssrInterpolate(unref(unreadNotif)())}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</i></button></span>`);
          } else {
            return [
              createVNode("span", { class: "inline-flex rounded-md" }, [
                createVNode("button", {
                  type: "button",
                  class: "inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none transition ease-in-out duration-150"
                }, [
                  createVNode("i", { class: "fa-solid fa-bell text-2xl" }, [
                    unref(unreadNotif)() > 0 ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "absolute inline-flex items-center justify-center w-6 h-6 text-xs font-bold text-white bg-red-500 border-2 border-white rounded-full top-0 end-0 dark:border-gray-900"
                    }, toDisplayString(unref(unreadNotif)()), 1)) : createCommentVNode("", true)
                  ])
                ])
              ])
            ];
          }
        }),
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$2)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="ms-3 relative">`);
      _push(ssrRenderComponent(_sfc_main$a, {
        align: "right",
        width: "48"
      }, {
        trigger: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="inline-flex rounded-md"${_scopeId}><button type="button" class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none transition ease-in-out duration-150"${_scopeId}><i class="fa-solid fa-user text-2xl"${_scopeId}></i></button></span>`);
          } else {
            return [
              createVNode("span", { class: "inline-flex rounded-md" }, [
                createVNode("button", {
                  type: "button",
                  class: "inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none transition ease-in-out duration-150"
                }, [
                  createVNode("i", { class: "fa-solid fa-user text-2xl" })
                ])
              ])
            ];
          }
        }),
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$b, {
              href: _ctx.route("profile.edit")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Profile `);
                } else {
                  return [
                    createTextVNode(" Profile ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$b, {
              href: _ctx.route("logout"),
              method: "post",
              as: "button"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Log Out `);
                } else {
                  return [
                    createTextVNode(" Log Out ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$b, {
                href: _ctx.route("profile.edit")
              }, {
                default: withCtx(() => [
                  createTextVNode(" Profile ")
                ]),
                _: 1
              }, 8, ["href"]),
              createVNode(_sfc_main$b, {
                href: _ctx.route("logout"),
                method: "post",
                as: "button"
              }, {
                default: withCtx(() => [
                  createTextVNode(" Log Out ")
                ]),
                _: 1
              }, 8, ["href"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></nav>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Partials/Nav/Index.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "AuthenticatedLayout",
  __ssrInlineRender: true,
  setup(__props) {
    ref(false);
    ref(route() || false);
    const isSideBarOpen = ref(false);
    const checkRole = (role = []) => {
      if (role.length == 0)
        return true;
      return role.some((r) => usePage().props.auth.user.roles.includes(r));
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="min-h-screen bg-gray-100 dark:bg-gray-900">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        modelValue: isSideBarOpen.value,
        "onUpdate:modelValue": ($event) => isSideBarOpen.value = $event
      }, null, _parent));
      _push(`<aside class="${ssrRenderClass([{ "translate-x-0": isSideBarOpen.value }, "fixed top-0 left-0 z-40 w-64 pt-20 h-screen transition-transform -translate-x-full md:translate-x-0 bg-white dark:bg-gray-800"])}"><div class="h-full px-3 py-4 overflow-y-auto">`);
      _push(ssrRenderComponent(_sfc_main$7, {
        check: checkRole(["user"])
      }, null, _parent));
      if (checkRole(["admin", "panitia"])) {
        _push(ssrRenderComponent(_sfc_main$6, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (checkRole(["admin", "panitia"])) {
        _push(ssrRenderComponent(_sfc_main$5, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (checkRole(["admin", "keuangan"])) {
        _push(ssrRenderComponent(_sfc_main$4, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (checkRole(["admin"])) {
        _push(ssrRenderComponent(_sfc_main$3, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></aside><div style="${ssrRenderStyle(isSideBarOpen.value ? null : { display: "none" })}" class="fixed inset-0 z-30 bg-gray-500 opacity-50"></div><main class="p-4 py-20 md:ml-64">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</main> ${ssrInterpolate(_ctx.$page.props.alert)} `);
      _push(ssrRenderComponent(_sfc_main$8, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/AuthenticatedLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
