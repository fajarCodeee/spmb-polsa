import { ref, onMounted, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { useForm, usePage } from "@inertiajs/vue3";
import { _ as _sfc_main$3 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$1 } from "./InputLabel-5e383564.js";
import "./TextInput-f08fe8c3.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$2 } from "./Combobox-8f85dcc2.js";
import axios from "axios";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "ChooseStudyProgram",
  __ssrInlineRender: true,
  setup(__props) {
    const form = useForm({
      wave: "",
      option: "",
      kelas: ""
    }).transform((data) => ({
      wave: data.wave ? parseInt(data.wave) : "",
      option: data.option ? parseInt(data.option) : "",
      kelas: data.kelas ? parseInt(data.kelas) : null
    }));
    const choices = ref([]);
    const choicesProdi = ref([]);
    const choicesKelas = ref([]);
    onMounted(() => {
      var _a;
      if (!((_a = usePage().props) == null ? void 0 : _a.form_status)) {
        axios.get("/api/gelombang").then((response) => {
          choices.value = response.data.data.map((item) => ({
            value: `${item.id}`,
            text: item.gelombang
          }));
          choices.value.unshift({
            value: "",
            text: "Pilih Gelombang"
          });
        }).catch((error) => {
        });
        axios.get("/api/program-studi").then((response) => {
          choicesProdi.value = response.data.data.map((item) => ({
            value: `${item.id}`,
            text: item.nama_prodi
          }));
          choicesProdi.value.unshift({
            value: "",
            text: "Pilih Prodi"
          });
        });
        axios.get("/api/kelas").then((response) => {
          choicesKelas.value = response.data.data.map((item) => ({
            value: `${item.id}`,
            text: item.nama_kelas
          }));
          choicesKelas.value.unshift({
            value: "",
            text: "Pilih Kelas"
          });
        });
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-w-7xl min-w-full mx-auto sm:px-6 lg:px-8 space-y-6" }, _attrs))}><div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg"><h2 class="font-bold text-left text-black text-2xl">Pendaftaran</h2><p>Ajukan pendaftaran untuk mendaftar di gelombang yang tersedia</p><div class="pt-8"><form class="mt-6 space-y-6"><div class="grid grid-cols-1 md:grid-cols-3 gap-4"><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "gelombang",
        value: "Gelombang"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "gelombang",
        class: "mt-1 block w-full",
        modelValue: unref(form).wave,
        "onUpdate:modelValue": ($event) => unref(form).wave = $event,
        "option-value": choices.value,
        placeholder: "Pilih Gelombang"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.wave
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "prodi",
        value: "Program Studi"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "prodi",
        class: "mt-1 block w-full",
        modelValue: unref(form).option,
        "onUpdate:modelValue": ($event) => unref(form).option = $event,
        "option-value": choicesProdi.value,
        placeholder: "Pilih Prodi"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.option
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "kelas",
        value: "Kelas"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "kelas",
        class: "mt-1 block w-full",
        modelValue: unref(form).kelas,
        "onUpdate:modelValue": ($event) => unref(form).kelas = $event,
        "option-value": choicesKelas.value,
        placeholder: "Pilih Kelas"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.kelas
      }, null, _parent));
      _push(`</div></div><div class="flex justify-end gap-4">`);
      if (unref(form).recentlySuccessful) {
        _push(`<p class="text-sm text-gray-600 dark:text-gray-400 items-center flex gap-2"> Berhasil mengajukan </p>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(PrimaryButton, {
        disabled: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Daftar`);
          } else {
            return [
              createTextVNode("Daftar")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></form></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Submission/Partials/ChooseStudyProgram.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
