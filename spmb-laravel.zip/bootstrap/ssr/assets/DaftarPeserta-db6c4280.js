import { ref, computed, mergeProps, useSSRContext, onMounted, unref, withCtx, createVNode, createTextVNode, openBlock, createBlock, Fragment, renderList, toDisplayString } from "vue";
import { ssrRenderAttrs, ssrRenderList, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrInterpolate, ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$3 } from "./SearchForm-7aa89cac.js";
import { _ as _sfc_main$2 } from "./AuthenticatedLayout-fbd10370.js";
import axios from "axios";
import { Head } from "@inertiajs/vue3";
import { Chart, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from "chart.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
const _sfc_main$1 = {
  __name: "FilterDropdown",
  __ssrInlineRender: true,
  props: {
    items: {
      type: Array,
      required: true
    }
  },
  emits: ["filter"],
  setup(__props, { emit: __emit }) {
    const show = ref(false);
    const props = __props;
    const tahun_akademik = computed(() => {
      return [...new Set(props.items.map((peserta) => peserta.get_form.wave.tahun_akademik))];
    });
    const prodi = computed(() => {
      return [...new Set(props.items.map((peserta) => peserta.get_form.prodi.nama_prodi))];
    });
    const kelas = computed(() => {
      return [...new Set(props.items.map((peserta) => peserta.get_form.kelas.nama_kelas))];
    });
    const wave = computed(() => {
      return [...new Set(props.items.map((peserta) => peserta.get_form.wave.gelombang))];
    });
    const selectedTahunAkademik = ref([]);
    const selectedProdi = ref([]);
    const selectedKelas = ref([]);
    const selectedWave = ref([]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative flex items-center w-full px-4" }, _attrs))}><button class="w-full flex items-center justify-center py-2 px-4 text-sm font-semibold text-gray-900 border-2 rounded-md hover:bg-gray-100"><i class="fas fa-filter me-1"></i>Filter </button>`);
      if (show.value) {
        _push(`<div class="absolute top-12 right-0 z-10 w-96 p-3 bg-white rounded-lg shadow-md"><div class="grid grid-cols-2 gap-2"><div class="mb-3"><h6 class="mb-3 text-sm font-semibold text-gray-900">Tahun Akademik</h6><ul class="space-y-2 text-sm"><!--[-->`);
        ssrRenderList(tahun_akademik.value, (tahun_akademik2, index) => {
          _push(`<li><input type="checkbox"${ssrRenderAttr("id", `filter_options_${index}`)}${ssrIncludeBooleanAttr(Array.isArray(selectedTahunAkademik.value) ? ssrLooseContain(selectedTahunAkademik.value, tahun_akademik2) : selectedTahunAkademik.value) ? " checked" : ""}${ssrRenderAttr("value", tahun_akademik2)} class="w-4 h-4 bg-gray-50 rounded-sm"><label${ssrRenderAttr("for", `filter_options_${index}`)} class="ml-2 text-sm font-medium text-gray-900">${ssrInterpolate(tahun_akademik2)}</label></li>`);
        });
        _push(`<!--]--></ul></div><div class="mb-3"><h6 class="mb-3 text-sm font-semibold text-gray-900">Gelombang</h6><ul class="space-y-2 text-sm"><!--[-->`);
        ssrRenderList(wave.value, (wave2, index) => {
          _push(`<li><input type="checkbox"${ssrRenderAttr("id", `wave_filter_options_${index}`)}${ssrIncludeBooleanAttr(Array.isArray(selectedWave.value) ? ssrLooseContain(selectedWave.value, wave2) : selectedWave.value) ? " checked" : ""}${ssrRenderAttr("value", wave2)} class="w-4 h-4 bg-gray-50 rounded-sm"><label${ssrRenderAttr("for", `wave_filter_options_${index}`)} class="ml-2 text-sm font-medium text-gray-900">${ssrInterpolate(wave2)}</label></li>`);
        });
        _push(`<!--]--></ul></div></div><div class="grid grid-cols-2 gap-2"><div class="mb-3"><h6 class="mb-3 text-sm font-semibold text-gray-900">Program Studi</h6><ul class="space-y-2 text-sm"><!--[-->`);
        ssrRenderList(prodi.value, (prodi2, index) => {
          _push(`<li><input type="checkbox"${ssrRenderAttr("id", `prodi_filter_options_${index}`)}${ssrIncludeBooleanAttr(Array.isArray(selectedProdi.value) ? ssrLooseContain(selectedProdi.value, prodi2) : selectedProdi.value) ? " checked" : ""}${ssrRenderAttr("value", prodi2)} class="w-4 h-4 bg-gray-50 rounded-sm"><label${ssrRenderAttr("for", `prodi_filter_options_${index}`)} class="ml-2 text-sm font-medium text-gray-900">${ssrInterpolate(prodi2)}</label></li>`);
        });
        _push(`<!--]--></ul></div><div class="mb-3"><h6 class="mb-3 text-sm font-semibold text-gray-900">Kelas</h6><ul class="space-y-2 text-sm"><!--[-->`);
        ssrRenderList(kelas.value, (kelas2, index) => {
          _push(`<li><input type="checkbox"${ssrRenderAttr("id", `kelas_filter_options_${index}`)}${ssrIncludeBooleanAttr(Array.isArray(selectedKelas.value) ? ssrLooseContain(selectedKelas.value, kelas2) : selectedKelas.value) ? " checked" : ""}${ssrRenderAttr("value", kelas2)} class="w-4 h-4 bg-gray-50 rounded-sm"><label${ssrRenderAttr("for", `kelas_filter_options_${index}`)} class="ml-2 text-sm font-medium text-gray-900">${ssrInterpolate(kelas2)}</label></li>`);
        });
        _push(`<!--]--></ul></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/FilterDropdown.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "DaftarPeserta",
  __ssrInlineRender: true,
  props: {
    peserta: {
      type: Array
    },
    wave: {
      type: Object
    }
  },
  setup(__props) {
    Chart.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);
    const props = __props;
    onMounted(() => {
      console.log(props.peserta);
    });
    const searchFilter = ref("");
    const tahunAkademikFilter = ref([]);
    const gelombangFilter = ref([]);
    const prodiFilter = ref([]);
    const kelasFilter = ref([]);
    const filterItems = computed(() => {
      let peserta = props.peserta;
      if (tahunAkademikFilter.value.length) {
        peserta = peserta.filter((peserta2) => tahunAkademikFilter.value.includes(peserta2.get_form.wave.tahun_akademik));
      }
      if (gelombangFilter.value.length) {
        peserta = peserta.filter((peserta2) => gelombangFilter.value.includes(peserta2.get_form.wave.gelombang));
      }
      if (prodiFilter.value.length) {
        peserta = peserta.filter((peserta2) => prodiFilter.value.includes(peserta2.get_form.prodi.nama_prodi));
      }
      if (kelasFilter.value.length) {
        peserta = peserta.filter((peserta2) => kelasFilter.value.includes(peserta2.get_form.kelas.nama_kelas));
      }
      if (searchFilter.value !== "") {
        peserta = peserta.filter((peserta2) => peserta2.name.includes(searchFilter.value) || peserta2.get_form.national_id.includes(searchFilter.value));
      }
      return peserta;
    });
    const handleSearch = (search) => {
      searchFilter.value = search;
    };
    const handleCheckbox = (filters) => {
      tahunAkademikFilter.value = filters.tahunAkademik;
      prodiFilter.value = filters.prodi;
      kelasFilter.value = filters.kelas;
      gelombangFilter.value = filters.wave;
    };
    const exportData = () => {
      axios.post("/admin/export-peserta", {
        filteredData: JSON.parse(JSON.stringify(filterItems.value)),
        nim: "test NIM"
      }, {
        responseType: "blob"
        // Pastikan menerima response sebagai file Blob
      }).then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        const sekarang = /* @__PURE__ */ new Date();
        const hari = String(sekarang.getDate()).padStart(2, "0");
        const bulan = String(sekarang.getMonth() + 1).padStart(2, "0");
        const tahun = sekarang.getFullYear();
        const jam = String(sekarang.getHours()).padStart(2, "0");
        const menit = String(sekarang.getMinutes()).padStart(2, "0");
        const detik = String(sekarang.getSeconds()).padStart(2, "0");
        const formatted = `${hari}_${bulan}_${tahun}_${jam}_${menit}_${detik}`;
        link.setAttribute("download", `DATA_PESERTA[NON REGIS]_${formatted}.xlsx`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }).catch((error) => {
        console.error("Error downloading the file:", error);
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Daftar Peserta" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="shadow-md sm:shadow-lg p-4 sm:p-8 bg-white"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between gap-3 pb-4"${_scopeId}><header class="flex flex-row items-center"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}> Daftar Peserta </h2>`);
            _push2(ssrRenderComponent(_sfc_main$3, { onSearch: handleSearch }, null, _parent2, _scopeId));
            _push2(`</header><div class="flex flex-columm justify-between"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              items: __props.peserta,
              onFilter: handleCheckbox
            }, null, _parent2, _scopeId));
            _push2(`<button class="w-full flex items-center justify-center py-2 px-4 text-sm font-semibold text-white rounded-md hover:bg-red-700 bg-red-400"${_scopeId}><i class="fas fa-print mr-1"${_scopeId}></i>Export</button></div></div><div class="relative overflow-x-auto"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3 capitalize"${_scopeId}>Nama lengkap</th><th scope="col" class="px-6 py-3"${_scopeId}> NIK </th><th scope="col" class="px-6 py-3"${_scopeId}> Tahun Akademik </th><th scope="col" class="px-6 py-3"${_scopeId}> Alamat </th><th scope="col" class="px-6 py-3"${_scopeId}> Prodi Pilihan </th><th scope="col" class="px-6 py-3"${_scopeId}> Kelas </th><th scope="col" class="px-6 py-3"${_scopeId}> Nomer WhatsApp </th><th scope="col" class="px-6 py-3"${_scopeId}> Nama Ibu </th><th scope="col" class="px-6 py-3"${_scopeId}> Email </th><th scope="col" class="px-6 py-3"${_scopeId}> Action </th></tr></thead><tbody class="uppercase"${_scopeId}><!--[-->`);
            ssrRenderList(filterItems.value, (peserta) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(peserta.name)}</th><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(peserta.get_form.national_id ?? "(Belum Dilengkapi)")}</th><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white capitalize"${_scopeId}>${ssrInterpolate(peserta.get_form.wave.tahun_akademik)}</th><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(peserta.get_form.address ?? "(Belum Dilengkapi)")}</th><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(peserta.get_form.prodi.nama_prodi ?? "(Belum Dilengkapi)")}</th><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(peserta.get_form.kelas.nama_kelas ?? "(Belum Dilengkapi)")}</th><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(peserta.get_form.phone_number ?? "(Belum Dilengkapi)")}</th><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white capitalize"${_scopeId}>${ssrInterpolate(peserta.get_form.mother_name ?? "(Belum Dilengkapi)")}</th><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white lowercase"${_scopeId}>${ssrInterpolate(peserta.email)}</th><td class="px-6 py-4 flex gap-2"${_scopeId}><button class="text-indigo-600 hover:text-indigo-900"${_scopeId}><i class="fa-solid fa-pencil"${_scopeId}></i></button><button class="text-red-600 hover:text-red-900"${_scopeId}><i class="fa-solid fa-trash"${_scopeId}></i></button></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "shadow-md sm:shadow-lg p-4 sm:p-8 bg-white" }, [
                    createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between gap-3 pb-4" }, [
                      createVNode("header", { class: "flex flex-row items-center" }, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Daftar Peserta "),
                        createVNode(_sfc_main$3, { onSearch: handleSearch })
                      ]),
                      createVNode("div", { class: "flex flex-columm justify-between" }, [
                        createVNode(_sfc_main$1, {
                          items: __props.peserta,
                          onFilter: handleCheckbox
                        }, null, 8, ["items"]),
                        createVNode("button", {
                          onClick: exportData,
                          class: "w-full flex items-center justify-center py-2 px-4 text-sm font-semibold text-white rounded-md hover:bg-red-700 bg-red-400"
                        }, [
                          createVNode("i", { class: "fas fa-print mr-1" }),
                          createTextVNode("Export")
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 capitalize"
                            }, "Nama lengkap"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " NIK "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Tahun Akademik "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Alamat "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Prodi Pilihan "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Kelas "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Nomer WhatsApp "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Nama Ibu "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Email "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", { class: "uppercase" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(filterItems.value, (peserta) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: peserta.id
                            }, [
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(peserta.name), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(peserta.get_form.national_id ?? "(Belum Dilengkapi)"), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white capitalize"
                              }, toDisplayString(peserta.get_form.wave.tahun_akademik), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(peserta.get_form.address ?? "(Belum Dilengkapi)"), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(peserta.get_form.prodi.nama_prodi ?? "(Belum Dilengkapi)"), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(peserta.get_form.kelas.nama_kelas ?? "(Belum Dilengkapi)"), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(peserta.get_form.phone_number ?? "(Belum Dilengkapi)"), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white capitalize"
                              }, toDisplayString(peserta.get_form.mother_name ?? "(Belum Dilengkapi)"), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white lowercase"
                              }, toDisplayString(peserta.email), 1),
                              createVNode("td", { class: "px-6 py-4 flex gap-2" }, [
                                createVNode("button", {
                                  onClick: ($event) => _ctx.editProdi(peserta.id),
                                  class: "text-indigo-600 hover:text-indigo-900"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-pencil" })
                                ], 8, ["onClick"]),
                                createVNode("button", {
                                  onClick: ($event) => _ctx.deleteProdi(peserta.id),
                                  class: "text-red-600 hover:text-red-900"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-trash" })
                                ], 8, ["onClick"])
                              ])
                            ]);
                          }), 128))
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/DaftarPeserta.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
