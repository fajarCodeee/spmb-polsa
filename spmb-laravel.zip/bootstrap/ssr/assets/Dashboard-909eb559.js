import { unref, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { Head, Link } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  props: {},
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight"${_scopeId}> Dashboard </h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight" }, " Dashboard ")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-gray-800 overflow-hidden shadow-md sm:shadow-lg sm:rounded-lg"${_scopeId}><div class="p-6 text-gray-900 dark:text-gray-100"${_scopeId}><h1 class="font-bold text-2xl"${_scopeId}> Selamat Datang di Sistem Pendaftaran Mahasiswa Baru <br${_scopeId}> ${ssrInterpolate(_ctx.$page.props.auth.user.name)} 👋 </h1>`);
            if (!_ctx.$page.props.auth.form.already) {
              _push2(`<p${_scopeId}> Apakah anda akan mendaftar sebagai mahasiswa baru? silahkan klik tombol dibawah ini. </p>`);
            } else {
              _push2(`<p${_scopeId}>Silahkan lanjut mengisi form pendaftaran.</p>`);
            }
            _push2(`<div class="flex justify-start mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(PrimaryButton, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("form.edit", { id: "personal" })
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${ssrInterpolate(_ctx.$page.props.auth.form.already ? "Lanjut" : "Bikin formulir")}`);
                      } else {
                        return [
                          createTextVNode(toDisplayString(_ctx.$page.props.auth.form.already ? "Lanjut" : "Bikin formulir"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(Link), {
                      href: _ctx.route("form.edit", { id: "personal" })
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(_ctx.$page.props.auth.form.already ? "Lanjut" : "Bikin formulir"), 1)
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div></div></div><div class="py-2"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-gray-800 overflow-hidden shadow-md sm:shadow-lg sm:rounded-lg"${_scopeId}><div class="p-6 text-gray-900 dark:text-gray-100"${_scopeId}><h1 class="font-bold text-2xl"${_scopeId}>Panduan pengisian</h1><ol class="relative border-s border-gray-200 dark:border-gray-700"${_scopeId}><li class="mb-10 ms-4"${_scopeId}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId}></div><time class="mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500"${_scopeId}>Langkah pertama</time><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId}> Ajukan pembelian formulir </h3><p class="mb-4 text-base font-normal text-gray-500 dark:text-gray-400"${_scopeId}> Pilih gelombang pendaftaran dan pilih jursan yang anda inginkan di menu `);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("form.submission"),
              class: "text-blue-600 hover:underline"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` pendaftaran `);
                } else {
                  return [
                    createTextVNode(" pendaftaran ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`. </p></li><li class="mb-10 ms-4"${_scopeId}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId}></div><time class="mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500"${_scopeId}>Langkah kedua</time><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId}> Isi setiap formulir </h3><p class="text-base font-normal text-gray-500 dark:text-gray-400"${_scopeId}> Isi setiap formulir dengan benar dan sesuai dengan identitas diri anda di menu `);
            _push2(ssrRenderComponent(unref(Link), {
              class: "text-blue-600 hover:underline",
              href: _ctx.route("form.edit", {
                id: "personal"
              })
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`data diri`);
                } else {
                  return [
                    createTextVNode("data diri")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</p></li><li class="mb-10 ms-4"${_scopeId}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId}></div><time class="mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500"${_scopeId}>Langkah ketiga</time><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId}> Jika sudah lengkap, ikuti semua tes yang ada </h3><p class="text-base font-normal text-gray-500 dark:text-gray-800"${_scopeId}> Tes akan dilakukan secara online, pastikan koneksi internet anda stabil dan tidak ada gangguan. </p></li><li class="ms-4"${_scopeId}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId}></div><time class="mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500"${_scopeId}>Langkah keempat</time><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId}> Tunggu pengumuman </h3><p class="text-base font-normal text-gray-500 dark:text-gray-800"${_scopeId}> Panitia akan mengumumkan hasil seleksi penerimaan mahasiswa baru di menu `);
            _push2(ssrRenderComponent(unref(Link), {
              class: "text-blue-600 hover:underline",
              href: _ctx.route("form.submission")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` pendaftaran `);
                } else {
                  return [
                    createTextVNode(" pendaftaran ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`. </p></li></ol><footer class="flex justify-end mt-4"${_scopeId}><p class="text-gray-300 dark:text-gray-400 text-sm"${_scopeId}> Semangat! 😉 </p></footer></div></div></div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-gray-800 overflow-hidden shadow-md sm:shadow-lg sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6 text-gray-900 dark:text-gray-100" }, [
                      createVNode("h1", { class: "font-bold text-2xl" }, [
                        createTextVNode(" Selamat Datang di Sistem Pendaftaran Mahasiswa Baru "),
                        createVNode("br"),
                        createTextVNode(" " + toDisplayString(_ctx.$page.props.auth.user.name) + " 👋 ", 1)
                      ]),
                      !_ctx.$page.props.auth.form.already ? (openBlock(), createBlock("p", { key: 0 }, " Apakah anda akan mendaftar sebagai mahasiswa baru? silahkan klik tombol dibawah ini. ")) : (openBlock(), createBlock("p", { key: 1 }, "Silahkan lanjut mengisi form pendaftaran.")),
                      createVNode("div", { class: "flex justify-start mt-4" }, [
                        createVNode(PrimaryButton, null, {
                          default: withCtx(() => [
                            createVNode(unref(Link), {
                              href: _ctx.route("form.edit", { id: "personal" })
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(_ctx.$page.props.auth.form.already ? "Lanjut" : "Bikin formulir"), 1)
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ])
                ])
              ]),
              createVNode("div", { class: "py-2" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-gray-800 overflow-hidden shadow-md sm:shadow-lg sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6 text-gray-900 dark:text-gray-100" }, [
                      createVNode("h1", { class: "font-bold text-2xl" }, "Panduan pengisian"),
                      createVNode("ol", { class: "relative border-s border-gray-200 dark:border-gray-700" }, [
                        createVNode("li", { class: "mb-10 ms-4" }, [
                          createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                          createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah pertama"),
                          createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Ajukan pembelian formulir "),
                          createVNode("p", { class: "mb-4 text-base font-normal text-gray-500 dark:text-gray-400" }, [
                            createTextVNode(" Pilih gelombang pendaftaran dan pilih jursan yang anda inginkan di menu "),
                            createVNode(unref(Link), {
                              href: _ctx.route("form.submission"),
                              class: "text-blue-600 hover:underline"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" pendaftaran ")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createTextVNode(". ")
                          ])
                        ]),
                        createVNode("li", { class: "mb-10 ms-4" }, [
                          createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                          createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah kedua"),
                          createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Isi setiap formulir "),
                          createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-400" }, [
                            createTextVNode(" Isi setiap formulir dengan benar dan sesuai dengan identitas diri anda di menu "),
                            createVNode(unref(Link), {
                              class: "text-blue-600 hover:underline",
                              href: _ctx.route("form.edit", {
                                id: "personal"
                              })
                            }, {
                              default: withCtx(() => [
                                createTextVNode("data diri")
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ])
                        ]),
                        createVNode("li", { class: "mb-10 ms-4" }, [
                          createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                          createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah ketiga"),
                          createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Jika sudah lengkap, ikuti semua tes yang ada "),
                          createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-800" }, " Tes akan dilakukan secara online, pastikan koneksi internet anda stabil dan tidak ada gangguan. ")
                        ]),
                        createVNode("li", { class: "ms-4" }, [
                          createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                          createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah keempat"),
                          createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Tunggu pengumuman "),
                          createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-800" }, [
                            createTextVNode(" Panitia akan mengumumkan hasil seleksi penerimaan mahasiswa baru di menu "),
                            createVNode(unref(Link), {
                              class: "text-blue-600 hover:underline",
                              href: _ctx.route("form.submission")
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" pendaftaran ")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createTextVNode(". ")
                          ])
                        ])
                      ]),
                      createVNode("footer", { class: "flex justify-end mt-4" }, [
                        createVNode("p", { class: "text-gray-300 dark:text-gray-400 text-sm" }, " Semangat! 😉 ")
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
