import { mergeProps, useSSRContext, ref, onMounted, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode } from "vue";
import { ssrRenderAttrs, ssrRenderClass, ssrInterpolate, ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$2 } from "./AuthenticatedLayout-fbd10370.js";
import { Head } from "@inertiajs/vue3";
import { C as Container, _ as _sfc_main$4 } from "./Card-8fb49bd9.js";
import { _ as _sfc_main$3 } from "./Grid-9e8ae324.js";
import { Chart, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from "chart.js";
import { Bar } from "vue-chartjs";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main$1 = {
  __name: "CardStats",
  __ssrInlineRender: true,
  props: {
    label: {
      type: String,
      default: "Label"
    },
    icon: {
      type: String,
      default: "fa-solid fa-question"
    },
    color: {
      type: String,
      default: "gray"
    },
    value: {
      type: Number,
      default: 0
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center justify-between p-4 bg-white rounded-lg shadow-md" }, _attrs))}><div class="${ssrRenderClass([`bg-${__props.color}-100`, "p-4 rounded-full mr-4"])}"><i class="${ssrRenderClass([`${__props.icon} text-${__props.color}-500`, "text-4xl"])}"></i></div><div class="flex flex-col justify-center items-center"><div class="text-2xl font-bold flex w-full justify-end md:justify-center">${ssrInterpolate(__props.value)}</div><div>${ssrInterpolate(__props.label)}</div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/CardStats.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  setup(__props) {
    Chart.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);
    const data_chart = ref(null);
    const data_count = ref(null);
    const options = ref({
      responsive: true
    });
    onMounted(() => {
      fetch(route("admin.dashboard.chart")).then((response) => response.json()).then((data) => {
        data_chart.value = data.data.chart;
        data_count.value = data.data.count;
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(Container, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<h2 class="text-2xl font-bold"${_scopeId2}>Dashboard</h2>`);
                  _push3(ssrRenderComponent(_sfc_main$3, { col: "1" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_sfc_main$3, {
                          col: "1",
                          sm: "2",
                          md: "4",
                          lg: "4"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            var _a, _b, _c, _d;
                            if (_push5) {
                              _push5(ssrRenderComponent(_sfc_main$1, {
                                label: "Pengguna",
                                icon: "fa-solid fa-users",
                                color: "blue",
                                value: data_count.value ? data_count.value.users : 0
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_sfc_main$1, {
                                label: "Formulir",
                                icon: "fa-solid fa-graduation-cap",
                                color: "green",
                                value: data_count.value ? data_count.value.forms : 0
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_sfc_main$1, {
                                label: "Prodi",
                                icon: "fa-solid fa-graduation-cap",
                                color: "red",
                                value: data_count.value ? (_a = data_count.value) == null ? void 0 : _a.prodi : 0
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_sfc_main$1, {
                                label: "Gel. Aktif",
                                icon: "fa-solid fa-water",
                                color: "orange",
                                value: data_count.value ? (_b = data_count.value) == null ? void 0 : _b.wave : 0
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_sfc_main$1, {
                                  label: "Pengguna",
                                  icon: "fa-solid fa-users",
                                  color: "blue",
                                  value: data_count.value ? data_count.value.users : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Formulir",
                                  icon: "fa-solid fa-graduation-cap",
                                  color: "green",
                                  value: data_count.value ? data_count.value.forms : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Prodi",
                                  icon: "fa-solid fa-graduation-cap",
                                  color: "red",
                                  value: data_count.value ? (_c = data_count.value) == null ? void 0 : _c.prodi : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Gel. Aktif",
                                  icon: "fa-solid fa-water",
                                  color: "orange",
                                  value: data_count.value ? (_d = data_count.value) == null ? void 0 : _d.wave : 0
                                }, null, 8, ["value"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(`<div${_scopeId3}><h2 class="text-xl font-bold mt-8 mb-4"${_scopeId3}> Antrian Verifikasi Formulir Mahasiswa </h2>`);
                        _push4(ssrRenderComponent(_sfc_main$3, {
                          col: "1",
                          sm: "2",
                          md: "4",
                          lg: "4"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
                            if (_push5) {
                              _push5(ssrRenderComponent(_sfc_main$1, {
                                label: "Formulir",
                                icon: "fa-solid fa-user-tie",
                                color: "blue",
                                value: data_count.value ? (_b = (_a = data_count.value) == null ? void 0 : _a.validation) == null ? void 0 : _b.forms : 0
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_sfc_main$1, {
                                label: "Penetuan",
                                icon: "fa-solid fa-person-circle-question",
                                color: "green",
                                value: data_count.value ? (_d = (_c = data_count.value) == null ? void 0 : _c.validation) == null ? void 0 : _d.graduation : 0
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_sfc_main$1, {
                                label: "Pembayaran",
                                icon: "fa-solid fa-cash-register",
                                color: "red",
                                value: data_count.value ? (_f = (_e = data_count.value) == null ? void 0 : _e.validation) == null ? void 0 : _f.payment : 0
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_sfc_main$1, {
                                  label: "Formulir",
                                  icon: "fa-solid fa-user-tie",
                                  color: "blue",
                                  value: data_count.value ? (_h = (_g = data_count.value) == null ? void 0 : _g.validation) == null ? void 0 : _h.forms : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Penetuan",
                                  icon: "fa-solid fa-person-circle-question",
                                  color: "green",
                                  value: data_count.value ? (_j = (_i = data_count.value) == null ? void 0 : _i.validation) == null ? void 0 : _j.graduation : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Pembayaran",
                                  icon: "fa-solid fa-cash-register",
                                  color: "red",
                                  value: data_count.value ? (_l = (_k = data_count.value) == null ? void 0 : _k.validation) == null ? void 0 : _l.payment : 0
                                }, null, 8, ["value"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(`</div>`);
                        _push4(ssrRenderComponent(_sfc_main$4, { title: "Statistik" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              if (data_chart.value) {
                                _push5(ssrRenderComponent(unref(Bar), {
                                  data: data_chart.value,
                                  options: options.value
                                }, null, _parent5, _scopeId4));
                              } else {
                                _push5(`<!---->`);
                              }
                            } else {
                              return [
                                data_chart.value ? (openBlock(), createBlock(unref(Bar), {
                                  key: 0,
                                  data: data_chart.value,
                                  options: options.value
                                }, null, 8, ["data", "options"])) : createCommentVNode("", true)
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_sfc_main$3, {
                            col: "1",
                            sm: "2",
                            md: "4",
                            lg: "4"
                          }, {
                            default: withCtx(() => {
                              var _a, _b;
                              return [
                                createVNode(_sfc_main$1, {
                                  label: "Pengguna",
                                  icon: "fa-solid fa-users",
                                  color: "blue",
                                  value: data_count.value ? data_count.value.users : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Formulir",
                                  icon: "fa-solid fa-graduation-cap",
                                  color: "green",
                                  value: data_count.value ? data_count.value.forms : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Prodi",
                                  icon: "fa-solid fa-graduation-cap",
                                  color: "red",
                                  value: data_count.value ? (_a = data_count.value) == null ? void 0 : _a.prodi : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Gel. Aktif",
                                  icon: "fa-solid fa-water",
                                  color: "orange",
                                  value: data_count.value ? (_b = data_count.value) == null ? void 0 : _b.wave : 0
                                }, null, 8, ["value"])
                              ];
                            }),
                            _: 1
                          }),
                          createVNode("div", null, [
                            createVNode("h2", { class: "text-xl font-bold mt-8 mb-4" }, " Antrian Verifikasi Formulir Mahasiswa "),
                            createVNode(_sfc_main$3, {
                              col: "1",
                              sm: "2",
                              md: "4",
                              lg: "4"
                            }, {
                              default: withCtx(() => {
                                var _a, _b, _c, _d, _e, _f;
                                return [
                                  createVNode(_sfc_main$1, {
                                    label: "Formulir",
                                    icon: "fa-solid fa-user-tie",
                                    color: "blue",
                                    value: data_count.value ? (_b = (_a = data_count.value) == null ? void 0 : _a.validation) == null ? void 0 : _b.forms : 0
                                  }, null, 8, ["value"]),
                                  createVNode(_sfc_main$1, {
                                    label: "Penetuan",
                                    icon: "fa-solid fa-person-circle-question",
                                    color: "green",
                                    value: data_count.value ? (_d = (_c = data_count.value) == null ? void 0 : _c.validation) == null ? void 0 : _d.graduation : 0
                                  }, null, 8, ["value"]),
                                  createVNode(_sfc_main$1, {
                                    label: "Pembayaran",
                                    icon: "fa-solid fa-cash-register",
                                    color: "red",
                                    value: data_count.value ? (_f = (_e = data_count.value) == null ? void 0 : _e.validation) == null ? void 0 : _f.payment : 0
                                  }, null, 8, ["value"])
                                ];
                              }),
                              _: 1
                            })
                          ]),
                          createVNode(_sfc_main$4, { title: "Statistik" }, {
                            default: withCtx(() => [
                              data_chart.value ? (openBlock(), createBlock(unref(Bar), {
                                key: 0,
                                data: data_chart.value,
                                options: options.value
                              }, null, 8, ["data", "options"])) : createCommentVNode("", true)
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("h2", { class: "text-2xl font-bold" }, "Dashboard"),
                    createVNode(_sfc_main$3, { col: "1" }, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$3, {
                          col: "1",
                          sm: "2",
                          md: "4",
                          lg: "4"
                        }, {
                          default: withCtx(() => {
                            var _a, _b;
                            return [
                              createVNode(_sfc_main$1, {
                                label: "Pengguna",
                                icon: "fa-solid fa-users",
                                color: "blue",
                                value: data_count.value ? data_count.value.users : 0
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$1, {
                                label: "Formulir",
                                icon: "fa-solid fa-graduation-cap",
                                color: "green",
                                value: data_count.value ? data_count.value.forms : 0
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$1, {
                                label: "Prodi",
                                icon: "fa-solid fa-graduation-cap",
                                color: "red",
                                value: data_count.value ? (_a = data_count.value) == null ? void 0 : _a.prodi : 0
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$1, {
                                label: "Gel. Aktif",
                                icon: "fa-solid fa-water",
                                color: "orange",
                                value: data_count.value ? (_b = data_count.value) == null ? void 0 : _b.wave : 0
                              }, null, 8, ["value"])
                            ];
                          }),
                          _: 1
                        }),
                        createVNode("div", null, [
                          createVNode("h2", { class: "text-xl font-bold mt-8 mb-4" }, " Antrian Verifikasi Formulir Mahasiswa "),
                          createVNode(_sfc_main$3, {
                            col: "1",
                            sm: "2",
                            md: "4",
                            lg: "4"
                          }, {
                            default: withCtx(() => {
                              var _a, _b, _c, _d, _e, _f;
                              return [
                                createVNode(_sfc_main$1, {
                                  label: "Formulir",
                                  icon: "fa-solid fa-user-tie",
                                  color: "blue",
                                  value: data_count.value ? (_b = (_a = data_count.value) == null ? void 0 : _a.validation) == null ? void 0 : _b.forms : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Penetuan",
                                  icon: "fa-solid fa-person-circle-question",
                                  color: "green",
                                  value: data_count.value ? (_d = (_c = data_count.value) == null ? void 0 : _c.validation) == null ? void 0 : _d.graduation : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Pembayaran",
                                  icon: "fa-solid fa-cash-register",
                                  color: "red",
                                  value: data_count.value ? (_f = (_e = data_count.value) == null ? void 0 : _e.validation) == null ? void 0 : _f.payment : 0
                                }, null, 8, ["value"])
                              ];
                            }),
                            _: 1
                          })
                        ]),
                        createVNode(_sfc_main$4, { title: "Statistik" }, {
                          default: withCtx(() => [
                            data_chart.value ? (openBlock(), createBlock(unref(Bar), {
                              key: 0,
                              data: data_chart.value,
                              options: options.value
                            }, null, 8, ["data", "options"])) : createCommentVNode("", true)
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode(Container, null, {
                  default: withCtx(() => [
                    createVNode("h2", { class: "text-2xl font-bold" }, "Dashboard"),
                    createVNode(_sfc_main$3, { col: "1" }, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$3, {
                          col: "1",
                          sm: "2",
                          md: "4",
                          lg: "4"
                        }, {
                          default: withCtx(() => {
                            var _a, _b;
                            return [
                              createVNode(_sfc_main$1, {
                                label: "Pengguna",
                                icon: "fa-solid fa-users",
                                color: "blue",
                                value: data_count.value ? data_count.value.users : 0
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$1, {
                                label: "Formulir",
                                icon: "fa-solid fa-graduation-cap",
                                color: "green",
                                value: data_count.value ? data_count.value.forms : 0
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$1, {
                                label: "Prodi",
                                icon: "fa-solid fa-graduation-cap",
                                color: "red",
                                value: data_count.value ? (_a = data_count.value) == null ? void 0 : _a.prodi : 0
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$1, {
                                label: "Gel. Aktif",
                                icon: "fa-solid fa-water",
                                color: "orange",
                                value: data_count.value ? (_b = data_count.value) == null ? void 0 : _b.wave : 0
                              }, null, 8, ["value"])
                            ];
                          }),
                          _: 1
                        }),
                        createVNode("div", null, [
                          createVNode("h2", { class: "text-xl font-bold mt-8 mb-4" }, " Antrian Verifikasi Formulir Mahasiswa "),
                          createVNode(_sfc_main$3, {
                            col: "1",
                            sm: "2",
                            md: "4",
                            lg: "4"
                          }, {
                            default: withCtx(() => {
                              var _a, _b, _c, _d, _e, _f;
                              return [
                                createVNode(_sfc_main$1, {
                                  label: "Formulir",
                                  icon: "fa-solid fa-user-tie",
                                  color: "blue",
                                  value: data_count.value ? (_b = (_a = data_count.value) == null ? void 0 : _a.validation) == null ? void 0 : _b.forms : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Penetuan",
                                  icon: "fa-solid fa-person-circle-question",
                                  color: "green",
                                  value: data_count.value ? (_d = (_c = data_count.value) == null ? void 0 : _c.validation) == null ? void 0 : _d.graduation : 0
                                }, null, 8, ["value"]),
                                createVNode(_sfc_main$1, {
                                  label: "Pembayaran",
                                  icon: "fa-solid fa-cash-register",
                                  color: "red",
                                  value: data_count.value ? (_f = (_e = data_count.value) == null ? void 0 : _e.validation) == null ? void 0 : _f.payment : 0
                                }, null, 8, ["value"])
                              ];
                            }),
                            _: 1
                          })
                        ]),
                        createVNode(_sfc_main$4, { title: "Statistik" }, {
                          default: withCtx(() => [
                            data_chart.value ? (openBlock(), createBlock(unref(Bar), {
                              key: 0,
                              data: data_chart.value,
                              options: options.value
                            }, null, 8, ["data", "options"])) : createCommentVNode("", true)
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
