import { onMounted, ref, withCtx, unref, createVNode, toDisplayString, createTextVNode, openBlock, createBlock, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderClass } from "vue/server-renderer";
import "@inertiajs/vue3";
import { C as Container, _ as _sfc_main$1 } from "./Card-8fb49bd9.js";
import { _ as _sfc_main$2 } from "./Display-b7d04753.js";
import "./PrimaryButton-373a10a0.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Determination",
  __ssrInlineRender: true,
  props: {
    form: {
      default: null,
      type: Object
    }
  },
  setup(__props) {
    const props = __props;
    onMounted(() => {
      console.log(props.form);
    });
    const randomNumber = Math.floor(1e5 + Math.random() * 9e5);
    const copyToClipboard = (text) => {
      const elem = document.createElement("textarea");
      elem.value = text.replace(/ |-/g, "");
      document.body.appendChild(elem);
      elem.select();
      document.execCommand("copy");
      document.body.removeChild(elem);
      statusCopy.value = true;
      setTimeout(() => {
        statusCopy.value = false;
      }, 3e3);
    };
    const statusCopy = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(Container, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$1, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-0 md:p-8 relative"${_scopeId2}><div class="bg-white p-14 rounded-lg shadow-md"${_scopeId2}><h2 class="text-2xl font-bold text-center"${_scopeId2}> Panitia Penerimaan Mahasiswa Baru </h2><h3 class="text-xl font-semibold text-center capitalize"${_scopeId2}> Politeknik Sawunggalih Aji ${ssrInterpolate(__props.form.wave.tahun_akademik)}</h3><div class="flex flex-col gap-4 mt-24"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    label: "Nama",
                    value: __props.form.name
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    label: "Email",
                    value: __props.form.email
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    label: "Tempat, Tanggal lahir",
                    value: `${__props.form.birth_place_city}, ${__props.form.birth_date}`
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    label: "Program Studi",
                    value: __props.form.prodi
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    label: "No. Peserta",
                    value: __props.form.no_exam
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    label: "Status",
                    value: __props.form.end_status
                  }, null, _parent3, _scopeId2));
                  _push3(`<div${_scopeId2}><p${_scopeId2}> Berdasarkan hasil penilaian yang telah dilakukan, peserta seleksi yang bernama <b${_scopeId2}>${ssrInterpolate(__props.form.name)}</b> dinyatakan: </p>`);
                  if (__props.form.end_status == "approved") {
                    _push3(`<div${_scopeId2}><p class="text-green font-bold uppercase text-center bg-green-200 p-4 rounded-lg mt-4"${_scopeId2}> Diterima </p><br${_scopeId2}><p${_scopeId2}> Selanjutnya, silahkan melakukan pembayaran <b${_scopeId2}>Registrasi</b> untuk melanjutkan proses registrasi mahasiswa </p><br${_scopeId2}><p${_scopeId2}> Informasi Pembayaran </p><p${_scopeId2}> Lakukan pembayaran sebesar <span class="font-semibold text-blue-700"${_scopeId2}>${ssrInterpolate(new Intl.NumberFormat("id-ID", {
                      style: "currency",
                      currency: "IDR"
                    }).format(props.form.biaya_registrasi))}</span> ke rekening berikut: </p><p class="font-semibold text-lg"${_scopeId2}>${ssrInterpolate(_ctx.$page.props.web_settings.payment_bank)}</p><div class="inline-flex items-center gap-x-3"${_scopeId2}><div class="text-sm font-medium text-gray-800 dark:text-white"${_scopeId2}>${ssrInterpolate(_ctx.$page.props.web_settings.payment_account)}</div><button type="button" class="p-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-white dark:hover:bg-gray-800 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"${_scopeId2}><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="${ssrRenderClass([{
                      "hidden ": statusCopy.value
                    }, "w-4 h-4 group-hover:rotate-6 transition"])}"${_scopeId2}><rect width="8" height="4" x="8" y="2" rx="1" ry="1"${_scopeId2}></rect><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"${_scopeId2}></path></svg><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="${ssrRenderClass([{
                      "block ": statusCopy.value,
                      hidden: !statusCopy.value
                    }, "w-4 h-4 text-blue-600"])}"${_scopeId2}><polyline points="20 6 9 17 4 12"${_scopeId2}></polyline></svg></button></div><p${_scopeId2}>A.n ${ssrInterpolate(_ctx.$page.props.web_settings.payment_name)}</p><p class="mt-4"${_scopeId2}><span class="font-semibold text-base"${_scopeId2}>Kode Pembayaran: </span><span class="font-semibold text-blue-700"${_scopeId2}>${ssrInterpolate(unref(randomNumber))}</span></p><p class="text-red-600 italic"${_scopeId2}>* Pilih Jenis Pembayaran <b${_scopeId2}>Registrasi</b></p></div>`);
                  } else if (__props.form.end_status == "rejected") {
                    _push3(`<div${_scopeId2}><div class="bg-red-200 p-4 rounded-lg mt-4"${_scopeId2}><p class="text-red font-bold uppercase text-center"${_scopeId2}> Ditolak </p></div><div class="mt-4"${_scopeId2}><p${_scopeId2}> Alasan penolakan: ${ssrInterpolate(__props.form.reason_rejected)}</p></div></div>`);
                  } else {
                    _push3(`<div${_scopeId2}><div class="bg-yellow-200 p-4 rounded-lg mt-4"${_scopeId2}><p class="text-yellow font-bold uppercase text-center"${_scopeId2}> Menunggu </p></div><div class="mt-4"${_scopeId2}><p class="text-center font-semibold"${_scopeId2}> sedang menunggu verifikasi panitia </p></div></div>`);
                  }
                  _push3(`</div></div></div>`);
                  if (__props.form.end_status == "submitted") {
                    _push3(`<div class="absolute top-0 left-0 bg-gray-800 text-white p-4 rounded-lg opacity-80 w-full h-full flex justify-center items-center"${_scopeId2}><p class="text-center"${_scopeId2}> Pengumuman belum dapat dikeluarkan karena belum diverifikasi oleh admin. </p></div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-0 md:p-8 relative" }, [
                      createVNode("div", { class: "bg-white p-14 rounded-lg shadow-md" }, [
                        createVNode("h2", { class: "text-2xl font-bold text-center" }, " Panitia Penerimaan Mahasiswa Baru "),
                        createVNode("h3", { class: "text-xl font-semibold text-center capitalize" }, " Politeknik Sawunggalih Aji " + toDisplayString(__props.form.wave.tahun_akademik), 1),
                        createVNode("div", { class: "flex flex-col gap-4 mt-24" }, [
                          createVNode(_sfc_main$2, {
                            label: "Nama",
                            value: __props.form.name
                          }, null, 8, ["value"]),
                          createVNode(_sfc_main$2, {
                            label: "Email",
                            value: __props.form.email
                          }, null, 8, ["value"]),
                          createVNode(_sfc_main$2, {
                            label: "Tempat, Tanggal lahir",
                            value: `${__props.form.birth_place_city}, ${__props.form.birth_date}`
                          }, null, 8, ["value"]),
                          createVNode(_sfc_main$2, {
                            label: "Program Studi",
                            value: __props.form.prodi
                          }, null, 8, ["value"]),
                          createVNode(_sfc_main$2, {
                            label: "No. Peserta",
                            value: __props.form.no_exam
                          }, null, 8, ["value"]),
                          createVNode(_sfc_main$2, {
                            label: "Status",
                            value: __props.form.end_status
                          }, null, 8, ["value"]),
                          createVNode("div", null, [
                            createVNode("p", null, [
                              createTextVNode(" Berdasarkan hasil penilaian yang telah dilakukan, peserta seleksi yang bernama "),
                              createVNode("b", null, toDisplayString(__props.form.name), 1),
                              createTextVNode(" dinyatakan: ")
                            ]),
                            __props.form.end_status == "approved" ? (openBlock(), createBlock("div", { key: 0 }, [
                              createVNode("p", { class: "text-green font-bold uppercase text-center bg-green-200 p-4 rounded-lg mt-4" }, " Diterima "),
                              createVNode("br"),
                              createVNode("p", null, [
                                createTextVNode(" Selanjutnya, silahkan melakukan pembayaran "),
                                createVNode("b", null, "Registrasi"),
                                createTextVNode(" untuk melanjutkan proses registrasi mahasiswa ")
                              ]),
                              createVNode("br"),
                              createVNode("p", null, " Informasi Pembayaran "),
                              createVNode("p", null, [
                                createTextVNode(" Lakukan pembayaran sebesar "),
                                createVNode("span", { class: "font-semibold text-blue-700" }, toDisplayString(new Intl.NumberFormat("id-ID", {
                                  style: "currency",
                                  currency: "IDR"
                                }).format(props.form.biaya_registrasi)), 1),
                                createTextVNode(" ke rekening berikut: ")
                              ]),
                              createVNode("p", { class: "font-semibold text-lg" }, toDisplayString(_ctx.$page.props.web_settings.payment_bank), 1),
                              createVNode("div", { class: "inline-flex items-center gap-x-3" }, [
                                createVNode("div", { class: "text-sm font-medium text-gray-800 dark:text-white" }, toDisplayString(_ctx.$page.props.web_settings.payment_account), 1),
                                createVNode("button", {
                                  type: "button",
                                  class: "p-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-white dark:hover:bg-gray-800 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600",
                                  onClick: ($event) => copyToClipboard(
                                    _ctx.$page.props.web_settings.payment_account
                                  )
                                }, [
                                  (openBlock(), createBlock("svg", {
                                    class: ["w-4 h-4 group-hover:rotate-6 transition", {
                                      "hidden ": statusCopy.value
                                    }],
                                    xmlns: "http://www.w3.org/2000/svg",
                                    width: "24",
                                    height: "24",
                                    viewBox: "0 0 24 24",
                                    fill: "none",
                                    stroke: "currentColor",
                                    "stroke-width": "2",
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round"
                                  }, [
                                    createVNode("rect", {
                                      width: "8",
                                      height: "4",
                                      x: "8",
                                      y: "2",
                                      rx: "1",
                                      ry: "1"
                                    }),
                                    createVNode("path", { d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" })
                                  ], 2)),
                                  (openBlock(), createBlock("svg", {
                                    class: ["w-4 h-4 text-blue-600", {
                                      "block ": statusCopy.value,
                                      hidden: !statusCopy.value
                                    }],
                                    xmlns: "http://www.w3.org/2000/svg",
                                    width: "24",
                                    height: "24",
                                    viewBox: "0 0 24 24",
                                    fill: "none",
                                    stroke: "currentColor",
                                    "stroke-width": "2",
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round"
                                  }, [
                                    createVNode("polyline", { points: "20 6 9 17 4 12" })
                                  ], 2))
                                ], 8, ["onClick"])
                              ]),
                              createVNode("p", null, "A.n " + toDisplayString(_ctx.$page.props.web_settings.payment_name), 1),
                              createVNode("p", { class: "mt-4" }, [
                                createVNode("span", { class: "font-semibold text-base" }, "Kode Pembayaran: "),
                                createVNode("span", { class: "font-semibold text-blue-700" }, toDisplayString(unref(randomNumber)), 1)
                              ]),
                              createVNode("p", { class: "text-red-600 italic" }, [
                                createTextVNode("* Pilih Jenis Pembayaran "),
                                createVNode("b", null, "Registrasi")
                              ])
                            ])) : __props.form.end_status == "rejected" ? (openBlock(), createBlock("div", { key: 1 }, [
                              createVNode("div", { class: "bg-red-200 p-4 rounded-lg mt-4" }, [
                                createVNode("p", { class: "text-red font-bold uppercase text-center" }, " Ditolak ")
                              ]),
                              createVNode("div", { class: "mt-4" }, [
                                createVNode("p", null, " Alasan penolakan: " + toDisplayString(__props.form.reason_rejected), 1)
                              ])
                            ])) : (openBlock(), createBlock("div", { key: 2 }, [
                              createVNode("div", { class: "bg-yellow-200 p-4 rounded-lg mt-4" }, [
                                createVNode("p", { class: "text-yellow font-bold uppercase text-center" }, " Menunggu ")
                              ]),
                              createVNode("div", { class: "mt-4" }, [
                                createVNode("p", { class: "text-center font-semibold" }, " sedang menunggu verifikasi panitia ")
                              ])
                            ]))
                          ])
                        ])
                      ]),
                      __props.form.end_status == "submitted" ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "absolute top-0 left-0 bg-gray-800 text-white p-4 rounded-lg opacity-80 w-full h-full flex justify-center items-center"
                      }, [
                        createVNode("p", { class: "text-center" }, " Pengumuman belum dapat dikeluarkan karena belum diverifikasi oleh admin. ")
                      ])) : createCommentVNode("", true)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$1, null, {
                default: withCtx(() => [
                  createVNode("div", { class: "p-0 md:p-8 relative" }, [
                    createVNode("div", { class: "bg-white p-14 rounded-lg shadow-md" }, [
                      createVNode("h2", { class: "text-2xl font-bold text-center" }, " Panitia Penerimaan Mahasiswa Baru "),
                      createVNode("h3", { class: "text-xl font-semibold text-center capitalize" }, " Politeknik Sawunggalih Aji " + toDisplayString(__props.form.wave.tahun_akademik), 1),
                      createVNode("div", { class: "flex flex-col gap-4 mt-24" }, [
                        createVNode(_sfc_main$2, {
                          label: "Nama",
                          value: __props.form.name
                        }, null, 8, ["value"]),
                        createVNode(_sfc_main$2, {
                          label: "Email",
                          value: __props.form.email
                        }, null, 8, ["value"]),
                        createVNode(_sfc_main$2, {
                          label: "Tempat, Tanggal lahir",
                          value: `${__props.form.birth_place_city}, ${__props.form.birth_date}`
                        }, null, 8, ["value"]),
                        createVNode(_sfc_main$2, {
                          label: "Program Studi",
                          value: __props.form.prodi
                        }, null, 8, ["value"]),
                        createVNode(_sfc_main$2, {
                          label: "No. Peserta",
                          value: __props.form.no_exam
                        }, null, 8, ["value"]),
                        createVNode(_sfc_main$2, {
                          label: "Status",
                          value: __props.form.end_status
                        }, null, 8, ["value"]),
                        createVNode("div", null, [
                          createVNode("p", null, [
                            createTextVNode(" Berdasarkan hasil penilaian yang telah dilakukan, peserta seleksi yang bernama "),
                            createVNode("b", null, toDisplayString(__props.form.name), 1),
                            createTextVNode(" dinyatakan: ")
                          ]),
                          __props.form.end_status == "approved" ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode("p", { class: "text-green font-bold uppercase text-center bg-green-200 p-4 rounded-lg mt-4" }, " Diterima "),
                            createVNode("br"),
                            createVNode("p", null, [
                              createTextVNode(" Selanjutnya, silahkan melakukan pembayaran "),
                              createVNode("b", null, "Registrasi"),
                              createTextVNode(" untuk melanjutkan proses registrasi mahasiswa ")
                            ]),
                            createVNode("br"),
                            createVNode("p", null, " Informasi Pembayaran "),
                            createVNode("p", null, [
                              createTextVNode(" Lakukan pembayaran sebesar "),
                              createVNode("span", { class: "font-semibold text-blue-700" }, toDisplayString(new Intl.NumberFormat("id-ID", {
                                style: "currency",
                                currency: "IDR"
                              }).format(props.form.biaya_registrasi)), 1),
                              createTextVNode(" ke rekening berikut: ")
                            ]),
                            createVNode("p", { class: "font-semibold text-lg" }, toDisplayString(_ctx.$page.props.web_settings.payment_bank), 1),
                            createVNode("div", { class: "inline-flex items-center gap-x-3" }, [
                              createVNode("div", { class: "text-sm font-medium text-gray-800 dark:text-white" }, toDisplayString(_ctx.$page.props.web_settings.payment_account), 1),
                              createVNode("button", {
                                type: "button",
                                class: "p-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-white dark:hover:bg-gray-800 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600",
                                onClick: ($event) => copyToClipboard(
                                  _ctx.$page.props.web_settings.payment_account
                                )
                              }, [
                                (openBlock(), createBlock("svg", {
                                  class: ["w-4 h-4 group-hover:rotate-6 transition", {
                                    "hidden ": statusCopy.value
                                  }],
                                  xmlns: "http://www.w3.org/2000/svg",
                                  width: "24",
                                  height: "24",
                                  viewBox: "0 0 24 24",
                                  fill: "none",
                                  stroke: "currentColor",
                                  "stroke-width": "2",
                                  "stroke-linecap": "round",
                                  "stroke-linejoin": "round"
                                }, [
                                  createVNode("rect", {
                                    width: "8",
                                    height: "4",
                                    x: "8",
                                    y: "2",
                                    rx: "1",
                                    ry: "1"
                                  }),
                                  createVNode("path", { d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" })
                                ], 2)),
                                (openBlock(), createBlock("svg", {
                                  class: ["w-4 h-4 text-blue-600", {
                                    "block ": statusCopy.value,
                                    hidden: !statusCopy.value
                                  }],
                                  xmlns: "http://www.w3.org/2000/svg",
                                  width: "24",
                                  height: "24",
                                  viewBox: "0 0 24 24",
                                  fill: "none",
                                  stroke: "currentColor",
                                  "stroke-width": "2",
                                  "stroke-linecap": "round",
                                  "stroke-linejoin": "round"
                                }, [
                                  createVNode("polyline", { points: "20 6 9 17 4 12" })
                                ], 2))
                              ], 8, ["onClick"])
                            ]),
                            createVNode("p", null, "A.n " + toDisplayString(_ctx.$page.props.web_settings.payment_name), 1),
                            createVNode("p", { class: "mt-4" }, [
                              createVNode("span", { class: "font-semibold text-base" }, "Kode Pembayaran: "),
                              createVNode("span", { class: "font-semibold text-blue-700" }, toDisplayString(unref(randomNumber)), 1)
                            ]),
                            createVNode("p", { class: "text-red-600 italic" }, [
                              createTextVNode("* Pilih Jenis Pembayaran "),
                              createVNode("b", null, "Registrasi")
                            ])
                          ])) : __props.form.end_status == "rejected" ? (openBlock(), createBlock("div", { key: 1 }, [
                            createVNode("div", { class: "bg-red-200 p-4 rounded-lg mt-4" }, [
                              createVNode("p", { class: "text-red font-bold uppercase text-center" }, " Ditolak ")
                            ]),
                            createVNode("div", { class: "mt-4" }, [
                              createVNode("p", null, " Alasan penolakan: " + toDisplayString(__props.form.reason_rejected), 1)
                            ])
                          ])) : (openBlock(), createBlock("div", { key: 2 }, [
                            createVNode("div", { class: "bg-yellow-200 p-4 rounded-lg mt-4" }, [
                              createVNode("p", { class: "text-yellow font-bold uppercase text-center" }, " Menunggu ")
                            ]),
                            createVNode("div", { class: "mt-4" }, [
                              createVNode("p", { class: "text-center font-semibold" }, " sedang menunggu verifikasi panitia ")
                            ])
                          ]))
                        ])
                      ])
                    ]),
                    __props.form.end_status == "submitted" ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "absolute top-0 left-0 bg-gray-800 text-white p-4 rounded-lg opacity-80 w-full h-full flex justify-center items-center"
                    }, [
                      createVNode("p", { class: "text-center" }, " Pengumuman belum dapat dikeluarkan karena belum diverifikasi oleh admin. ")
                    ])) : createCommentVNode("", true)
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Submission/Partials/Determination.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
