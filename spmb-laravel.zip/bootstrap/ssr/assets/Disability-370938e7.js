import { unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$3 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$1 } from "./InputLabel-5e383564.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$2 } from "./Combobox-8f85dcc2.js";
import { usePage, useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$4 } from "./TextareaInput-ea5736c3.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Disability",
  __ssrInlineRender: true,
  props: {
    mustVerifyEmail: {
      type: Boolean
    },
    status: {
      type: String
    }
  },
  setup(__props) {
    const form_data = usePage().props.form;
    const form = useForm({
      is_color_blind: form_data.is_color_blind ? "true" : "false",
      is_disability: form_data.is_disability ? "true" : "false",
      disability_note: form_data.disability_note || ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(_attrs)}><header><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"> Disabilitas </h2><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"> Jika anda memiliki disabilitas, silahkan isi form berikut. </p></header><form class="mt-6 space-y-6"><div class="grid grid-cols-2 gap-4"><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "is_color_blind",
        value: "Buta Warna"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "is_color_blind",
        class: "mt-1 block w-full",
        modelValue: unref(form).is_color_blind,
        "onUpdate:modelValue": ($event) => unref(form).is_color_blind = $event,
        "option-value": [
          { value: "true", text: "Ya" },
          { value: "false", text: "TIdak" }
        ]
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.is_color_blind
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "is_disability",
        value: "Disabilitas"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "is_disability",
        class: "mt-1 block w-full",
        modelValue: unref(form).is_disability,
        "onUpdate:modelValue": ($event) => unref(form).is_disability = $event,
        "option-value": [
          { value: "true", text: "Ya" },
          { value: "false", text: "Tidak" }
        ]
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.is_disability
      }, null, _parent));
      _push(`</div>`);
      if (unref(form).is_disability == "true") {
        _push(`<div class="col-span-2">`);
        _push(ssrRenderComponent(_sfc_main$1, {
          for: "disability_note",
          value: "Keterangan Disabilitas "
        }, null, _parent));
        _push(ssrRenderComponent(_sfc_main$4, {
          id: "disability_note",
          class: "mt-1 block w-full",
          type: "text",
          modelValue: unref(form).disability_note,
          "onUpdate:modelValue": ($event) => unref(form).disability_note = $event
        }, null, _parent));
        _push(ssrRenderComponent(_sfc_main$3, {
          class: "mt-2",
          message: unref(form).errors.disability_note
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="flex justify-end gap-4">`);
      _push(ssrRenderComponent(PrimaryButton, {
        disabled: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Save`);
          } else {
            return [
              createTextVNode("Save")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></form></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Form/Partials/Disability.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
