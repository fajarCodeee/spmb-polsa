import { ssrRenderAttrs, ssrInterpolate, ssrRenderSlot } from "vue/server-renderer";
import { useSSRContext } from "vue";
const _sfc_main = {
  __name: "Display",
  __ssrInlineRender: true,
  props: {
    label: {
      type: String,
      required: true
    },
    value: {
      type: String,
      required: false
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><label class="text-gray-500">${ssrInterpolate(__props.label)}</label>`);
      if (__props.value) {
        _push(`<p class="font-semibold">`);
        if (__props.value) {
          _push(`<span>${ssrInterpolate(__props.value)}</span>`);
        } else {
          _push(`<span>`);
          ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
          _push(`</span>`);
        }
        _push(`</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Display.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
