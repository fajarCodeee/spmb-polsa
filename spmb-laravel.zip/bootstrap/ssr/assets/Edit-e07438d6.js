import { unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { Head } from "@inertiajs/vue3";
import _sfc_main$2 from "./Personal-807972de.js";
import _sfc_main$3 from "./Address-a322c6bf.js";
import _sfc_main$4 from "./Disability-370938e7.js";
import _sfc_main$5 from "./Education-48eb4379.js";
import _sfc_main$6 from "./Parent-04b6cb7c.js";
import "./Affiliate-52ca3c83.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
import "./InputError-83b094c2.js";
import "./InputLabel-5e383564.js";
import "./PrimaryButton-373a10a0.js";
import "./TextInput-f08fe8c3.js";
import "./Combobox-8f85dcc2.js";
import "./DateInput-00587317.js";
import "./TextareaInput-ea5736c3.js";
import "./NumberInput-74774052.js";
const _sfc_main = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    mustVerifyEmail: {
      type: Boolean
    },
    status: {
      type: String
    },
    id: {
      type: String
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Personal Data" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight"${_scopeId}> Form </h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight" }, " Form ")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6"${_scopeId}>`);
            if (__props.id === "personal") {
              _push2(`<div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                "must-verify-email": __props.mustVerifyEmail,
                status: __props.status
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (__props.id === "address") {
              _push2(`<div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$3, {
                "must-verify-email": __props.mustVerifyEmail,
                status: __props.status
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (__props.id === "disability") {
              _push2(`<div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$4, {
                "must-verify-email": __props.mustVerifyEmail,
                status: __props.status
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (__props.id === "education") {
              _push2(`<div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$5, {
                "must-verify-email": __props.mustVerifyEmail,
                status: __props.status
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (__props.id === "parent") {
              _push2(`<div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$6, {
                "must-verify-email": __props.mustVerifyEmail,
                status: __props.status
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (__props.id === "affiliate") {
              _push2(`<div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"${_scopeId}></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6" }, [
                  __props.id === "personal" ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"
                  }, [
                    createVNode(_sfc_main$2, {
                      "must-verify-email": __props.mustVerifyEmail,
                      status: __props.status
                    }, null, 8, ["must-verify-email", "status"])
                  ])) : createCommentVNode("", true),
                  __props.id === "address" ? (openBlock(), createBlock("div", {
                    key: 1,
                    class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"
                  }, [
                    createVNode(_sfc_main$3, {
                      "must-verify-email": __props.mustVerifyEmail,
                      status: __props.status
                    }, null, 8, ["must-verify-email", "status"])
                  ])) : createCommentVNode("", true),
                  __props.id === "disability" ? (openBlock(), createBlock("div", {
                    key: 2,
                    class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"
                  }, [
                    createVNode(_sfc_main$4, {
                      "must-verify-email": __props.mustVerifyEmail,
                      status: __props.status
                    }, null, 8, ["must-verify-email", "status"])
                  ])) : createCommentVNode("", true),
                  __props.id === "education" ? (openBlock(), createBlock("div", {
                    key: 3,
                    class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"
                  }, [
                    createVNode(_sfc_main$5, {
                      "must-verify-email": __props.mustVerifyEmail,
                      status: __props.status
                    }, null, 8, ["must-verify-email", "status"])
                  ])) : createCommentVNode("", true),
                  __props.id === "parent" ? (openBlock(), createBlock("div", {
                    key: 4,
                    class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"
                  }, [
                    createVNode(_sfc_main$6, {
                      "must-verify-email": __props.mustVerifyEmail,
                      status: __props.status
                    }, null, 8, ["must-verify-email", "status"])
                  ])) : createCommentVNode("", true),
                  __props.id === "affiliate" ? (openBlock(), createBlock("div", {
                    key: 5,
                    class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-md sm:shadow-lg sm:rounded-lg"
                  })) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Form/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
