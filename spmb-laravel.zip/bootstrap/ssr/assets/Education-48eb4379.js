import { unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$3 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$1 } from "./InputLabel-5e383564.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$2 } from "./TextInput-f08fe8c3.js";
import { usePage, useForm } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Education",
  __ssrInlineRender: true,
  setup(__props) {
    const from_data = usePage().props.form;
    const form = useForm({
      last_education: from_data.last_education || "",
      education_number: from_data.education_number || "",
      education_name: from_data.education_name || "",
      education_city: from_data.education_city || "",
      education_province: from_data.education_province || "",
      education_subdistrict: from_data.education_subdistrict || "",
      education_country: from_data.education_country || "",
      education_postal_code: `${from_data.education_postal_code || ""}`,
      education_graduation_year: from_data.education_graduation_year || "",
      education_major: from_data.education_major || "",
      education_grade: from_data.education_grade || ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(_attrs)}><header><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"> Pendidikan </h2><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"> Update data pendidikan anda. </p></header><form class="mt-6 space-y-6"><div class="grid grid-cols-2 md:grid-cols-4 gap-4"><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "last_education",
        value: "Pendidikan Terakhir"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "last_education",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).last_education,
        "onUpdate:modelValue": ($event) => unref(form).last_education = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.last_education
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "education_number",
        value: "NISN"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "education_number",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).education_number,
        "onUpdate:modelValue": ($event) => unref(form).education_number = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.education_number
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "education_name",
        value: "Nama Instansi Pendidikan"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "education_name",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).education_name,
        "onUpdate:modelValue": ($event) => unref(form).education_name = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.education_name
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "education_city",
        value: "Kota"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "education_city",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).education_city,
        "onUpdate:modelValue": ($event) => unref(form).education_city = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.education_city
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "education_province",
        value: "Provinsi"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "education_province",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).education_province,
        "onUpdate:modelValue": ($event) => unref(form).education_province = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.education_province
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "education_subdistrict",
        value: "Kecamatan"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "education_subdistrict",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).education_subdistrict,
        "onUpdate:modelValue": ($event) => unref(form).education_subdistrict = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.education_subdistrict
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "education_country",
        value: "Negara"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "education_country",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).education_country,
        "onUpdate:modelValue": ($event) => unref(form).education_country = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.education_country
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "education_postal_code",
        value: "Kode Pos"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "education_postal_code",
        type: "number",
        class: "mt-1 block w-full",
        modelValue: unref(form).education_postal_code,
        "onUpdate:modelValue": ($event) => unref(form).education_postal_code = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.education_postal_code
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "education_graduation_year",
        value: "Tahun Kelulusan"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "education_graduation_year",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).education_graduation_year,
        "onUpdate:modelValue": ($event) => unref(form).education_graduation_year = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.education_graduation_year
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "education_major",
        value: "Jurusan"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "education_major",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).education_major,
        "onUpdate:modelValue": ($event) => unref(form).education_major = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.education_major
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "education_grade",
        value: "Nilai Rata rate Ijazah"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "education_grade",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).education_grade,
        "onUpdate:modelValue": ($event) => unref(form).education_grade = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.education_grade
      }, null, _parent));
      _push(`</div></div><div class="flex justify-end gap-4">`);
      _push(ssrRenderComponent(PrimaryButton, {
        disabled: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Save`);
          } else {
            return [
              createTextVNode("Save")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></form></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Form/Partials/Education.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
