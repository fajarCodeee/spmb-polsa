import { mergeProps, unref, withCtx, createVNode, useSSRContext, ref, onMounted, onBeforeUnmount, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderSlot, ssrRenderStyle, ssrRenderList, ssrRenderClass, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { Link, useForm, usePage, Head } from "@inertiajs/vue3";
import { A as ApplicationLogo } from "./ApplicationLogo-9c97dc09.js";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$3 } from "./SecondaryButton-33aab301.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main$1 = {
  __name: "ExamLayout",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "min-h-screen" }, _attrs))}><nav class="bg-white sticky top-0 shadow-md"><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between"><div class="flex flex-row"><div class="flex-shrink-0 flex items-center gap-3">`);
      _push(ssrRenderComponent(unref(Link), { href: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(ApplicationLogo, { class: "block h-9 w-auto" }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(ApplicationLogo, { class: "block h-9 w-auto" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<h1 class="border-l-2 text-lg inline-flex items-center font-bold text-black px-3 leading-relaxed capitalize">${ssrInterpolate(_ctx.$page.props.web_settings.title_exam)}</h1></div></div></div></nav><main class="p-4 py-10">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</main></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/ExamLayout.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Exams",
  __ssrInlineRender: true,
  props: {
    exam: {
      type: Object,
      required: true
    },
    history: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const options = {
      option_a: "A",
      option_b: "B",
      option_c: "C",
      option_d: "D",
      option_e: "E"
    };
    const countdown = ref("00:00:00");
    const countdownInterval = ref(null);
    const question = ref([]);
    const answer = ref({});
    const posistion = ref(0);
    const timeoutSaveId = ref(null);
    const modalSubmit = ref(false);
    const form = useForm({
      answers: {},
      finish: false
    });
    const changeQuestion = (index) => {
      posistion.value = index;
    };
    const changeAnswer = (index, value) => {
      answer.value[index] = value;
      clearTimeout(timeoutSaveId.value);
      timeoutSaveId.value = setTimeout(() => {
        form.answers = answer.value;
        form.patch(route("exams.knowledge.store", usePage().props.exam.id));
      }, 2e3);
    };
    const submit = () => {
      form.finish = true;
      form.answers = answer.value;
      form.patch(route("exams.knowledge.store", usePage().props.exam.id));
    };
    onMounted(() => {
      var _a;
      const examOrder = JSON.parse(usePage().props.history.order_questions);
      const quest = JSON.parse(JSON.stringify(usePage().props.exam.questions));
      question.value = examOrder.map((id) => quest.find((q) => q.id == id)) || quest;
      if (usePage().props.history.answers)
        answer.value = JSON.parse(usePage().props.history.answers);
      const finishAt = new Date((_a = usePage().props.history) == null ? void 0 : _a.finished_at).getTime();
      countdownInterval.value = setInterval(() => {
        const now = (/* @__PURE__ */ new Date()).getTime();
        const distance = finishAt - now;
        const hours = Math.floor(
          distance % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60)
        );
        const minutes = Math.floor(distance % (1e3 * 60 * 60) / (1e3 * 60));
        const seconds = Math.floor(distance % (1e3 * 60) / 1e3);
        if (distance < 0) {
          clearInterval(countdownInterval.value);
          countdown.value = "00:00:00";
          submit();
          return;
        }
        countdown.value = `${hours}:${minutes}:${seconds}`;
      }, 1e3);
    });
    const backQuestion = () => {
      if (posistion.value > 0)
        posistion.value--;
    };
    const nextQuestion = () => {
      if (posistion.value < question.value.length - 1)
        posistion.value++;
    };
    onBeforeUnmount(() => {
      clearInterval(countdownInterval.value);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: __props.exam.name
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="max-w-7xl mx-auto"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-4 gap-4"${_scopeId}><div class="col-span-1 md:col-span-3"${_scopeId}><div class="bg-white shadow-md rounded-md p-4 h-full"${_scopeId}><div class="flex flex-row justify-between items-center"${_scopeId}><h1 class="text-2xl font-bold text-gray-800"${_scopeId}>${ssrInterpolate(__props.exam.name)}</h1></div><div class="mt-4"${_scopeId}><div style="${ssrRenderStyle({ "user-select": "none" })}"${_scopeId}>${(_a = question.value[posistion.value]) == null ? void 0 : _a.question}</div></div><div class="mt-4"${_scopeId}><div class="grid grid-cols-1 gap-4"${_scopeId}><!--[-->`);
            ssrRenderList(Object.keys(
              options
            ), (value, index) => {
              var _a2, _b2;
              _push2(`<button class="${ssrRenderClass([{
                "bg-gray-200 border border-gray-400": answer.value[(_a2 = question.value[posistion.value]) == null ? void 0 : _a2.id] == options[value]
              }, "p-2 border border-gray-200 rounded-md text-left"])}"${_scopeId}>${ssrInterpolate(options[value])}. ${ssrInterpolate((_b2 = question.value[posistion.value]) == null ? void 0 : _b2[value])}</button>`);
            });
            _push2(`<!--]--></div></div></div></div><div class="col-span-1 order-last md:order-none"${_scopeId}><div class="flex flex-col gap-4"${_scopeId}><div class="bg-white shadow-md rounded-md p-4"${_scopeId}><div class="flex flex-row justify-between items-center"${_scopeId}><h1 class="text-2xl font-bold text-gray-800"${_scopeId}>${ssrInterpolate(__props.exam.name)}</h1></div><div class="mt-4"${_scopeId}><div class="grid grid-cols-5 gap-4"${_scopeId}><!--[-->`);
            ssrRenderList(question.value, (value, index) => {
              _push2(`<button class="${ssrRenderClass([{
                "bg-blue-500 hover:bg-blue-600 text-white": answer.value[value.id] != void 0 && index != posistion.value,
                "bg-gray-300 hover:bg-gray-400": index == posistion.value && answer.value[value.id] == void 0,
                "bg-blue-700 hover:bg-blue-800 text-white ": index == posistion.value
              }, "p-2 border border-gray-200 rounded-md text-center"])}"${_scopeId}>${ssrInterpolate(index + 1)}</button>`);
            });
            _push2(`<!--]--></div></div></div><div class="bg-white shadow-md rounded-md p-4"${_scopeId}><div class="flex flex-row justify-between items-center"${_scopeId}><h1 class="text-2xl font-bold text-gray-800"${_scopeId}> Sisa waktu </h1></div><div class="mt-4 text-center text-2xl font-bold text-gray-800"${_scopeId}>${ssrInterpolate(countdown.value)}</div><div class="mt-4"${_scopeId}><div class="grid grid-cols-1 gap-4"${_scopeId}><button class="${ssrRenderClass([{
              "bg-red-500 hover:bg-red-600": Object.keys(answer.value).length >= question.value.length,
              "bg-gray-400 cursor-not-allowed": Object.keys(answer.value).length < question.value.length
            }, "text-white px-4 py-2 rounded-md"])}"${_scopeId}> Selesai </button></div></div></div></div></div><div class="col-span-1 md:col-span-3"${_scopeId}><div class="flex flex-row items-center justify-between"${_scopeId}><button class="${ssrRenderClass([{
              "bg-blue-500 hover:bg-blue-600": posistion.value > 0,
              "bg-gray-400": posistion.value <= 0
            }, "text-white px-4 py-2 rounded-md"])}"${ssrIncludeBooleanAttr(posistion.value <= 0) ? " disabled" : ""}${_scopeId}><i class="fas fa-arrow-left"${_scopeId}></i> Kembali </button><button class="${ssrRenderClass([{
              "bg-gray-400 cursor-not-allowed": posistion.value >= question.value.length - 1,
              "bg-blue-500 hover:bg-blue-600": posistion.value < question.value.length - 1
            }, "text-white px-4 py-2 rounded-md"])}"${ssrIncludeBooleanAttr(posistion.value >= question.value.length - 1) ? " disabled" : ""}${_scopeId}> Lanjut <i class="fas fa-arrow-right"${_scopeId}></i></button></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: modalSubmit.value,
              onClose: ($event) => modalSubmit.value = false
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="bg-white shadow-md rounded-md p-4"${_scopeId2}><div class="flex flex-row justify-between items-center"${_scopeId2}><h1 class="text-2xl font-bold text-gray-800"${_scopeId2}> Submit jawaban </h1></div><div class="mt-4"${_scopeId2}><p${_scopeId2}> Apakah anda yakin ingin mengumpulkan jawaban anda?, jawaban yang sudah dikumpulkan tidak dapat diubah kembali. </p></div><div class="mt-4"${_scopeId2}><div class="flex justify-end gap-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(PrimaryButton, { onClick: submit }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Submit `);
                      } else {
                        return [
                          createTextVNode(" Submit ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    onClick: ($event) => modalSubmit.value = false
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Batal `);
                      } else {
                        return [
                          createTextVNode(" Batal ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "bg-white shadow-md rounded-md p-4" }, [
                      createVNode("div", { class: "flex flex-row justify-between items-center" }, [
                        createVNode("h1", { class: "text-2xl font-bold text-gray-800" }, " Submit jawaban ")
                      ]),
                      createVNode("div", { class: "mt-4" }, [
                        createVNode("p", null, " Apakah anda yakin ingin mengumpulkan jawaban anda?, jawaban yang sudah dikumpulkan tidak dapat diubah kembali. ")
                      ]),
                      createVNode("div", { class: "mt-4" }, [
                        createVNode("div", { class: "flex justify-end gap-2" }, [
                          createVNode(PrimaryButton, { onClick: submit }, {
                            default: withCtx(() => [
                              createTextVNode(" Submit ")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$3, {
                            onClick: ($event) => modalSubmit.value = false
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Batal ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "max-w-7xl mx-auto" }, [
                createVNode("div", { class: "grid grid-cols-1 md:grid-cols-4 gap-4" }, [
                  createVNode("div", { class: "col-span-1 md:col-span-3" }, [
                    createVNode("div", { class: "bg-white shadow-md rounded-md p-4 h-full" }, [
                      createVNode("div", { class: "flex flex-row justify-between items-center" }, [
                        createVNode("h1", { class: "text-2xl font-bold text-gray-800" }, toDisplayString(__props.exam.name), 1)
                      ]),
                      createVNode("div", { class: "mt-4" }, [
                        createVNode("div", {
                          innerHTML: (_b = question.value[posistion.value]) == null ? void 0 : _b.question,
                          style: { "user-select": "none" }
                        }, null, 8, ["innerHTML"])
                      ]),
                      createVNode("div", { class: "mt-4" }, [
                        createVNode("div", { class: "grid grid-cols-1 gap-4" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(Object.keys(
                            options
                          ), (value, index) => {
                            var _a2, _b2;
                            return openBlock(), createBlock("button", {
                              key: index,
                              class: ["p-2 border border-gray-200 rounded-md text-left", {
                                "bg-gray-200 border border-gray-400": answer.value[(_a2 = question.value[posistion.value]) == null ? void 0 : _a2.id] == options[value]
                              }],
                              onClick: ($event) => changeAnswer(
                                question.value[posistion.value].id,
                                options[value]
                              )
                            }, toDisplayString(options[value]) + ". " + toDisplayString((_b2 = question.value[posistion.value]) == null ? void 0 : _b2[value]), 11, ["onClick"]);
                          }), 128))
                        ])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "col-span-1 order-last md:order-none" }, [
                    createVNode("div", { class: "flex flex-col gap-4" }, [
                      createVNode("div", { class: "bg-white shadow-md rounded-md p-4" }, [
                        createVNode("div", { class: "flex flex-row justify-between items-center" }, [
                          createVNode("h1", { class: "text-2xl font-bold text-gray-800" }, toDisplayString(__props.exam.name), 1)
                        ]),
                        createVNode("div", { class: "mt-4" }, [
                          createVNode("div", { class: "grid grid-cols-5 gap-4" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(question.value, (value, index) => {
                              return openBlock(), createBlock("button", {
                                key: index,
                                class: ["p-2 border border-gray-200 rounded-md text-center", {
                                  "bg-blue-500 hover:bg-blue-600 text-white": answer.value[value.id] != void 0 && index != posistion.value,
                                  "bg-gray-300 hover:bg-gray-400": index == posistion.value && answer.value[value.id] == void 0,
                                  "bg-blue-700 hover:bg-blue-800 text-white ": index == posistion.value
                                }],
                                onClick: ($event) => changeQuestion(index)
                              }, toDisplayString(index + 1), 11, ["onClick"]);
                            }), 128))
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "bg-white shadow-md rounded-md p-4" }, [
                        createVNode("div", { class: "flex flex-row justify-between items-center" }, [
                          createVNode("h1", { class: "text-2xl font-bold text-gray-800" }, " Sisa waktu ")
                        ]),
                        createVNode("div", { class: "mt-4 text-center text-2xl font-bold text-gray-800" }, toDisplayString(countdown.value), 1),
                        createVNode("div", { class: "mt-4" }, [
                          createVNode("div", { class: "grid grid-cols-1 gap-4" }, [
                            createVNode("button", {
                              class: ["text-white px-4 py-2 rounded-md", {
                                "bg-red-500 hover:bg-red-600": Object.keys(answer.value).length >= question.value.length,
                                "bg-gray-400 cursor-not-allowed": Object.keys(answer.value).length < question.value.length
                              }],
                              onClick: ($event) => modalSubmit.value = true
                            }, " Selesai ", 10, ["onClick"])
                          ])
                        ])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "col-span-1 md:col-span-3" }, [
                    createVNode("div", { class: "flex flex-row items-center justify-between" }, [
                      createVNode("button", {
                        class: ["text-white px-4 py-2 rounded-md", {
                          "bg-blue-500 hover:bg-blue-600": posistion.value > 0,
                          "bg-gray-400": posistion.value <= 0
                        }],
                        onClick: backQuestion,
                        disabled: posistion.value <= 0
                      }, [
                        createVNode("i", { class: "fas fa-arrow-left" }),
                        createTextVNode(" Kembali ")
                      ], 10, ["disabled"]),
                      createVNode("button", {
                        class: ["text-white px-4 py-2 rounded-md", {
                          "bg-gray-400 cursor-not-allowed": posistion.value >= question.value.length - 1,
                          "bg-blue-500 hover:bg-blue-600": posistion.value < question.value.length - 1
                        }],
                        onClick: nextQuestion,
                        disabled: posistion.value >= question.value.length - 1
                      }, [
                        createTextVNode(" Lanjut "),
                        createVNode("i", { class: "fas fa-arrow-right" })
                      ], 10, ["disabled"])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: modalSubmit.value,
                  onClose: ($event) => modalSubmit.value = false
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "bg-white shadow-md rounded-md p-4" }, [
                      createVNode("div", { class: "flex flex-row justify-between items-center" }, [
                        createVNode("h1", { class: "text-2xl font-bold text-gray-800" }, " Submit jawaban ")
                      ]),
                      createVNode("div", { class: "mt-4" }, [
                        createVNode("p", null, " Apakah anda yakin ingin mengumpulkan jawaban anda?, jawaban yang sudah dikumpulkan tidak dapat diubah kembali. ")
                      ]),
                      createVNode("div", { class: "mt-4" }, [
                        createVNode("div", { class: "flex justify-end gap-2" }, [
                          createVNode(PrimaryButton, { onClick: submit }, {
                            default: withCtx(() => [
                              createTextVNode(" Submit ")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$3, {
                            onClick: ($event) => modalSubmit.value = false
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Batal ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show", "onClose"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Exams/Knowledge/Exams.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
