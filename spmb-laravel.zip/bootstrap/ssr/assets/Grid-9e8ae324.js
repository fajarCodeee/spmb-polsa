import { computed, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderSlot } from "vue/server-renderer";
const _sfc_main = {
  __name: "Grid",
  __ssrInlineRender: true,
  props: {
    col: {
      type: String,
      default: "1"
    },
    sm: {
      type: String,
      default: null
    },
    md: {
      type: String,
      default: null
    },
    lg: {
      type: String,
      default: null
    },
    xl: {
      type: String,
      default: null
    },
    gap: {
      type: String,
      default: "4"
    }
  },
  setup(__props) {
    const props = __props;
    const className = computed(() => {
      return [
        "grid",
        `grid-cols-${props.col}`,
        props.sm ? `sm:grid-cols-${props.sm}` : "",
        props.md ? `md:grid-cols-${props.md}` : "",
        props.lg ? `lg:grid-cols-${props.lg}` : "",
        props.xl ? `xl:grid-cols-${props.xl}` : "",
        `gap-${props.gap}`
      ];
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: className.value }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Grid.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
