import { ref, withCtx, unref, createTextVNode, createVNode, openBlock, createBlock, toDisplayString, createCommentVNode, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderStyle } from "vue/server-renderer";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$3 } from "./SecondaryButton-33aab301.js";
import { useForm, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { C as Container, _ as _sfc_main$1 } from "./Card-8fb49bd9.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Guide",
  __ssrInlineRender: true,
  props: {
    wave: {
      default: null
    },
    percent: Object,
    status: {
      default: null,
      type: String
    },
    note: {
      default: null,
      type: String
    }
  },
  setup(__props) {
    const modal = ref(false);
    const progressName = {
      personal: "Data Diri",
      address: "Alamat Rumah",
      education: "Pendidikan",
      parent: "Orang Tua",
      document: "Dokumen"
    };
    const form = useForm({});
    const verification = () => {
      form.post(route("form.validation"), {
        preserveScroll: true,
        onFinish: () => {
          modal.value = false;
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(Container, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$1, {
              title: "Pendaftaran",
              description: "Anda sudah mendapatkan akses form pendaftaran tahun ajaran, silahkan melakukan pendaftaran dengan mengisi form pendaftaran."
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="pt-8 flex flex-col gap-5"${_scopeId2}><div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg"${_scopeId2}><h3 class="font-semibold text-gray-900 dark:text-white capitalize text-left text-xl"${_scopeId2}> Panduan Pendaftaran </h3><ol class="relative border-s border-gray-200 dark:border-gray-700"${_scopeId2}><li class="mb-10 ms-4"${_scopeId2}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId2}></div><time class="mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500"${_scopeId2}>Langkah pertama</time><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId2}> Isi data diri </h3><p class="mb-4 text-base font-normal text-gray-500 dark:text-gray-400"${_scopeId2}> Lengkapi data diri anda pada menu `);
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("form.edit", {
                      id: "personal"
                    }),
                    class: "text-blue-600 hover:underline"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`data diri`);
                      } else {
                        return [
                          createTextVNode("data diri")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`, isi sesuai dengan identitas diri anda. </p></li><li class="mb-10 ms-4"${_scopeId2}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId2}></div><time class="mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500"${_scopeId2}>Langkah kedua</time><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId2}> Isi form disabilitas </h3><p class="text-base font-normal text-gray-500 dark:text-gray-400"${_scopeId2}> Lengkapi data kesehatan pada menu `);
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("form.edit", {
                      id: "disability"
                    }),
                    class: "text-blue-600 hover:underline"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`disabilitas`);
                      } else {
                        return [
                          createTextVNode("disabilitas")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`, isi sesuai dengan kondisi disabilitas anda. </p></li><li class="mb-10 ms-4"${_scopeId2}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId2}></div><time class="mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500"${_scopeId2}>Langkah ketiga</time><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId2}> Isi data pendidikan terakhir </h3><p class="text-base font-normal text-gray-500 dark:text-gray-400"${_scopeId2}> Lengkapi data pendidikan terakhir pada menu `);
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("form.edit", {
                      id: "education"
                    }),
                    class: "text-blue-600 hover:underline"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`pendidikan`);
                      } else {
                        return [
                          createTextVNode("pendidikan")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`, isi sesuai dengan data pendidikan terakhir anda. </p></li><li class="ms-4"${_scopeId2}><div class="absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"${_scopeId2}></div><time class="mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500"${_scopeId2}>Langkah keempat</time><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId2}> Isi data orang tua </h3><p class="text-base font-normal text-gray-500 dark:text-gray-400"${_scopeId2}> Lengkapi data orang tua pada menu `);
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("form.edit", {
                      id: "parent"
                    }),
                    class: "text-blue-600 hover:underline"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`orang tua`);
                      } else {
                        return [
                          createTextVNode("orang tua")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`, isi sesuai dengan data orang tua anda. </p></li></ol></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "pt-8 flex flex-col gap-5" }, [
                      createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg" }, [
                        createVNode("h3", { class: "font-semibold text-gray-900 dark:text-white capitalize text-left text-xl" }, " Panduan Pendaftaran "),
                        createVNode("ol", { class: "relative border-s border-gray-200 dark:border-gray-700" }, [
                          createVNode("li", { class: "mb-10 ms-4" }, [
                            createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                            createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah pertama"),
                            createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Isi data diri "),
                            createVNode("p", { class: "mb-4 text-base font-normal text-gray-500 dark:text-gray-400" }, [
                              createTextVNode(" Lengkapi data diri anda pada menu "),
                              createVNode(unref(Link), {
                                href: _ctx.route("form.edit", {
                                  id: "personal"
                                }),
                                class: "text-blue-600 hover:underline"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("data diri")
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createTextVNode(", isi sesuai dengan identitas diri anda. ")
                            ])
                          ]),
                          createVNode("li", { class: "mb-10 ms-4" }, [
                            createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                            createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah kedua"),
                            createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Isi form disabilitas "),
                            createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-400" }, [
                              createTextVNode(" Lengkapi data kesehatan pada menu "),
                              createVNode(unref(Link), {
                                href: _ctx.route("form.edit", {
                                  id: "disability"
                                }),
                                class: "text-blue-600 hover:underline"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("disabilitas")
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createTextVNode(", isi sesuai dengan kondisi disabilitas anda. ")
                            ])
                          ]),
                          createVNode("li", { class: "mb-10 ms-4" }, [
                            createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                            createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah ketiga"),
                            createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Isi data pendidikan terakhir "),
                            createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-400" }, [
                              createTextVNode(" Lengkapi data pendidikan terakhir pada menu "),
                              createVNode(unref(Link), {
                                href: _ctx.route("form.edit", {
                                  id: "education"
                                }),
                                class: "text-blue-600 hover:underline"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("pendidikan")
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createTextVNode(", isi sesuai dengan data pendidikan terakhir anda. ")
                            ])
                          ]),
                          createVNode("li", { class: "ms-4" }, [
                            createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                            createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah keempat"),
                            createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Isi data orang tua "),
                            createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-400" }, [
                              createTextVNode(" Lengkapi data orang tua pada menu "),
                              createVNode(unref(Link), {
                                href: _ctx.route("form.edit", {
                                  id: "parent"
                                }),
                                class: "text-blue-600 hover:underline"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("orang tua")
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createTextVNode(", isi sesuai dengan data orang tua anda. ")
                            ])
                          ])
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$1, {
              title: "Progres Pendaftaran",
              description: "Jika anda sudah mengisi semua data yang dibutuhkan untuk pendaftaran, silahkan mengajukan verifikasi dengan mengklik tombol dibawah ini."
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (__props.status == "rejected" && __props.note) {
                    _push3(`<div class="bg-yellow-50 dark:bg-yellow-800 border-l-4 border-yellow-400 p-4 rounded-lg my-4"${_scopeId2}><h4 class="flex items-center text-lg font-semibold text-yellow-600 dark:text-yellow-400"${_scopeId2}><i class="fa-solid fa-exclamation-triangle text-yellow-400"${_scopeId2}></i><span class="ml-2"${_scopeId2}>Perhatian</span></h4><p class="mt-2 text-sm text-gray-500 dark:text-gray-400"${_scopeId2}>${ssrInterpolate(__props.note)}</p></div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`<div class="pt-8 flex flex-col gap-3"${_scopeId2}><!--[-->`);
                  ssrRenderList(__props.percent, (value, key) => {
                    _push3(`<div${_scopeId2}><div class="mb-2 flex justify-between items-center"${_scopeId2}><h3 class="text-sm font-semibold text-gray-800 dark:text-white capitalize"${_scopeId2}>${ssrInterpolate(progressName[key])}</h3><span class="text-sm text-gray-800 dark:text-white"${_scopeId2}>${ssrInterpolate(value.toFixed(0))}%</span></div><div class="flex w-full h-2 bg-gray-200 rounded-full overflow-hidden dark:bg-gray-700" role="progressbar"${_scopeId2}><div class="flex flex-col justify-center rounded-full overflow-hidden bg-teal-600 text-xs text-white text-center whitespace-nowrap transition duration-500 dark:bg-teal-500" style="${ssrRenderStyle(`width: ${value}%`)}"${_scopeId2}></div></div></div>`);
                  });
                  _push3(`<!--]--></div><div class="flex justify-end gap-4 mt-8"${_scopeId2}>`);
                  _push3(ssrRenderComponent(PrimaryButton, {
                    onClick: ($event) => modal.value = true
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Ajukan Verifikasi`);
                      } else {
                        return [
                          createTextVNode("Ajukan Verifikasi")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    __props.status == "rejected" && __props.note ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "bg-yellow-50 dark:bg-yellow-800 border-l-4 border-yellow-400 p-4 rounded-lg my-4"
                    }, [
                      createVNode("h4", { class: "flex items-center text-lg font-semibold text-yellow-600 dark:text-yellow-400" }, [
                        createVNode("i", { class: "fa-solid fa-exclamation-triangle text-yellow-400" }),
                        createVNode("span", { class: "ml-2" }, "Perhatian")
                      ]),
                      createVNode("p", { class: "mt-2 text-sm text-gray-500 dark:text-gray-400" }, toDisplayString(__props.note), 1)
                    ])) : createCommentVNode("", true),
                    createVNode("div", { class: "pt-8 flex flex-col gap-3" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(__props.percent, (value, key) => {
                        return openBlock(), createBlock("div", { key }, [
                          createVNode("div", { class: "mb-2 flex justify-between items-center" }, [
                            createVNode("h3", { class: "text-sm font-semibold text-gray-800 dark:text-white capitalize" }, toDisplayString(progressName[key]), 1),
                            createVNode("span", { class: "text-sm text-gray-800 dark:text-white" }, toDisplayString(value.toFixed(0)) + "%", 1)
                          ]),
                          createVNode("div", {
                            class: "flex w-full h-2 bg-gray-200 rounded-full overflow-hidden dark:bg-gray-700",
                            role: "progressbar"
                          }, [
                            createVNode("div", {
                              class: "flex flex-col justify-center rounded-full overflow-hidden bg-teal-600 text-xs text-white text-center whitespace-nowrap transition duration-500 dark:bg-teal-500",
                              style: `width: ${value}%`
                            }, null, 4)
                          ])
                        ]);
                      }), 128))
                    ]),
                    createVNode("div", { class: "flex justify-end gap-4 mt-8" }, [
                      createVNode(PrimaryButton, {
                        onClick: ($event) => modal.value = true
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Ajukan Verifikasi")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: modal.value,
              onClose: ($event) => modal.value = false
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h3 class="text-lg font-bold text-gray-900 dark:text-gray-100"${_scopeId2}> Ajukan Verifikasi </h3><p class="text-gray-600 dark:text-gray-400"${_scopeId2}> Sebelum mengajukan verifikasi, pastikan bahwa data yang Anda isi sudah benar dan sesuai dengan data diri Anda. Jika sudah yakin, silakan klik tombol di bawah ini. </p><p class="mt-4 text-red-500 dark:text-red-400 text-sm font-semibold"${_scopeId2}> Harap dicatat bahwa setelah Anda mengumpulkan, Anda tidak akan dapat mengganti data yang sudah diserahkan. </p><div class="flex justify-end gap-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    onClick: ($event) => modal.value = false,
                    class: "ml-2"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` tutup `);
                      } else {
                        return [
                          createTextVNode(" tutup ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(PrimaryButton, { onClick: verification }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Ajukan Verifikasi `);
                      } else {
                        return [
                          createTextVNode(" Ajukan Verifikasi ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h3", { class: "text-lg font-bold text-gray-900 dark:text-gray-100" }, " Ajukan Verifikasi "),
                      createVNode("p", { class: "text-gray-600 dark:text-gray-400" }, " Sebelum mengajukan verifikasi, pastikan bahwa data yang Anda isi sudah benar dan sesuai dengan data diri Anda. Jika sudah yakin, silakan klik tombol di bawah ini. "),
                      createVNode("p", { class: "mt-4 text-red-500 dark:text-red-400 text-sm font-semibold" }, " Harap dicatat bahwa setelah Anda mengumpulkan, Anda tidak akan dapat mengganti data yang sudah diserahkan. "),
                      createVNode("div", { class: "flex justify-end gap-4" }, [
                        createVNode(_sfc_main$3, {
                          onClick: ($event) => modal.value = false,
                          class: "ml-2"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" tutup ")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(PrimaryButton, { onClick: verification }, {
                          default: withCtx(() => [
                            createTextVNode(" Ajukan Verifikasi ")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$1, {
                title: "Pendaftaran",
                description: "Anda sudah mendapatkan akses form pendaftaran tahun ajaran, silahkan melakukan pendaftaran dengan mengisi form pendaftaran."
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "pt-8 flex flex-col gap-5" }, [
                    createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg" }, [
                      createVNode("h3", { class: "font-semibold text-gray-900 dark:text-white capitalize text-left text-xl" }, " Panduan Pendaftaran "),
                      createVNode("ol", { class: "relative border-s border-gray-200 dark:border-gray-700" }, [
                        createVNode("li", { class: "mb-10 ms-4" }, [
                          createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                          createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah pertama"),
                          createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Isi data diri "),
                          createVNode("p", { class: "mb-4 text-base font-normal text-gray-500 dark:text-gray-400" }, [
                            createTextVNode(" Lengkapi data diri anda pada menu "),
                            createVNode(unref(Link), {
                              href: _ctx.route("form.edit", {
                                id: "personal"
                              }),
                              class: "text-blue-600 hover:underline"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("data diri")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createTextVNode(", isi sesuai dengan identitas diri anda. ")
                          ])
                        ]),
                        createVNode("li", { class: "mb-10 ms-4" }, [
                          createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                          createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah kedua"),
                          createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Isi form disabilitas "),
                          createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-400" }, [
                            createTextVNode(" Lengkapi data kesehatan pada menu "),
                            createVNode(unref(Link), {
                              href: _ctx.route("form.edit", {
                                id: "disability"
                              }),
                              class: "text-blue-600 hover:underline"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("disabilitas")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createTextVNode(", isi sesuai dengan kondisi disabilitas anda. ")
                          ])
                        ]),
                        createVNode("li", { class: "mb-10 ms-4" }, [
                          createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                          createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah ketiga"),
                          createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Isi data pendidikan terakhir "),
                          createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-400" }, [
                            createTextVNode(" Lengkapi data pendidikan terakhir pada menu "),
                            createVNode(unref(Link), {
                              href: _ctx.route("form.edit", {
                                id: "education"
                              }),
                              class: "text-blue-600 hover:underline"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("pendidikan")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createTextVNode(", isi sesuai dengan data pendidikan terakhir anda. ")
                          ])
                        ]),
                        createVNode("li", { class: "ms-4" }, [
                          createVNode("div", { class: "absolute w-3 h-3 bg-gray-200 rounded-full mt-1.5 -start-1.5 border border-white dark:border-gray-900 dark:bg-gray-700" }),
                          createVNode("time", { class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500" }, "Langkah keempat"),
                          createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Isi data orang tua "),
                          createVNode("p", { class: "text-base font-normal text-gray-500 dark:text-gray-400" }, [
                            createTextVNode(" Lengkapi data orang tua pada menu "),
                            createVNode(unref(Link), {
                              href: _ctx.route("form.edit", {
                                id: "parent"
                              }),
                              class: "text-blue-600 hover:underline"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("orang tua")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createTextVNode(", isi sesuai dengan data orang tua anda. ")
                          ])
                        ])
                      ])
                    ])
                  ])
                ]),
                _: 1
              }),
              createVNode(_sfc_main$1, {
                title: "Progres Pendaftaran",
                description: "Jika anda sudah mengisi semua data yang dibutuhkan untuk pendaftaran, silahkan mengajukan verifikasi dengan mengklik tombol dibawah ini."
              }, {
                default: withCtx(() => [
                  __props.status == "rejected" && __props.note ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "bg-yellow-50 dark:bg-yellow-800 border-l-4 border-yellow-400 p-4 rounded-lg my-4"
                  }, [
                    createVNode("h4", { class: "flex items-center text-lg font-semibold text-yellow-600 dark:text-yellow-400" }, [
                      createVNode("i", { class: "fa-solid fa-exclamation-triangle text-yellow-400" }),
                      createVNode("span", { class: "ml-2" }, "Perhatian")
                    ]),
                    createVNode("p", { class: "mt-2 text-sm text-gray-500 dark:text-gray-400" }, toDisplayString(__props.note), 1)
                  ])) : createCommentVNode("", true),
                  createVNode("div", { class: "pt-8 flex flex-col gap-3" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.percent, (value, key) => {
                      return openBlock(), createBlock("div", { key }, [
                        createVNode("div", { class: "mb-2 flex justify-between items-center" }, [
                          createVNode("h3", { class: "text-sm font-semibold text-gray-800 dark:text-white capitalize" }, toDisplayString(progressName[key]), 1),
                          createVNode("span", { class: "text-sm text-gray-800 dark:text-white" }, toDisplayString(value.toFixed(0)) + "%", 1)
                        ]),
                        createVNode("div", {
                          class: "flex w-full h-2 bg-gray-200 rounded-full overflow-hidden dark:bg-gray-700",
                          role: "progressbar"
                        }, [
                          createVNode("div", {
                            class: "flex flex-col justify-center rounded-full overflow-hidden bg-teal-600 text-xs text-white text-center whitespace-nowrap transition duration-500 dark:bg-teal-500",
                            style: `width: ${value}%`
                          }, null, 4)
                        ])
                      ]);
                    }), 128))
                  ]),
                  createVNode("div", { class: "flex justify-end gap-4 mt-8" }, [
                    createVNode(PrimaryButton, {
                      onClick: ($event) => modal.value = true
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Ajukan Verifikasi")
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ])
                ]),
                _: 1
              }),
              createVNode(_sfc_main$2, {
                show: modal.value,
                onClose: ($event) => modal.value = false
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "p-6" }, [
                    createVNode("h3", { class: "text-lg font-bold text-gray-900 dark:text-gray-100" }, " Ajukan Verifikasi "),
                    createVNode("p", { class: "text-gray-600 dark:text-gray-400" }, " Sebelum mengajukan verifikasi, pastikan bahwa data yang Anda isi sudah benar dan sesuai dengan data diri Anda. Jika sudah yakin, silakan klik tombol di bawah ini. "),
                    createVNode("p", { class: "mt-4 text-red-500 dark:text-red-400 text-sm font-semibold" }, " Harap dicatat bahwa setelah Anda mengumpulkan, Anda tidak akan dapat mengganti data yang sudah diserahkan. "),
                    createVNode("div", { class: "flex justify-end gap-4" }, [
                      createVNode(_sfc_main$3, {
                        onClick: ($event) => modal.value = false,
                        class: "ml-2"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" tutup ")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(PrimaryButton, { onClick: verification }, {
                        default: withCtx(() => [
                          createTextVNode(" Ajukan Verifikasi ")
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["show", "onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Submission/Partials/Guide.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
