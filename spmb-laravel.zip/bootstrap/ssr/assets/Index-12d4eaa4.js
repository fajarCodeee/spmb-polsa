import { ref, computed, unref, withCtx, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, Fragment, renderList, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { useForm, usePage, Head, router } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { _ as _sfc_main$9 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$4 } from "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$3 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$5 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$8 } from "./NumberInput-74774052.js";
import { _ as _sfc_main$7 } from "./Combobox-8f85dcc2.js";
import { _ as _sfc_main$6 } from "./TextareaInput-ea5736c3.js";
import Multiselect from "@vueform/multiselect";
/* empty css                                                            */import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    exams: Object,
    prodis: Array
  },
  setup(__props) {
    const form = useForm({
      name: "",
      description: "",
      duration: "",
      allowed: [],
      shuffle_question: false,
      shuffle_answer: false,
      show_result: false,
      access_start_time: "",
      access_end_time: "",
      is_active: false
    }).transform((data) => {
      return {
        ...data,
        duration: parseInt(data.duration),
        allowed: JSON.stringify(data.allowed),
        shuffle_question: data.shuffle_question == "true" ? true : false,
        shuffle_answer: data.shuffle_answer == "true" ? true : false,
        show_result: data.show_result == "true" ? true : false,
        is_active: data.is_active == "true" ? true : false
      };
    });
    const dialog = ref(false);
    const dialogIndex = ref(null);
    const dialogItem = ref(null);
    const open = (type, item = null) => {
      dialogItem.value = item;
      dialog.value = true;
      dialogIndex.value = type;
      if (type == 0) {
        form.reset();
      } else if (type == 1) {
        form.name = item.name;
        form.description = item.description;
        form.duration = item.duration;
        form.allowed = JSON.parse(item.allowed);
        form.shuffle_question = item.shuffle_question == 1 ? "true" : "false";
        form.shuffle_answer = item.shuffle_answer == 1 ? "true" : "false";
        form.show_result = item.show_result == 1 ? "true" : "false";
        form.access_start_time = item.access_start_time;
        form.access_end_time = item.access_end_time;
        form.is_active = item.is_active == 1 ? "true" : "false";
      }
    };
    const close = () => {
      dialog.value = false;
      dialogItem.value = null;
      dialogIndex.value = null;
      form.reset();
    };
    const save = () => {
      if (dialogIndex.value == 0) {
        form.post(route("admin.exams.store"), {
          preserveScroll: true,
          onSuccess: () => {
            close();
          }
        });
      } else if (dialogIndex.value == 1) {
        form.patch(route("admin.exams.update", dialogItem.value.id), {
          preserveScroll: true,
          onSuccess: () => {
            close();
          }
        });
      } else {
        form.delete(route("admin.exams.destroy", dialogItem.value.id), {
          preserveScroll: true,
          onSuccess: () => {
            close();
          }
        });
      }
    };
    const navigateTo = (url) => {
      if (url === null)
        return;
      return router.visit(url);
    };
    const prodi = computed(() => {
      return usePage().props.prodis.map((item) => ({
        value: item.id,
        label: item.nama_prodi
      }));
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard Admin" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="bg-white p-4 shadow-md rounded-lg"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-lg font-bold text-gray-900 dark:text-gray-100"${_scopeId}> Kelola Soal Ujian </h2></header>`);
            _push2(ssrRenderComponent(PrimaryButton, {
              onClick: ($event) => open(0)
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` create `);
                } else {
                  return [
                    createTextVNode(" create ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="relative overflow-x-auto shadow-md sm:rounded-lg"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-3 py-3"${_scopeId}>NO</th><th scope="col" class="px-6 py-3 w-1/2"${_scopeId}> Pelajaran </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Soal </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Status </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.exams.data, (exam, index) => {
              var _a, _b;
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><td class="w-4 p-4"${_scopeId}>${ssrInterpolate(index + __props.exams.per_page * (__props.exams.current_page - 1) + 1)}</td><th scope="row" class="flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}><div${_scopeId}><div class="text-base font-semibold"${_scopeId}>${ssrInterpolate(exam.name)}</div><div class="font-normal text-gray-500"${_scopeId}> Durasi: ${ssrInterpolate(exam.duration)} menit </div><div class="font-normal text-gray-500"${_scopeId}> Akses: ${ssrInterpolate(exam.access_start_time)} - ${ssrInterpolate(exam.access_end_time)}</div><div class="font-normal text-gray-500"${_scopeId}> Pengaturan: ${ssrInterpolate(exam.shuffle_question ? "Acak Soal" : "Tidak Acak Soal")} , ${ssrInterpolate(exam.shuffle_answer ? "Acak Jawaban" : "Tidak Acak Jawaban")} , ${ssrInterpolate(exam.show_result ? "Tampilkan Hasil" : "Tidak Tampilkan Hasil")}</div><div class="font-normal text-gray-500"${_scopeId}> Dapat diakses oleh: ${ssrInterpolate(((_a = JSON.parse(exam.allowed)) == null ? void 0 : _a.length) > 0 ? JSON.parse(
                exam.allowed
              ).map((item) => {
                var _a2;
                return (_a2 = prodi.value.find(
                  (prodi2) => prodi2.value == item
                )) == null ? void 0 : _a2.label;
              }).join(", ") : "Tidak ada")}</div><div class="font-normal text-gray-500"${_scopeId}>${ssrInterpolate(((_b = exam.description) == null ? void 0 : _b.length) > 50 ? exam.description.substring(
                0,
                50
              ) + "..." : exam.description || "")}</div></div></th><td class="px-6 py-4 text-center"${_scopeId}>${ssrInterpolate(exam.questions_count)} Soal </td><td class="px-6 py-4"${_scopeId}><div class="flex items-center justify-center"${_scopeId}><span class="${ssrRenderClass([{
                "bg-blue-600 text-white dark:bg-blue-500": exam.is_active,
                "bg-red-600 text-white dark:bg-red-500": !exam.is_active
              }, "inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium"])}"${_scopeId}>${ssrInterpolate(exam.is_active ? "Aktif" : "Tidak Aktif")}</span></div></td><td class="px-6 py-4"${_scopeId}><div class="flex justify-center gap-3"${_scopeId}><button class="text-gray-600 text-md font-medium hover:text-gray-700"${_scopeId}><i class="fas fa-book"${_scopeId}></i></button><button class="text-blue-600 text-md font-medium hover:text-blue-700"${_scopeId}><i class="fas fa-edit"${_scopeId}></i></button><button class="text-red-600 text-md font-medium hover:text-red-700"${_scopeId}><i class="fas fa-trash"${_scopeId}></i></button></div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div><div class="py-1 px-4"${_scopeId}><nav class="flex items-center space-x-1"${_scopeId}><!--[-->`);
            ssrRenderList(__props.exams.links, (link) => {
              _push2(`<button type="button" class="min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10" aria-current="page"${ssrIncludeBooleanAttr(link.active) ? " disabled" : ""}${_scopeId}><span class="truncate"${_scopeId}>${link.label}</span></button>`);
            });
            _push2(`<!--]--></nav></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: dialog.value,
              onClose: ($event) => close()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100"${_scopeId2}>${ssrInterpolate(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete")}</h2>`);
                  if (dialogIndex.value !== 2) {
                    _push3(`<div class="mt-6 grid grid-cols-2 gap-4"${_scopeId2}><div class="col-span-2"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "ujian" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Nama Ujian`);
                        } else {
                          return [
                            createTextVNode("Nama Ujian")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "ujian",
                      modelValue: unref(form).name,
                      "onUpdate:modelValue": ($event) => unref(form).name = $event,
                      class: "mt-1 block w-full",
                      placeholder: "Nama Ujian"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.name,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-2"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "description" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Deskripsi Ujian`);
                        } else {
                          return [
                            createTextVNode("Deskripsi Ujian")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      id: "description",
                      modelValue: unref(form).description,
                      "onUpdate:modelValue": ($event) => unref(form).description = $event,
                      class: "mt-1 block w-full",
                      placeholder: "Deskripsi Ujian"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.description,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-2"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "allowed" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Akses Ujian Ke Prodi`);
                        } else {
                          return [
                            createTextVNode("Akses Ujian Ke Prodi")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(unref(Multiselect), {
                      modelValue: unref(form).allowed,
                      "onUpdate:modelValue": ($event) => unref(form).allowed = $event,
                      options: prodi.value,
                      mode: "multiple",
                      "close-on-select": false,
                      "clear-on-select": false,
                      "preserve-search": true,
                      placeholder: "Pilih Prodi",
                      label: "label",
                      "track-by": "label",
                      "preselect-first": true,
                      "hide-selected": false
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.allowed,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "access_start_time" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Waktu Mulai`);
                        } else {
                          return [
                            createTextVNode("Waktu Mulai")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "access_start_time",
                      modelValue: unref(form).access_start_time,
                      "onUpdate:modelValue": ($event) => unref(form).access_start_time = $event,
                      class: "mt-1 block w-full",
                      placeholder: "Waktu Mulai Cth: 00:00"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.access_start_time,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "access_end_time" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Waktu Selesai`);
                        } else {
                          return [
                            createTextVNode("Waktu Selesai")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "access_end_time",
                      modelValue: unref(form).access_end_time,
                      "onUpdate:modelValue": ($event) => unref(form).access_end_time = $event,
                      class: "mt-1 block w-full",
                      placeholder: "Waktu Selesai Cth: 23:59"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.access_end_time,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "shuffle_question" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Acak Soal`);
                        } else {
                          return [
                            createTextVNode("Acak Soal")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$7, {
                      id: "shuffle_question",
                      modelValue: unref(form).shuffle_question,
                      "onUpdate:modelValue": ($event) => unref(form).shuffle_question = $event,
                      class: "mt-1 block w-full",
                      "option-value": [
                        { value: true, text: "Ya" },
                        { value: false, text: "Tidak" }
                      ]
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.shuffle_question,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "shuffle_answer" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Acak Jawaban`);
                        } else {
                          return [
                            createTextVNode("Acak Jawaban")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$7, {
                      id: "shuffle_answer",
                      modelValue: unref(form).shuffle_answer,
                      "onUpdate:modelValue": ($event) => unref(form).shuffle_answer = $event,
                      class: "mt-1 block w-full",
                      "option-value": [
                        { value: true, text: "Ya" },
                        { value: false, text: "Tidak" }
                      ]
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.shuffle_answer,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "show_result" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Tampilkan Hasil`);
                        } else {
                          return [
                            createTextVNode("Tampilkan Hasil")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$7, {
                      id: "show_result",
                      modelValue: unref(form).show_result,
                      "onUpdate:modelValue": ($event) => unref(form).show_result = $event,
                      class: "mt-1 block w-full",
                      "option-value": [
                        { value: true, text: "Ya" },
                        { value: false, text: "Tidak" }
                      ]
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.show_result,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "duration" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Durasi Ujian / menit`);
                        } else {
                          return [
                            createTextVNode("Durasi Ujian / menit")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$8, {
                      id: "duration",
                      modelValue: unref(form).duration,
                      "onUpdate:modelValue": ($event) => unref(form).duration = $event,
                      class: "mt-1 block w-full",
                      placeholder: "Durasi Ujian Cth: 90",
                      type: "number"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.duration,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-2"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "is_active" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Status`);
                        } else {
                          return [
                            createTextVNode("Status")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$7, {
                      id: "is_active",
                      modelValue: unref(form).is_active,
                      "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                      class: "mt-1 block w-full",
                      "option-value": [
                        { value: true, text: "Aktif" },
                        { value: false, text: "Tidak Aktif" }
                      ]
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.is_active,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  } else {
                    _push3(`<div class="mt-6"${_scopeId2}><p${_scopeId2}> Apakah anda yakin ingin menghapus data ini? Data yang sudah dihapus tidak dapat dikembalikan. </p></div>`);
                  }
                  _push3(`<div class="mt-6"${_scopeId2}><div class="flex justify-end"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$9, {
                    onClick: ($event) => close()
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Cancel `);
                      } else {
                        return [
                          createTextVNode(" Cancel ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(PrimaryButton, {
                    class: "ml-2",
                    onClick: ($event) => save()
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${ssrInterpolate(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete")}`);
                      } else {
                        return [
                          createTextVNode(toDisplayString(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100" }, toDisplayString(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete"), 1),
                      dialogIndex.value !== 2 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-6 grid grid-cols-2 gap-4"
                      }, [
                        createVNode("div", { class: "col-span-2" }, [
                          createVNode(_sfc_main$3, { for: "ujian" }, {
                            default: withCtx(() => [
                              createTextVNode("Nama Ujian")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "ujian",
                            modelValue: unref(form).name,
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Nama Ujian"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.name,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "col-span-2" }, [
                          createVNode(_sfc_main$3, { for: "description" }, {
                            default: withCtx(() => [
                              createTextVNode("Deskripsi Ujian")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$6, {
                            id: "description",
                            modelValue: unref(form).description,
                            "onUpdate:modelValue": ($event) => unref(form).description = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Deskripsi Ujian"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.description,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "col-span-2" }, [
                          createVNode(_sfc_main$3, { for: "allowed" }, {
                            default: withCtx(() => [
                              createTextVNode("Akses Ujian Ke Prodi")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(Multiselect), {
                            modelValue: unref(form).allowed,
                            "onUpdate:modelValue": ($event) => unref(form).allowed = $event,
                            options: prodi.value,
                            mode: "multiple",
                            "close-on-select": false,
                            "clear-on-select": false,
                            "preserve-search": true,
                            placeholder: "Pilih Prodi",
                            label: "label",
                            "track-by": "label",
                            "preselect-first": true,
                            "hide-selected": false
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "options"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.allowed,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "access_start_time" }, {
                            default: withCtx(() => [
                              createTextVNode("Waktu Mulai")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "access_start_time",
                            modelValue: unref(form).access_start_time,
                            "onUpdate:modelValue": ($event) => unref(form).access_start_time = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Waktu Mulai Cth: 00:00"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.access_start_time,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "access_end_time" }, {
                            default: withCtx(() => [
                              createTextVNode("Waktu Selesai")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "access_end_time",
                            modelValue: unref(form).access_end_time,
                            "onUpdate:modelValue": ($event) => unref(form).access_end_time = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Waktu Selesai Cth: 23:59"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.access_end_time,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "shuffle_question" }, {
                            default: withCtx(() => [
                              createTextVNode("Acak Soal")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$7, {
                            id: "shuffle_question",
                            modelValue: unref(form).shuffle_question,
                            "onUpdate:modelValue": ($event) => unref(form).shuffle_question = $event,
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: true, text: "Ya" },
                              { value: false, text: "Tidak" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.shuffle_question,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "shuffle_answer" }, {
                            default: withCtx(() => [
                              createTextVNode("Acak Jawaban")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$7, {
                            id: "shuffle_answer",
                            modelValue: unref(form).shuffle_answer,
                            "onUpdate:modelValue": ($event) => unref(form).shuffle_answer = $event,
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: true, text: "Ya" },
                              { value: false, text: "Tidak" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.shuffle_answer,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "show_result" }, {
                            default: withCtx(() => [
                              createTextVNode("Tampilkan Hasil")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$7, {
                            id: "show_result",
                            modelValue: unref(form).show_result,
                            "onUpdate:modelValue": ($event) => unref(form).show_result = $event,
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: true, text: "Ya" },
                              { value: false, text: "Tidak" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.show_result,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "duration" }, {
                            default: withCtx(() => [
                              createTextVNode("Durasi Ujian / menit")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$8, {
                            id: "duration",
                            modelValue: unref(form).duration,
                            "onUpdate:modelValue": ($event) => unref(form).duration = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Durasi Ujian Cth: 90",
                            type: "number"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.duration,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "col-span-2" }, [
                          createVNode(_sfc_main$3, { for: "is_active" }, {
                            default: withCtx(() => [
                              createTextVNode("Status")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$7, {
                            id: "is_active",
                            modelValue: unref(form).is_active,
                            "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: true, text: "Aktif" },
                              { value: false, text: "Tidak Aktif" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.is_active,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ])) : (openBlock(), createBlock("div", {
                        key: 1,
                        class: "mt-6"
                      }, [
                        createVNode("p", null, " Apakah anda yakin ingin menghapus data ini? Data yang sudah dihapus tidak dapat dikembalikan. ")
                      ])),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode(_sfc_main$9, {
                            onClick: ($event) => close()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(PrimaryButton, {
                            class: "ml-2",
                            onClick: ($event) => save()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete"), 1)
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "bg-white p-4 shadow-md rounded-lg" }, [
                    createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-lg font-bold text-gray-900 dark:text-gray-100" }, " Kelola Soal Ujian ")
                      ]),
                      createVNode(PrimaryButton, {
                        onClick: ($event) => open(0)
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" create ")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-3 py-3"
                            }, "NO"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 w-1/2"
                            }, " Pelajaran "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Soal "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Status "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.exams.data, (exam, index) => {
                            var _a, _b;
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: index
                            }, [
                              createVNode("td", { class: "w-4 p-4" }, toDisplayString(index + __props.exams.per_page * (__props.exams.current_page - 1) + 1), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"
                              }, [
                                createVNode("div", null, [
                                  createVNode("div", { class: "text-base font-semibold" }, toDisplayString(exam.name), 1),
                                  createVNode("div", { class: "font-normal text-gray-500" }, " Durasi: " + toDisplayString(exam.duration) + " menit ", 1),
                                  createVNode("div", { class: "font-normal text-gray-500" }, " Akses: " + toDisplayString(exam.access_start_time) + " - " + toDisplayString(exam.access_end_time), 1),
                                  createVNode("div", { class: "font-normal text-gray-500" }, " Pengaturan: " + toDisplayString(exam.shuffle_question ? "Acak Soal" : "Tidak Acak Soal") + " , " + toDisplayString(exam.shuffle_answer ? "Acak Jawaban" : "Tidak Acak Jawaban") + " , " + toDisplayString(exam.show_result ? "Tampilkan Hasil" : "Tidak Tampilkan Hasil"), 1),
                                  createVNode("div", { class: "font-normal text-gray-500" }, " Dapat diakses oleh: " + toDisplayString(((_a = JSON.parse(exam.allowed)) == null ? void 0 : _a.length) > 0 ? JSON.parse(
                                    exam.allowed
                                  ).map((item) => {
                                    var _a2;
                                    return (_a2 = prodi.value.find(
                                      (prodi2) => prodi2.value == item
                                    )) == null ? void 0 : _a2.label;
                                  }).join(", ") : "Tidak ada"), 1),
                                  createVNode("div", { class: "font-normal text-gray-500" }, toDisplayString(((_b = exam.description) == null ? void 0 : _b.length) > 50 ? exam.description.substring(
                                    0,
                                    50
                                  ) + "..." : exam.description || ""), 1)
                                ])
                              ]),
                              createVNode("td", { class: "px-6 py-4 text-center" }, toDisplayString(exam.questions_count) + " Soal ", 1),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex items-center justify-center" }, [
                                  createVNode("span", {
                                    class: [{
                                      "bg-blue-600 text-white dark:bg-blue-500": exam.is_active,
                                      "bg-red-600 text-white dark:bg-red-500": !exam.is_active
                                    }, "inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium"]
                                  }, toDisplayString(exam.is_active ? "Aktif" : "Tidak Aktif"), 3)
                                ])
                              ]),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex justify-center gap-3" }, [
                                  createVNode("button", {
                                    class: "text-gray-600 text-md font-medium hover:text-gray-700",
                                    onClick: withModifiers(($event) => navigateTo(
                                      _ctx.route(
                                        "admin.exams.questions",
                                        exam.id
                                      )
                                    ), ["prevent"])
                                  }, [
                                    createVNode("i", { class: "fas fa-book" })
                                  ], 8, ["onClick"]),
                                  createVNode("button", {
                                    class: "text-blue-600 text-md font-medium hover:text-blue-700",
                                    onClick: withModifiers(($event) => open(1, exam), ["prevent"])
                                  }, [
                                    createVNode("i", { class: "fas fa-edit" })
                                  ], 8, ["onClick"]),
                                  createVNode("button", {
                                    class: "text-red-600 text-md font-medium hover:text-red-700",
                                    onClick: withModifiers(($event) => open(2, exam), ["prevent"])
                                  }, [
                                    createVNode("i", { class: "fas fa-trash" })
                                  ], 8, ["onClick"])
                                ])
                              ])
                            ]);
                          }), 128))
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "py-1 px-4" }, [
                      createVNode("nav", { class: "flex items-center space-x-1" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.exams.links, (link) => {
                          return openBlock(), createBlock("button", {
                            type: "button",
                            class: "min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10",
                            "aria-current": "page",
                            key: link.label,
                            disabled: link.active,
                            onClick: withModifiers(($event) => navigateTo(link.url || "#"), ["prevent"])
                          }, [
                            createVNode("span", {
                              innerHTML: link.label,
                              class: "truncate"
                            }, null, 8, ["innerHTML"])
                          ], 8, ["disabled", "onClick"]);
                        }), 128))
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: dialog.value,
                  onClose: ($event) => close()
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100" }, toDisplayString(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete"), 1),
                      dialogIndex.value !== 2 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-6 grid grid-cols-2 gap-4"
                      }, [
                        createVNode("div", { class: "col-span-2" }, [
                          createVNode(_sfc_main$3, { for: "ujian" }, {
                            default: withCtx(() => [
                              createTextVNode("Nama Ujian")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "ujian",
                            modelValue: unref(form).name,
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Nama Ujian"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.name,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "col-span-2" }, [
                          createVNode(_sfc_main$3, { for: "description" }, {
                            default: withCtx(() => [
                              createTextVNode("Deskripsi Ujian")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$6, {
                            id: "description",
                            modelValue: unref(form).description,
                            "onUpdate:modelValue": ($event) => unref(form).description = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Deskripsi Ujian"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.description,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "col-span-2" }, [
                          createVNode(_sfc_main$3, { for: "allowed" }, {
                            default: withCtx(() => [
                              createTextVNode("Akses Ujian Ke Prodi")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(Multiselect), {
                            modelValue: unref(form).allowed,
                            "onUpdate:modelValue": ($event) => unref(form).allowed = $event,
                            options: prodi.value,
                            mode: "multiple",
                            "close-on-select": false,
                            "clear-on-select": false,
                            "preserve-search": true,
                            placeholder: "Pilih Prodi",
                            label: "label",
                            "track-by": "label",
                            "preselect-first": true,
                            "hide-selected": false
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "options"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.allowed,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "access_start_time" }, {
                            default: withCtx(() => [
                              createTextVNode("Waktu Mulai")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "access_start_time",
                            modelValue: unref(form).access_start_time,
                            "onUpdate:modelValue": ($event) => unref(form).access_start_time = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Waktu Mulai Cth: 00:00"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.access_start_time,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "access_end_time" }, {
                            default: withCtx(() => [
                              createTextVNode("Waktu Selesai")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "access_end_time",
                            modelValue: unref(form).access_end_time,
                            "onUpdate:modelValue": ($event) => unref(form).access_end_time = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Waktu Selesai Cth: 23:59"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.access_end_time,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "shuffle_question" }, {
                            default: withCtx(() => [
                              createTextVNode("Acak Soal")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$7, {
                            id: "shuffle_question",
                            modelValue: unref(form).shuffle_question,
                            "onUpdate:modelValue": ($event) => unref(form).shuffle_question = $event,
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: true, text: "Ya" },
                              { value: false, text: "Tidak" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.shuffle_question,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "shuffle_answer" }, {
                            default: withCtx(() => [
                              createTextVNode("Acak Jawaban")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$7, {
                            id: "shuffle_answer",
                            modelValue: unref(form).shuffle_answer,
                            "onUpdate:modelValue": ($event) => unref(form).shuffle_answer = $event,
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: true, text: "Ya" },
                              { value: false, text: "Tidak" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.shuffle_answer,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "show_result" }, {
                            default: withCtx(() => [
                              createTextVNode("Tampilkan Hasil")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$7, {
                            id: "show_result",
                            modelValue: unref(form).show_result,
                            "onUpdate:modelValue": ($event) => unref(form).show_result = $event,
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: true, text: "Ya" },
                              { value: false, text: "Tidak" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.show_result,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "duration" }, {
                            default: withCtx(() => [
                              createTextVNode("Durasi Ujian / menit")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$8, {
                            id: "duration",
                            modelValue: unref(form).duration,
                            "onUpdate:modelValue": ($event) => unref(form).duration = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Durasi Ujian Cth: 90",
                            type: "number"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.duration,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "col-span-2" }, [
                          createVNode(_sfc_main$3, { for: "is_active" }, {
                            default: withCtx(() => [
                              createTextVNode("Status")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$7, {
                            id: "is_active",
                            modelValue: unref(form).is_active,
                            "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: true, text: "Aktif" },
                              { value: false, text: "Tidak Aktif" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.is_active,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ])) : (openBlock(), createBlock("div", {
                        key: 1,
                        class: "mt-6"
                      }, [
                        createVNode("p", null, " Apakah anda yakin ingin menghapus data ini? Data yang sudah dihapus tidak dapat dikembalikan. ")
                      ])),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode(_sfc_main$9, {
                            onClick: ($event) => close()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(PrimaryButton, {
                            class: "ml-2",
                            onClick: ($event) => save()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete"), 1)
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show", "onClose"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Exams/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
