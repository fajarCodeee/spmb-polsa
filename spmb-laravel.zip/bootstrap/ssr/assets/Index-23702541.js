import { unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { Head } from "@inertiajs/vue3";
import "./InputError-83b094c2.js";
import "./InputLabel-5e383564.js";
import "./TextInput-f08fe8c3.js";
import "./PrimaryButton-373a10a0.js";
import "./SecondaryButton-33aab301.js";
import "./Combobox-8f85dcc2.js";
import "./Modal-14fa9cf8.js";
import _sfc_main$2 from "./ChooseStudyProgram-d1a69f81.js";
import _sfc_main$3 from "./MakePayment-c936bc20.js";
import _sfc_main$4 from "./Guide-3de2ccec.js";
import _sfc_main$5 from "./Submitted-35a37f4b.js";
import _sfc_main$6 from "./ApprovedForm-2059efe8.js";
import _sfc_main$7 from "./Determination-d363c1be.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
import "./Card-8fb49bd9.js";
import "./Display-b7d04753.js";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    form: {
      default: null,
      type: Object
    },
    percent: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Pendaftaran" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col gap-3"${_scopeId}>`);
            if (!__props.form.prodi && !__props.form.wave) {
              _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
            } else if (__props.form.status && !__props.form.is_paid_registration) {
              _push2(ssrRenderComponent(_sfc_main$3, {
                amount: __props.form.amount,
                wave: __props.form.wave,
                code: __props.form.code
              }, null, _parent2, _scopeId));
            } else if (__props.form.status && (__props.form.status == "waiting" || __props.form.status == "rejected") && __props.form.is_paid_registration) {
              _push2(ssrRenderComponent(_sfc_main$4, {
                wave: __props.form.wave,
                percent: __props.percent,
                status: __props.form.status,
                note: __props.form.note
              }, null, _parent2, _scopeId));
            } else if (__props.form.status == "submitted") {
              _push2(ssrRenderComponent(_sfc_main$5, {
                wave: __props.form.wave
              }, null, _parent2, _scopeId));
            } else if (__props.form.status == "approved" && __props.form.end_status == "pending") {
              _push2(ssrRenderComponent(_sfc_main$6, { form: __props.form }, null, _parent2, _scopeId));
            } else if (__props.form.end_status !== "pending") {
              _push2(ssrRenderComponent(_sfc_main$7, { form: __props.form }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col gap-3" }, [
                !__props.form.prodi && !__props.form.wave ? (openBlock(), createBlock(_sfc_main$2, { key: 0 })) : __props.form.status && !__props.form.is_paid_registration ? (openBlock(), createBlock(_sfc_main$3, {
                  key: 1,
                  amount: __props.form.amount,
                  wave: __props.form.wave,
                  code: __props.form.code
                }, null, 8, ["amount", "wave", "code"])) : __props.form.status && (__props.form.status == "waiting" || __props.form.status == "rejected") && __props.form.is_paid_registration ? (openBlock(), createBlock(_sfc_main$4, {
                  key: 2,
                  wave: __props.form.wave,
                  percent: __props.percent,
                  status: __props.form.status,
                  note: __props.form.note
                }, null, 8, ["wave", "percent", "status", "note"])) : __props.form.status == "submitted" ? (openBlock(), createBlock(_sfc_main$5, {
                  key: 3,
                  wave: __props.form.wave
                }, null, 8, ["wave"])) : __props.form.status == "approved" && __props.form.end_status == "pending" ? (openBlock(), createBlock(_sfc_main$6, {
                  key: 4,
                  form: __props.form
                }, null, 8, ["form"])) : __props.form.end_status !== "pending" ? (openBlock(), createBlock(_sfc_main$7, {
                  key: 5,
                  form: __props.form
                }, null, 8, ["form"])) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Submission/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
