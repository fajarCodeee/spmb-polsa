import { unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, withModifiers, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { Head, router } from "@inertiajs/vue3";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    forms: Object
  },
  setup(__props) {
    const navigateTo = (url) => {
      if (url === null)
        return;
      return router.visit(url);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Validasi Formulir" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="bg-white p-4 sm:p-8 shadow-md sm:shadow-lg rounded-lg"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><h1 class="text-2xl font-semibold"${_scopeId}> Validasi Formulir </h1></div><div class="relative overflow-x-auto shadow-md sm:rounded-lg mt-4"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-3 py-3"${_scopeId}>No</th><th scope="col" class="px-6 py-3"${_scopeId}>Name</th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Pilihan Prodi </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Mengajukan </th><th scope="col" class="px-6 py-3"${_scopeId}> Status </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.forms.data, (form, index) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><td class="w-4 p-4"${_scopeId}>${ssrInterpolate(index + 1 + (__props.forms.current_page - 1) * __props.forms.per_page)}</td><th scope="row" class="flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}><div${_scopeId}><div class="text-base font-semibold"${_scopeId}>${ssrInterpolate(form.user.name)}</div><div class="font-normal text-gray-500"${_scopeId}>${ssrInterpolate(form.user.email)}</div></div></th><td class="px-6 py-4 capitalize truncate text-center"${_scopeId}>${ssrInterpolate(form.option.nama_prodi)}</td><td class="px-6 py-4"${_scopeId}><div class="flex items-center justify-center"${_scopeId}><span class="${ssrRenderClass([{
                "bg-blue-600 text-white dark:bg-blue-500": form.is_submitted,
                "bg-red-600 text-white dark:bg-red-500": !form.is_submitted
              }, "inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium"])}"${_scopeId}>${ssrInterpolate(form.is_submitted ? "Ya" : "Tidak")}</span></div></td><td class="px-6 py-4 uppercase text-xs"${_scopeId}>${ssrInterpolate(form.status)}</td><td class="px-6 py-4"${_scopeId}><div class="flex justify-center"${_scopeId}><button type="button" class="inline-block rounded bg-blue-600 px-4 py-2 text-xs font-medium text-white hover:bg-blue-700"${_scopeId}> View </button></div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table>`);
            if (__props.forms.data.length === 0) {
              _push2(`<div class="flex items-center justify-center p-4"${_scopeId}><p class="text-gray-500 dark:text-gray-400"${_scopeId}> Tidak ada yang perlu divalidasi </p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="py-1 px-4"${_scopeId}><nav class="flex items-center space-x-1"${_scopeId}><!--[-->`);
            ssrRenderList(__props.forms.links, (link) => {
              _push2(`<button type="button" class="min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10" aria-current="page"${ssrIncludeBooleanAttr(link.active || link.url === null) ? " disabled" : ""}${_scopeId}><span class="truncate"${_scopeId}>${link.label}</span></button>`);
            });
            _push2(`<!--]--></nav></div></div></div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "bg-white p-4 sm:p-8 shadow-md sm:shadow-lg rounded-lg" }, [
                    createVNode("div", { class: "flex justify-between items-center" }, [
                      createVNode("h1", { class: "text-2xl font-semibold" }, " Validasi Formulir ")
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg mt-4" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-3 py-3"
                            }, "No"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Name"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Pilihan Prodi "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Mengajukan "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Status "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.forms.data, (form, index) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: form.id
                            }, [
                              createVNode("td", { class: "w-4 p-4" }, toDisplayString(index + 1 + (__props.forms.current_page - 1) * __props.forms.per_page), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"
                              }, [
                                createVNode("div", null, [
                                  createVNode("div", { class: "text-base font-semibold" }, toDisplayString(form.user.name), 1),
                                  createVNode("div", { class: "font-normal text-gray-500" }, toDisplayString(form.user.email), 1)
                                ])
                              ]),
                              createVNode("td", { class: "px-6 py-4 capitalize truncate text-center" }, toDisplayString(form.option.nama_prodi), 1),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex items-center justify-center" }, [
                                  createVNode("span", {
                                    class: [{
                                      "bg-blue-600 text-white dark:bg-blue-500": form.is_submitted,
                                      "bg-red-600 text-white dark:bg-red-500": !form.is_submitted
                                    }, "inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium"]
                                  }, toDisplayString(form.is_submitted ? "Ya" : "Tidak"), 3)
                                ])
                              ]),
                              createVNode("td", { class: "px-6 py-4 uppercase text-xs" }, toDisplayString(form.status), 1),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex justify-center" }, [
                                  createVNode("button", {
                                    type: "button",
                                    class: "inline-block rounded bg-blue-600 px-4 py-2 text-xs font-medium text-white hover:bg-blue-700",
                                    onClick: withModifiers(($event) => navigateTo(
                                      _ctx.route(
                                        "admin.verification.user",
                                        form.id
                                      )
                                    ), ["prevent"])
                                  }, " View ", 8, ["onClick"])
                                ])
                              ])
                            ]);
                          }), 128))
                        ])
                      ]),
                      __props.forms.data.length === 0 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "flex items-center justify-center p-4"
                      }, [
                        createVNode("p", { class: "text-gray-500 dark:text-gray-400" }, " Tidak ada yang perlu divalidasi ")
                      ])) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "py-1 px-4" }, [
                      createVNode("nav", { class: "flex items-center space-x-1" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.forms.links, (link) => {
                          return openBlock(), createBlock("button", {
                            type: "button",
                            class: "min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10",
                            "aria-current": "page",
                            key: link.label,
                            disabled: link.active || link.url === null,
                            onClick: withModifiers(($event) => navigateTo(link.url), ["prevent"])
                          }, [
                            createVNode("span", {
                              innerHTML: link.label,
                              class: "truncate"
                            }, null, 8, ["innerHTML"])
                          ], 8, ["disabled", "onClick"]);
                        }), 128))
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Verification/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
