import { unref, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { Head } from "@inertiajs/vue3";
import "./PrimaryButton-373a10a0.js";
import "./SecondaryButton-33aab301.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    interview: {
      type: Object,
      default: {}
    },
    auth: {
      type: Object,
      default: {}
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Wawancara peserta" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="grid grid-cols-1 gap-4 sm:grid-cols-3 sm:gap-8"${_scopeId}><div class="bg-white dark:bg-gray-800 p-4 sm:p-8 shadow-md rounded-lg sm:shadow-lg col-span-2"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-2xl font-bold text-gray-900 dark:text-gray-100 capitalize"${_scopeId}> Wawancara peserta </h2><p class="text-sm text-gray-400"${_scopeId}> Wawancara peserta adalah tes yang bertujuan untuk mengukur seberapa jauh pengetahuan seseorang terhadap suatu hal. </p></header></div><div class="flex flex-col gap-4"${_scopeId}><div${_scopeId}><div class="capitalize"${_scopeId}> No Peserta : <span class="font-bold text-baase"${_scopeId}>${ssrInterpolate(__props.interview.no_exam)}</span></div><div class="capitalize"${_scopeId}> Nama Peserta : <span class="font-bold text-baase"${_scopeId}>${ssrInterpolate(__props.auth.user.name)}</span></div><div${_scopeId}> Email Peserta : <span class="font-bold text-base"${_scopeId}>${ssrInterpolate(__props.auth.user.email)}</span></div></div><div${_scopeId}><div class="capitalize"${_scopeId}> status wawancara : <span class="${ssrRenderClass([{
              "text-green-500": __props.interview.status === "approved",
              "text-yellow-500": __props.interview.status === "pending",
              "text-red-500": __props.interview.status === "rejected"
            }, "font-bold text-lg uppercase"])}"${_scopeId}>${ssrInterpolate(__props.interview.status)}</span></div>`);
            if (__props.interview.status !== "pending") {
              _push2(`<!--[--><div class="capitalize"${_scopeId}> Tanggal Wawancara : <span class="font-bold text-baase"${_scopeId}>${ssrInterpolate(__props.interview.interview_date)}</span></div><div class="capitalize"${_scopeId}> Di wawancara oleh : <span class="font-bold text-base capitalize"${_scopeId}>${ssrInterpolate(JSON.parse(
                __props.interview.verified_by
              ).name || "")}</span></div><!--]-->`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
            if (__props.interview.status == "rejected" && __props.interview.note) {
              _push2(`<div class="bg-yellow-50 dark:bg-yellow-800 border-l-4 border-yellow-400 p-4 rounded-lg"${_scopeId}><h4 class="flex items-center text-lg font-semibold text-yellow-600 dark:text-yellow-400"${_scopeId}><i class="fa-solid fa-exclamation-triangle text-yellow-400"${_scopeId}></i><span class="ml-2"${_scopeId}>Perhatian</span></h4><p class="mt-2 text-sm text-gray-500 dark:text-gray-400"${_scopeId}>${ssrInterpolate(__props.interview.note)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="bg-white dark:bg-gray-800 p-4 sm:p-8 shadow-md rounded-lg sm:shadow-lg col-span-1"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-lg font-bold text-gray-500 capitalize"${_scopeId}> Panduan Wawancara </h2><p class="text-sm text-gray-400"${_scopeId}> Berikut adalah panduan wawancara yang harus diikuti oleh peserta. </p></header><div class="mt-4"${_scopeId}><div class="text-sm text-gray-400"${_scopeId}><ul class="list-disc list-inside text-gray-400"${_scopeId}><li${_scopeId}> Peserta wajib mengikuti wawancara sesuai dengan jadwal yang telah ditentukan. </li><li${_scopeId}> Peserta wajib mengikuti wawancara dengan sopan dan santun. </li><li${_scopeId}> Peserta wajib mengikuti wawancara dengan penuh kejujuran. </li></ul></div></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "grid grid-cols-1 gap-4 sm:grid-cols-3 sm:gap-8" }, [
                    createVNode("div", { class: "bg-white dark:bg-gray-800 p-4 sm:p-8 shadow-md rounded-lg sm:shadow-lg col-span-2" }, [
                      createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4" }, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100 capitalize" }, " Wawancara peserta "),
                          createVNode("p", { class: "text-sm text-gray-400" }, " Wawancara peserta adalah tes yang bertujuan untuk mengukur seberapa jauh pengetahuan seseorang terhadap suatu hal. ")
                        ])
                      ]),
                      createVNode("div", { class: "flex flex-col gap-4" }, [
                        createVNode("div", null, [
                          createVNode("div", { class: "capitalize" }, [
                            createTextVNode(" No Peserta : "),
                            createVNode("span", { class: "font-bold text-baase" }, toDisplayString(__props.interview.no_exam), 1)
                          ]),
                          createVNode("div", { class: "capitalize" }, [
                            createTextVNode(" Nama Peserta : "),
                            createVNode("span", { class: "font-bold text-baase" }, toDisplayString(__props.auth.user.name), 1)
                          ]),
                          createVNode("div", null, [
                            createTextVNode(" Email Peserta : "),
                            createVNode("span", { class: "font-bold text-base" }, toDisplayString(__props.auth.user.email), 1)
                          ])
                        ]),
                        createVNode("div", null, [
                          createVNode("div", { class: "capitalize" }, [
                            createTextVNode(" status wawancara : "),
                            createVNode("span", {
                              class: [{
                                "text-green-500": __props.interview.status === "approved",
                                "text-yellow-500": __props.interview.status === "pending",
                                "text-red-500": __props.interview.status === "rejected"
                              }, "font-bold text-lg uppercase"]
                            }, toDisplayString(__props.interview.status), 3)
                          ]),
                          __props.interview.status !== "pending" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                            createVNode("div", { class: "capitalize" }, [
                              createTextVNode(" Tanggal Wawancara : "),
                              createVNode("span", { class: "font-bold text-baase" }, toDisplayString(__props.interview.interview_date), 1)
                            ]),
                            createVNode("div", { class: "capitalize" }, [
                              createTextVNode(" Di wawancara oleh : "),
                              createVNode("span", { class: "font-bold text-base capitalize" }, toDisplayString(JSON.parse(
                                __props.interview.verified_by
                              ).name || ""), 1)
                            ])
                          ], 64)) : createCommentVNode("", true)
                        ]),
                        __props.interview.status == "rejected" && __props.interview.note ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "bg-yellow-50 dark:bg-yellow-800 border-l-4 border-yellow-400 p-4 rounded-lg"
                        }, [
                          createVNode("h4", { class: "flex items-center text-lg font-semibold text-yellow-600 dark:text-yellow-400" }, [
                            createVNode("i", { class: "fa-solid fa-exclamation-triangle text-yellow-400" }),
                            createVNode("span", { class: "ml-2" }, "Perhatian")
                          ]),
                          createVNode("p", { class: "mt-2 text-sm text-gray-500 dark:text-gray-400" }, toDisplayString(__props.interview.note), 1)
                        ])) : createCommentVNode("", true)
                      ])
                    ]),
                    createVNode("div", { class: "bg-white dark:bg-gray-800 p-4 sm:p-8 shadow-md rounded-lg sm:shadow-lg col-span-1" }, [
                      createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4" }, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "text-lg font-bold text-gray-500 capitalize" }, " Panduan Wawancara "),
                          createVNode("p", { class: "text-sm text-gray-400" }, " Berikut adalah panduan wawancara yang harus diikuti oleh peserta. ")
                        ]),
                        createVNode("div", { class: "mt-4" }, [
                          createVNode("div", { class: "text-sm text-gray-400" }, [
                            createVNode("ul", { class: "list-disc list-inside text-gray-400" }, [
                              createVNode("li", null, " Peserta wajib mengikuti wawancara sesuai dengan jadwal yang telah ditentukan. "),
                              createVNode("li", null, " Peserta wajib mengikuti wawancara dengan sopan dan santun. "),
                              createVNode("li", null, " Peserta wajib mengikuti wawancara dengan penuh kejujuran. ")
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Exams/Interview/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
