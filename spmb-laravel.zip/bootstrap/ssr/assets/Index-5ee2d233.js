import { ref, unref, withCtx, createTextVNode, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { useForm, Head } from "@inertiajs/vue3";
import "./TextInput-f08fe8c3.js";
import "./NumberInput-74774052.js";
import "./InputError-83b094c2.js";
import "./InputLabel-5e383564.js";
import "./Combobox-8f85dcc2.js";
import "./TextareaInput-ea5736c3.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$3 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    ujian: Array,
    perlu_ujian: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const confirmStartExam = ref(false);
    const form = useForm({});
    const items = ref(null);
    const checkTime = (exam) => {
      const now = /* @__PURE__ */ new Date();
      const startTime = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate(),
        exam.access_start_time.split(":")[0],
        exam.access_start_time.split(":")[1]
      );
      const endTime = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate(),
        exam.access_end_time.split(":")[0],
        exam.access_end_time.split(":")[1]
      );
      return now >= startTime && now <= endTime;
    };
    const open = (exam) => {
      confirmStartExam.value = true;
      items.value = exam;
    };
    const start = (exam) => {
      confirmStartExam.value = true;
      form.post(route("exams.knowledge.start", exam.id), {
        preserveScroll: true,
        onSuccess: () => {
        }
      });
    };
    const close = () => {
      confirmStartExam.value = false;
      items.value = null;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Tes Pengetahuan" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="bg-white dark:bg-gray-800 p-4 sm:p-8 shadow-md rounded-lg sm:shadow-lg"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-2xl font-bold text-gray-900 dark:text-gray-100 capitalize"${_scopeId}> Tes Pengetahuan </h2><p class="text-sm text-gray-400"${_scopeId}> Tes pengetahuan adalah tes yang bertujuan untuk mengukur seberapa jauh pengetahuan seseorang terhadap suatu hal. </p></header></div><div class="relative overflow-x-auto shadow-md sm:rounded-lg"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-3 py-3"${_scopeId}>NO</th><th scope="col" class="px-6 py-3 w-1/2"${_scopeId}> Pelajaran </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Status </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.ujian, (exam, index) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><td class="w-4 p-4"${_scopeId}>${ssrInterpolate(index + 1)}</td><th scope="row" class="flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}><div${_scopeId}><div class="text-sm font-medium"${_scopeId}>${ssrInterpolate(exam.name)}</div><div class="text-sm text-gray-500"${_scopeId}>${ssrInterpolate(exam.description)}</div><div class="text-xs text-gray-500"${_scopeId}> jumlah soal: ${ssrInterpolate(exam.questions_count)}</div><div class="text-xs text-gray-500"${_scopeId}> waktu: ${ssrInterpolate(exam.duration)} menit </div><div class="text-xs text-gray-500"${_scopeId}> waktu akses: ${ssrInterpolate(exam.access_start_time)} - ${ssrInterpolate(exam.access_end_time)}</div>`);
              if (exam.score) {
                _push2(`<div class="text-xs text-gray-500"${_scopeId}> Nilai: ${ssrInterpolate(exam.score)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></th><td class="px-6 py-4"${_scopeId}><div class="flex items-center justify-center"${_scopeId}><span class="${ssrRenderClass([{
                "bg-blue-600 text-white dark:bg-blue-500": exam.is_end,
                "bg-red-600 text-white dark:bg-red-500": !exam.is_end
              }, "inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium whitespace-nowrap"])}"${_scopeId}>${ssrInterpolate(exam.is_end ? "SELESAI" : "BELUM DI KERJAKAN")}</span></div></td><td class="px-6 py-4"${_scopeId}><div class="flex justify-center gap-3"${_scopeId}><button${ssrIncludeBooleanAttr(
                !checkTime(exam) || !exam.can_start
              ) ? " disabled" : ""} class="${ssrRenderClass([{
                "bg-blue-600 hover:bg-blue-700": checkTime(exam) && exam.can_start,
                "bg-gray-400 cursor-not-allowed": !checkTime(exam) || !exam.can_start
              }, "inline-block rounded px-4 py-2 text-xs font-medium text-white whitespace-nowrap"])}"${_scopeId}>${ssrInterpolate(exam.is_end ? "SELESAI" : checkTime(exam) ? "MULAI" : "BELUM WAKTU")}</button></div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div>`);
            if (__props.ujian.length === 0) {
              _push2(`<div class="flex items-center justify-center p-4"${_scopeId}>`);
              if (!__props.perlu_ujian) {
                _push2(`<p class="text-gray-500 dark:text-gray-400"${_scopeId}> Anda merupakan siswa berprestasi, tidak perlu mengerjakan ujian </p>`);
              } else {
                _push2(`<p class="text-gray-500 dark:text-gray-400"${_scopeId}> Tidak ada ujian yang perlu dikerjakan </p>`);
              }
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: confirmStartExam.value,
              onClose: ($event) => close()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-xl font-medium text-gray-900 dark:text-gray-100"${_scopeId2}> Konfirmasi Mulai Tes </h2><p class="mt-2 text-sm text-gray-500 dark:text-gray-400"${_scopeId2}> Apakah anda yakin ingin memulai tes ini? </p><div class="mt-4 flex justify-end gap-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(PrimaryButton, {
                    onClick: ($event) => start(items.value)
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Mulai `);
                      } else {
                        return [
                          createTextVNode(" Mulai ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    onClick: ($event) => close()
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Batal `);
                      } else {
                        return [
                          createTextVNode(" Batal ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-xl font-medium text-gray-900 dark:text-gray-100" }, " Konfirmasi Mulai Tes "),
                      createVNode("p", { class: "mt-2 text-sm text-gray-500 dark:text-gray-400" }, " Apakah anda yakin ingin memulai tes ini? "),
                      createVNode("div", { class: "mt-4 flex justify-end gap-2" }, [
                        createVNode(PrimaryButton, {
                          onClick: ($event) => start(items.value)
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Mulai ")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_sfc_main$3, {
                          onClick: ($event) => close()
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Batal ")
                          ]),
                          _: 1
                        }, 8, ["onClick"])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "bg-white dark:bg-gray-800 p-4 sm:p-8 shadow-md rounded-lg sm:shadow-lg" }, [
                    createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100 capitalize" }, " Tes Pengetahuan "),
                        createVNode("p", { class: "text-sm text-gray-400" }, " Tes pengetahuan adalah tes yang bertujuan untuk mengukur seberapa jauh pengetahuan seseorang terhadap suatu hal. ")
                      ])
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-3 py-3"
                            }, "NO"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 w-1/2"
                            }, " Pelajaran "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Status "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.ujian, (exam, index) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: index
                            }, [
                              createVNode("td", { class: "w-4 p-4" }, toDisplayString(index + 1), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"
                              }, [
                                createVNode("div", null, [
                                  createVNode("div", { class: "text-sm font-medium" }, toDisplayString(exam.name), 1),
                                  createVNode("div", { class: "text-sm text-gray-500" }, toDisplayString(exam.description), 1),
                                  createVNode("div", { class: "text-xs text-gray-500" }, " jumlah soal: " + toDisplayString(exam.questions_count), 1),
                                  createVNode("div", { class: "text-xs text-gray-500" }, " waktu: " + toDisplayString(exam.duration) + " menit ", 1),
                                  createVNode("div", { class: "text-xs text-gray-500" }, " waktu akses: " + toDisplayString(exam.access_start_time) + " - " + toDisplayString(exam.access_end_time), 1),
                                  exam.score ? (openBlock(), createBlock("div", {
                                    key: 0,
                                    class: "text-xs text-gray-500"
                                  }, " Nilai: " + toDisplayString(exam.score), 1)) : createCommentVNode("", true)
                                ])
                              ]),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex items-center justify-center" }, [
                                  createVNode("span", {
                                    class: [{
                                      "bg-blue-600 text-white dark:bg-blue-500": exam.is_end,
                                      "bg-red-600 text-white dark:bg-red-500": !exam.is_end
                                    }, "inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium whitespace-nowrap"]
                                  }, toDisplayString(exam.is_end ? "SELESAI" : "BELUM DI KERJAKAN"), 3)
                                ])
                              ]),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex justify-center gap-3" }, [
                                  createVNode("button", {
                                    class: ["inline-block rounded px-4 py-2 text-xs font-medium text-white whitespace-nowrap", {
                                      "bg-blue-600 hover:bg-blue-700": checkTime(exam) && exam.can_start,
                                      "bg-gray-400 cursor-not-allowed": !checkTime(exam) || !exam.can_start
                                    }],
                                    disabled: !checkTime(exam) || !exam.can_start,
                                    onClick: ($event) => checkTime(exam) ? open(exam) : null
                                  }, toDisplayString(exam.is_end ? "SELESAI" : checkTime(exam) ? "MULAI" : "BELUM WAKTU"), 11, ["disabled", "onClick"])
                                ])
                              ])
                            ]);
                          }), 128))
                        ])
                      ])
                    ]),
                    __props.ujian.length === 0 ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "flex items-center justify-center p-4"
                    }, [
                      !__props.perlu_ujian ? (openBlock(), createBlock("p", {
                        key: 0,
                        class: "text-gray-500 dark:text-gray-400"
                      }, " Anda merupakan siswa berprestasi, tidak perlu mengerjakan ujian ")) : (openBlock(), createBlock("p", {
                        key: 1,
                        class: "text-gray-500 dark:text-gray-400"
                      }, " Tidak ada ujian yang perlu dikerjakan "))
                    ])) : createCommentVNode("", true)
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: confirmStartExam.value,
                  onClose: ($event) => close()
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-xl font-medium text-gray-900 dark:text-gray-100" }, " Konfirmasi Mulai Tes "),
                      createVNode("p", { class: "mt-2 text-sm text-gray-500 dark:text-gray-400" }, " Apakah anda yakin ingin memulai tes ini? "),
                      createVNode("div", { class: "mt-4 flex justify-end gap-2" }, [
                        createVNode(PrimaryButton, {
                          onClick: ($event) => start(items.value)
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Mulai ")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_sfc_main$3, {
                          onClick: ($event) => close()
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Batal ")
                          ]),
                          _: 1
                        }, 8, ["onClick"])
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show", "onClose"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Exams/Knowledge/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
