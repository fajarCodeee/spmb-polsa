import { ref, unref, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { _ as _sfc_main$3, a as _sfc_main$4 } from "./Table-18dc0020.js";
import { C as Container, _ as _sfc_main$2 } from "./Card-8fb49bd9.js";
import { _ as _sfc_main$5 } from "./Modal-14fa9cf8.js";
import "./PrimaryButton-373a10a0.js";
import "./SecondaryButton-33aab301.js";
import { Head } from "@inertiajs/vue3";
import _sfc_main$6 from "./ModalView-4abe9cef.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
import "./TextareaInput-ea5736c3.js";
import "./InputLabel-5e383564.js";
import "./Display-b7d04753.js";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    forms: Object
  },
  setup(__props) {
    const item = ref({});
    const modal = ref(false);
    const open = (i) => {
      fetch(route("admin.end-validation.show", i.id)).then((res) => res.json()).then((data) => {
        console.log(data);
        item.value = data.data;
        modal.value = true;
      });
    };
    const close = () => {
      modal.value = false;
      item.value = {};
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Penentuan Kelulusan" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(Container, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    title: "Penentuan Kelulusan",
                    description: " Penentuan Kelulusan"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="flex flex-col gap-4"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_sfc_main$3, {
                          forms: __props.forms,
                          open
                        }, null, _parent4, _scopeId3));
                        _push4(`<div class="flex items-center justify-center"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_sfc_main$4, {
                          pages: __props.forms.links,
                          type: "visit"
                        }, null, _parent4, _scopeId3));
                        _push4(`</div></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "flex flex-col gap-4" }, [
                            createVNode(_sfc_main$3, {
                              forms: __props.forms,
                              open
                            }, null, 8, ["forms"]),
                            createVNode("div", { class: "flex items-center justify-center" }, [
                              createVNode(_sfc_main$4, {
                                pages: __props.forms.links,
                                type: "visit"
                              }, null, 8, ["pages"])
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_sfc_main$2, {
                      title: "Penentuan Kelulusan",
                      description: " Penentuan Kelulusan"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "flex flex-col gap-4" }, [
                          createVNode(_sfc_main$3, {
                            forms: __props.forms,
                            open
                          }, null, 8, ["forms"]),
                          createVNode("div", { class: "flex items-center justify-center" }, [
                            createVNode(_sfc_main$4, {
                              pages: __props.forms.links,
                              type: "visit"
                            }, null, 8, ["pages"])
                          ])
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              show: modal.value,
              onClose: close
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_sfc_main$6, {
                    item: item.value,
                    close
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_sfc_main$6, {
                      item: item.value,
                      close
                    }, null, 8, ["item"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode(Container, null, {
                  default: withCtx(() => [
                    createVNode(_sfc_main$2, {
                      title: "Penentuan Kelulusan",
                      description: " Penentuan Kelulusan"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "flex flex-col gap-4" }, [
                          createVNode(_sfc_main$3, {
                            forms: __props.forms,
                            open
                          }, null, 8, ["forms"]),
                          createVNode("div", { class: "flex items-center justify-center" }, [
                            createVNode(_sfc_main$4, {
                              pages: __props.forms.links,
                              type: "visit"
                            }, null, 8, ["pages"])
                          ])
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_sfc_main$5, {
                  show: modal.value,
                  onClose: close
                }, {
                  default: withCtx(() => [
                    createVNode(_sfc_main$6, {
                      item: item.value,
                      close
                    }, null, 8, ["item"])
                  ]),
                  _: 1
                }, 8, ["show"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Verification/End/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
