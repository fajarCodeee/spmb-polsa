import { ref, unref, withCtx, createTextVNode, createVNode, openBlock, createBlock, Fragment, toDisplayString, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$6 } from "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$3 } from "./NumberInput-74774052.js";
import { _ as _sfc_main$4 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$2 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$5 } from "./Combobox-8f85dcc2.js";
import { _ as _sfc_main$7 } from "./TextareaInput-ea5736c3.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$9 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$8 } from "./Modal-14fa9cf8.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    user: {
      type: Object,
      default: () => {
      }
    },
    image: String
  },
  setup(__props) {
    const form_data = usePage().props.user;
    const form = useForm({
      height: form_data.height || ``,
      weight: form_data.weight || ``,
      blood_type: form_data.blood_type || "",
      blood_pressure: form_data.blood_pressure || "",
      blood_sugar: form_data.blood_sugar || "",
      is_smoking: form_data.is_smoking == 1 ? true : false,
      color_blind: form_data.color_blind == 1 ? true : false,
      is_disability: form_data.is_disability == 1 ? true : false,
      note: form_data.note || ``,
      image: null
    }).transform((data) => ({
      ...data,
      height: data.height ? parseInt(data.height) : null,
      weight: data.weight ? parseInt(data.weight) : null,
      is_smoking: data.is_smoking ? true : false,
      color_blind: data.color_blind ? true : false,
      is_disability: data.is_disability ? true : false
    }));
    const modal = ref(false);
    const open = () => {
      modal.value = true;
    };
    const close = () => {
      modal.value = false;
    };
    const save = () => {
      form.post(route("exams.health.update"), {
        preserveScroll: true,
        onFinish: () => {
          close();
        },
        onSuccess: () => {
          close();
        }
      });
    };
    const url = ref(null);
    const onFileChange = (e) => {
      form.image = e.target.files[0];
      if (form.image) {
        url.value = URL.createObjectURL(form.image);
      } else {
        url.value = null;
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Pemeriksaan Kesehatan" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="bg-white dark:bg-gray-800 p-4 sm:p-8 shadow-md rounded-lg sm:shadow-lg"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-2xl font-bold text-gray-900 dark:text-gray-100 capitalize"${_scopeId}> Tes Kesehatan </h2><p class="text-sm text-gray-400"${_scopeId}> Pemeriksaan kesehatan calon mahasiswa baru </p></header></div>`);
            if (__props.user.status !== "submitted" && __props.user.status !== "approved") {
              _push2(`<!--[-->`);
              if (__props.user.status === "rejected" && __props.user.admin_note) {
                _push2(`<div class="bg-yellow-50 dark:bg-yellow-800 border-l-4 border-yellow-400 p-4 rounded-lg"${_scopeId}><h4 class="flex items-center text-lg font-semibold text-yellow-600 dark:text-yellow-400"${_scopeId}><i class="fa-solid fa-exclamation-triangle text-yellow-400"${_scopeId}></i><span class="ml-2"${_scopeId}>Perhatian</span></h4><p class="mt-2 text-sm text-gray-500 dark:text-gray-400"${_scopeId}>${ssrInterpolate(__props.user.admin_note)}</p></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<form class="mt-6 grid grid-cols-1 gap-y-6 md:grid-cols-4 md:gap-x-8"${_scopeId}><div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "height",
                value: "Tinggi Badan"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$3, {
                id: "height",
                class: "mt-1 block w-full",
                modelValue: unref(form).height,
                "onUpdate:modelValue": ($event) => unref(form).height = $event
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$4, {
                class: "mt-2",
                message: unref(form).errors.height
              }, null, _parent2, _scopeId));
              _push2(`<p class="mt-2 text-sm text-gray-400"${_scopeId}> Satuan dalam sentimeter (cm) </p></div><div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "weight",
                value: "Berat Badan"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$3, {
                id: "weight",
                class: "mt-1 block w-full",
                modelValue: unref(form).weight,
                "onUpdate:modelValue": ($event) => unref(form).weight = $event
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$4, {
                class: "mt-2",
                message: unref(form).errors.weight
              }, null, _parent2, _scopeId));
              _push2(`<p class="mt-2 text-sm text-gray-400"${_scopeId}> Satuan dalam kilogram (kg) </p></div><div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "blood_type",
                value: "Gol. Darah"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$5, {
                id: "blood_type",
                class: "mt-1 block w-full",
                modelValue: unref(form).blood_type,
                "onUpdate:modelValue": ($event) => unref(form).blood_type = $event,
                autocomplete: "blood_type",
                "option-value": [
                  { value: "A", text: "A" },
                  { value: "B", text: "B" },
                  { value: "AB", text: "AB" },
                  { value: "O", text: "O" },
                  { value: "", text: "Silahkan Pilih" }
                ]
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$4, {
                class: "mt-2",
                message: unref(form).errors.blood_type
              }, null, _parent2, _scopeId));
              _push2(`</div><div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "blood_pressure",
                value: "Tekanan Darah"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$6, {
                id: "blood_pressure",
                type: "text",
                class: "mt-1 block w-full",
                modelValue: unref(form).blood_pressure,
                "onUpdate:modelValue": ($event) => unref(form).blood_pressure = $event
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$4, {
                class: "mt-2",
                message: unref(form).errors.blood_pressure
              }, null, _parent2, _scopeId));
              _push2(`</div><div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "blood_sugar",
                value: "Gula Darah"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$6, {
                id: "blood_sugar",
                type: "text",
                class: "mt-1 block w-full",
                modelValue: unref(form).blood_sugar,
                "onUpdate:modelValue": ($event) => unref(form).blood_sugar = $event
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$4, {
                class: "mt-2",
                message: unref(form).errors.blood_sugar
              }, null, _parent2, _scopeId));
              _push2(`</div><div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "is_smoking",
                value: "Merokok"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$5, {
                id: "is_smoking",
                class: "mt-1 block w-full",
                modelValue: unref(form).is_smoking,
                "onUpdate:modelValue": ($event) => unref(form).is_smoking = $event,
                autocomplete: "is_smoking",
                "option-value": [
                  { value: true, text: "Ya" },
                  { value: false, text: "Tidak" }
                ]
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$4, {
                class: "mt-2",
                message: unref(form).errors.is_smoking
              }, null, _parent2, _scopeId));
              _push2(`</div><div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "color_blind",
                value: "Buta Warna"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$5, {
                id: "color_blind",
                class: "mt-1 block w-full",
                modelValue: unref(form).color_blind,
                "onUpdate:modelValue": ($event) => unref(form).color_blind = $event,
                autocomplete: "color_blind",
                "option-value": [
                  { value: true, text: "Ya" },
                  { value: false, text: "Tidak" }
                ]
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$4, {
                class: "mt-2",
                message: unref(form).errors.color_blind
              }, null, _parent2, _scopeId));
              _push2(`</div><div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "is_disability",
                value: "Disabilitas"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$5, {
                id: "is_disability",
                class: "mt-1 block w-full",
                modelValue: unref(form).is_disability,
                "onUpdate:modelValue": ($event) => unref(form).is_disability = $event,
                autocomplete: "is_disability",
                "option-value": [
                  { value: true, text: "Ya" },
                  { value: false, text: "Tidak" }
                ]
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$4, {
                class: "mt-2",
                message: unref(form).errors.is_disability
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="col-span-1 md:col-span-4"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "note",
                value: "Catatan"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$7, {
                id: "note",
                class: "mt-1 block w-full",
                modelValue: unref(form).note,
                "onUpdate:modelValue": ($event) => unref(form).note = $event
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$4, {
                class: "mt-2",
                message: unref(form).errors.note
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="col-span-1 md:col-span-4"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "image",
                value: "Foto"
              }, null, _parent2, _scopeId));
              _push2(`<div class="flex items-center justify-center w-full"${_scopeId}><label for="dropzone-file" class="flex flex-col items-center justify-center w-full h-auto border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"${_scopeId}>`);
              if (!unref(form).image && !__props.image) {
                _push2(`<div class="flex flex-col items-center justify-center pt-5 pb-6"${_scopeId}><i class="fa-solid fa-cloud-arrow-up text-lg"${_scopeId}></i><p class="mb-2 text-sm text-gray-500 dark:text-gray-400"${_scopeId}><span class="font-semibold"${_scopeId}>Click to upload</span> or drag and drop </p><p class="text-xs text-gray-500 dark:text-gray-400"${_scopeId}> PNG, JPG (MAX. 800x400px) </p></div>`);
              } else {
                _push2(`<div class="flex flex-col items-center justify-center pt-5 pb-6"${_scopeId}><img${ssrRenderAttr("src", url.value || __props.image)} alt="Bukti tes kesehatan" class="object-contain w-full max-h-40"${_scopeId}></div>`);
              }
              _push2(`<input id="dropzone-file" type="file" class="hidden" accept="image/*"${_scopeId}></label></div>`);
              _push2(ssrRenderComponent(_sfc_main$4, {
                class: "mt-2",
                message: unref(form).errors.image
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="mt-6 text-sm text-gray-400 col-span-1 md:col-span-4"${_scopeId}><p${_scopeId}><span class="font-semibold"${_scopeId}>Catatan:</span> Data yang di inputkan akan di verifikasi oleh admin. Jika data yang di inputkan tidak sesuai dengan kriteria yang di tentukan maka data akan di tolak. </p></div><div class="col-span-1 md:col-span-4"${_scopeId}><div class="flex justify-end"${_scopeId}>`);
              _push2(ssrRenderComponent(PrimaryButton, { type: "submit" }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Simpan `);
                  } else {
                    return [
                      createTextVNode(" Simpan ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div></div></form><!--]-->`);
            } else if (__props.user.status == "submitted") {
              _push2(`<div class="mt-6"${_scopeId}><p${_scopeId}> Anda sudah mengirimkan data pemeriksaan kesehatan. mohon tunggu hingga data di verifikasi </p></div>`);
            } else if (__props.user.status == "approved") {
              _push2(`<div class="mt-6"${_scopeId}><p${_scopeId}> Selamat data pemeriksaan kesehatan anda sudah di verifikasi oleh admin dan diterima </p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(_sfc_main$8, {
              show: modal.value,
              onClose: ($event) => close()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><div class="flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4"${_scopeId2}><header${_scopeId2}><h2 class="text-2xl font-bold text-gray-900 dark:text-gray-100 capitalize"${_scopeId2}> Submit </h2><p class="text-sm text-gray-400"${_scopeId2}> Anda yakin ingin menyimpan data ini? Data akan di verifikasi oleh admin. </p></header></div><div class="mt-6"${_scopeId2}><div class="flex justify-end"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$9, {
                    onClick: ($event) => close()
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Cancel `);
                      } else {
                        return [
                          createTextVNode(" Cancel ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(PrimaryButton, {
                    class: "ml-2",
                    onClick: ($event) => save()
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` save `);
                      } else {
                        return [
                          createTextVNode(" save ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4" }, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100 capitalize" }, " Submit "),
                          createVNode("p", { class: "text-sm text-gray-400" }, " Anda yakin ingin menyimpan data ini? Data akan di verifikasi oleh admin. ")
                        ])
                      ]),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode(_sfc_main$9, {
                            onClick: ($event) => close()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(PrimaryButton, {
                            class: "ml-2",
                            onClick: ($event) => save()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" save ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "bg-white dark:bg-gray-800 p-4 sm:p-8 shadow-md rounded-lg sm:shadow-lg" }, [
                    createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100 capitalize" }, " Tes Kesehatan "),
                        createVNode("p", { class: "text-sm text-gray-400" }, " Pemeriksaan kesehatan calon mahasiswa baru ")
                      ])
                    ]),
                    __props.user.status !== "submitted" && __props.user.status !== "approved" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                      __props.user.status === "rejected" && __props.user.admin_note ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "bg-yellow-50 dark:bg-yellow-800 border-l-4 border-yellow-400 p-4 rounded-lg"
                      }, [
                        createVNode("h4", { class: "flex items-center text-lg font-semibold text-yellow-600 dark:text-yellow-400" }, [
                          createVNode("i", { class: "fa-solid fa-exclamation-triangle text-yellow-400" }),
                          createVNode("span", { class: "ml-2" }, "Perhatian")
                        ]),
                        createVNode("p", { class: "mt-2 text-sm text-gray-500 dark:text-gray-400" }, toDisplayString(__props.user.admin_note), 1)
                      ])) : createCommentVNode("", true),
                      createVNode("form", {
                        onSubmit: withModifiers(($event) => open(), ["prevent"]),
                        class: "mt-6 grid grid-cols-1 gap-y-6 md:grid-cols-4 md:gap-x-8"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for: "height",
                            value: "Tinggi Badan"
                          }),
                          createVNode(_sfc_main$3, {
                            id: "height",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).height,
                            "onUpdate:modelValue": ($event) => unref(form).height = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.height
                          }, null, 8, ["message"]),
                          createVNode("p", { class: "mt-2 text-sm text-gray-400" }, " Satuan dalam sentimeter (cm) ")
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for: "weight",
                            value: "Berat Badan"
                          }),
                          createVNode(_sfc_main$3, {
                            id: "weight",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).weight,
                            "onUpdate:modelValue": ($event) => unref(form).weight = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.weight
                          }, null, 8, ["message"]),
                          createVNode("p", { class: "mt-2 text-sm text-gray-400" }, " Satuan dalam kilogram (kg) ")
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for: "blood_type",
                            value: "Gol. Darah"
                          }),
                          createVNode(_sfc_main$5, {
                            id: "blood_type",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).blood_type,
                            "onUpdate:modelValue": ($event) => unref(form).blood_type = $event,
                            autocomplete: "blood_type",
                            "option-value": [
                              { value: "A", text: "A" },
                              { value: "B", text: "B" },
                              { value: "AB", text: "AB" },
                              { value: "O", text: "O" },
                              { value: "", text: "Silahkan Pilih" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.blood_type
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for: "blood_pressure",
                            value: "Tekanan Darah"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "blood_pressure",
                            type: "text",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).blood_pressure,
                            "onUpdate:modelValue": ($event) => unref(form).blood_pressure = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.blood_pressure
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for: "blood_sugar",
                            value: "Gula Darah"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "blood_sugar",
                            type: "text",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).blood_sugar,
                            "onUpdate:modelValue": ($event) => unref(form).blood_sugar = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.blood_sugar
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for: "is_smoking",
                            value: "Merokok"
                          }),
                          createVNode(_sfc_main$5, {
                            id: "is_smoking",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).is_smoking,
                            "onUpdate:modelValue": ($event) => unref(form).is_smoking = $event,
                            autocomplete: "is_smoking",
                            "option-value": [
                              { value: true, text: "Ya" },
                              { value: false, text: "Tidak" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.is_smoking
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for: "color_blind",
                            value: "Buta Warna"
                          }),
                          createVNode(_sfc_main$5, {
                            id: "color_blind",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).color_blind,
                            "onUpdate:modelValue": ($event) => unref(form).color_blind = $event,
                            autocomplete: "color_blind",
                            "option-value": [
                              { value: true, text: "Ya" },
                              { value: false, text: "Tidak" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.color_blind
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for: "is_disability",
                            value: "Disabilitas"
                          }),
                          createVNode(_sfc_main$5, {
                            id: "is_disability",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).is_disability,
                            "onUpdate:modelValue": ($event) => unref(form).is_disability = $event,
                            autocomplete: "is_disability",
                            "option-value": [
                              { value: true, text: "Ya" },
                              { value: false, text: "Tidak" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.is_disability
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "col-span-1 md:col-span-4" }, [
                          createVNode(_sfc_main$2, {
                            for: "note",
                            value: "Catatan"
                          }),
                          createVNode(_sfc_main$7, {
                            id: "note",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).note,
                            "onUpdate:modelValue": ($event) => unref(form).note = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.note
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "col-span-1 md:col-span-4" }, [
                          createVNode(_sfc_main$2, {
                            for: "image",
                            value: "Foto"
                          }),
                          createVNode("div", { class: "flex items-center justify-center w-full" }, [
                            createVNode("label", {
                              for: "dropzone-file",
                              class: "flex flex-col items-center justify-center w-full h-auto border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
                            }, [
                              !unref(form).image && !__props.image ? (openBlock(), createBlock("div", {
                                key: 0,
                                class: "flex flex-col items-center justify-center pt-5 pb-6"
                              }, [
                                createVNode("i", { class: "fa-solid fa-cloud-arrow-up text-lg" }),
                                createVNode("p", { class: "mb-2 text-sm text-gray-500 dark:text-gray-400" }, [
                                  createVNode("span", { class: "font-semibold" }, "Click to upload"),
                                  createTextVNode(" or drag and drop ")
                                ]),
                                createVNode("p", { class: "text-xs text-gray-500 dark:text-gray-400" }, " PNG, JPG (MAX. 800x400px) ")
                              ])) : (openBlock(), createBlock("div", {
                                key: 1,
                                class: "flex flex-col items-center justify-center pt-5 pb-6"
                              }, [
                                createVNode("img", {
                                  src: url.value || __props.image,
                                  alt: "Bukti tes kesehatan",
                                  class: "object-contain w-full max-h-40"
                                }, null, 8, ["src"])
                              ])),
                              createVNode("input", {
                                id: "dropzone-file",
                                type: "file",
                                class: "hidden",
                                accept: "image/*",
                                onChange: onFileChange
                              }, null, 32)
                            ])
                          ]),
                          createVNode(_sfc_main$4, {
                            class: "mt-2",
                            message: unref(form).errors.image
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "mt-6 text-sm text-gray-400 col-span-1 md:col-span-4" }, [
                          createVNode("p", null, [
                            createVNode("span", { class: "font-semibold" }, "Catatan:"),
                            createTextVNode(" Data yang di inputkan akan di verifikasi oleh admin. Jika data yang di inputkan tidak sesuai dengan kriteria yang di tentukan maka data akan di tolak. ")
                          ])
                        ]),
                        createVNode("div", { class: "col-span-1 md:col-span-4" }, [
                          createVNode("div", { class: "flex justify-end" }, [
                            createVNode(PrimaryButton, { type: "submit" }, {
                              default: withCtx(() => [
                                createTextVNode(" Simpan ")
                              ]),
                              _: 1
                            })
                          ])
                        ])
                      ], 40, ["onSubmit"])
                    ], 64)) : __props.user.status == "submitted" ? (openBlock(), createBlock("div", {
                      key: 1,
                      class: "mt-6"
                    }, [
                      createVNode("p", null, " Anda sudah mengirimkan data pemeriksaan kesehatan. mohon tunggu hingga data di verifikasi ")
                    ])) : __props.user.status == "approved" ? (openBlock(), createBlock("div", {
                      key: 2,
                      class: "mt-6"
                    }, [
                      createVNode("p", null, " Selamat data pemeriksaan kesehatan anda sudah di verifikasi oleh admin dan diterima ")
                    ])) : createCommentVNode("", true)
                  ])
                ]),
                createVNode(_sfc_main$8, {
                  show: modal.value,
                  onClose: ($event) => close()
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4" }, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100 capitalize" }, " Submit "),
                          createVNode("p", { class: "text-sm text-gray-400" }, " Anda yakin ingin menyimpan data ini? Data akan di verifikasi oleh admin. ")
                        ])
                      ]),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode(_sfc_main$9, {
                            onClick: ($event) => close()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(PrimaryButton, {
                            class: "ml-2",
                            onClick: ($event) => save()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" save ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show", "onClose"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Exams/Health/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
