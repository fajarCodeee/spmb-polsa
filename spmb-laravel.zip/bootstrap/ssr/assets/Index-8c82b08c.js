import { ref, unref, withCtx, createTextVNode, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, withModifiers, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { useForm, Head, router } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { _ as _sfc_main$6 } from "./Combobox-8f85dcc2.js";
import { _ as _sfc_main$5 } from "./TextareaInput-ea5736c3.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$8 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$4 } from "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$3 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$7 } from "./InputError-83b094c2.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    health: Object
  },
  setup(__props) {
    const navigateTo = (url) => {
      if (url === null)
        return;
      return router.visit(url);
    };
    const form = useForm({
      status: null,
      admin_note: null
    });
    const modalStatus = ref(false);
    const modalItem = ref(null);
    const open = (item) => {
      modalStatus.value = true;
      modalItem.value = item;
      form.status = item.status;
      form.admin_note = item.admin_note || ``;
    };
    const close = () => {
      modalStatus.value = false;
      modalItem.value = null;
      form.reset();
    };
    const save = () => {
      form.post(route("admin.health-verification.update", modalItem.value.id), {
        preserveScroll: true,
        onSuccess: () => {
          close();
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Validasi Kesehatan" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="bg-white p-4 sm:p-8 shadow-md sm:shadow-lg rounded-lg"${_scopeId}><div class="relative overflow-x-auto shadow-md sm:rounded-lg"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}>Nama</th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> No Hp </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Status </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.health.data, (item) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><th scope="row" class="flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}><div${_scopeId}><div class="text-base font-semibold"${_scopeId}>${ssrInterpolate(item.user)}</div><div class="text-sm text-gray-500 font-semibold"${_scopeId}>${ssrInterpolate(item.email)}</div></div></th><td class="px-6 py-4 capitalize truncate text-center"${_scopeId}>${ssrInterpolate(item.phone)}</td><td class="px-6 py-4 capitalize truncate text-center"${_scopeId}>${ssrInterpolate(item.status)}</td><td class="px-6 py-4"${_scopeId}><div class="flex justify-center"${_scopeId}><button type="button" class="text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"${_scopeId}><i class="fas fa-edit"${_scopeId}></i></button></div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table>`);
            if (__props.health.data.length === 0) {
              _push2(`<div class="flex items-center justify-center p-4"${_scopeId}><p class="text-gray-500 dark:text-gray-400"${_scopeId}> Tidak ada yang perlu divalidasi </p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="py-1 px-4"${_scopeId}><nav class="flex items-center space-x-1"${_scopeId}><!--[-->`);
            ssrRenderList(__props.health.links, (link) => {
              _push2(`<button type="button" class="min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10" aria-current="page"${ssrIncludeBooleanAttr(link.active) ? " disabled" : ""}${_scopeId}><span class="truncate"${_scopeId}>${link.label}</span></button>`);
            });
            _push2(`<!--]--></nav></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: modalStatus.value,
              maxWidth: "4xl",
              onClose: ($event) => modalStatus.value = false
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-xl font-semibold text-gray-800 dark:text-gray-100"${_scopeId2}><i class="fas fa-edit"${_scopeId2}></i> Edit Status </h2><div class="mt-4"${_scopeId2}><div class="flex flex-col items-center justify-between"${_scopeId2}><div${_scopeId2}><img${ssrRenderAttr("src", modalItem.value.image)} alt="" class="max-h-96 rounded-lg object-cover"${_scopeId2}></div><div${_scopeId2}><div class="grid grid-cols-2 md:grid-cols-4 gap-4"${_scopeId2}><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "height",
                    value: "Tinggi"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    type: "number",
                    modelValue: modalItem.value.height,
                    "onUpdate:modelValue": ($event) => modalItem.value.height = $event,
                    disabled: "",
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "weight",
                    value: "Berat"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    type: "number",
                    modelValue: modalItem.value.weight,
                    "onUpdate:modelValue": ($event) => modalItem.value.weight = $event,
                    disabled: "",
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "blood_type",
                    value: "Tekanan Darah"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    type: "text",
                    modelValue: modalItem.value.blood_pressure,
                    "onUpdate:modelValue": ($event) => modalItem.value.blood_pressure = $event,
                    disabled: "",
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "blood_type",
                    value: "Golongan Darah"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    type: "text",
                    modelValue: modalItem.value.blood_type,
                    "onUpdate:modelValue": ($event) => modalItem.value.blood_type = $event,
                    disabled: "",
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "blood_sugar",
                    value: "Gula Darah"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    type: "text",
                    modelValue: modalItem.value.blood_sugar,
                    "onUpdate:modelValue": ($event) => modalItem.value.blood_sugar = $event,
                    disabled: "",
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "is_smoking",
                    value: "Perokok"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    type: "text",
                    modelValue: modalItem.value.is_smoking,
                    "onUpdate:modelValue": ($event) => modalItem.value.is_smoking = $event,
                    disabled: "",
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "color_blind",
                    value: "Buta Warna"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    type: "text",
                    modelValue: modalItem.value.color_blind,
                    "onUpdate:modelValue": ($event) => modalItem.value.color_blind = $event,
                    disabled: "",
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "is_disability",
                    value: "Disabilitas"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    type: "text",
                    modelValue: modalItem.value.is_disability,
                    "onUpdate:modelValue": ($event) => modalItem.value.is_disability = $event,
                    disabled: "",
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="col-span-2 md:col-span-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "note",
                    value: "Cacatan Disabilitas"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$5, {
                    type: "text",
                    modelValue: modalItem.value.note,
                    "onUpdate:modelValue": ($event) => modalItem.value.note = $event,
                    disabled: "",
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div></div><div class="mt-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "status",
                    value: "Status"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$6, {
                    modelValue: unref(form).status,
                    "onUpdate:modelValue": ($event) => unref(form).status = $event,
                    "option-value": [
                      {
                        text: "Waiting",
                        value: "waiting"
                      },
                      {
                        text: "Submitted",
                        value: "submitted"
                      },
                      {
                        text: "Approved",
                        value: "approved"
                      },
                      {
                        text: "Rejected",
                        value: "rejected"
                      }
                    ],
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$7, {
                    message: unref(form).errors.status
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="mt-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "admin_note",
                    value: "Catatan"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$5, {
                    modelValue: unref(form).admin_note,
                    "onUpdate:modelValue": ($event) => unref(form).admin_note = $event,
                    class: "mt-1 block w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$7, {
                    message: unref(form).errors.admin_note
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="mt-4 flex gap-3"${_scopeId2}>`);
                  _push3(ssrRenderComponent(PrimaryButton, { onClick: save }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Simpan `);
                      } else {
                        return [
                          createTextVNode(" Simpan ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$8, { onClick: close }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Batal `);
                      } else {
                        return [
                          createTextVNode(" Batal ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div></div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-xl font-semibold text-gray-800 dark:text-gray-100" }, [
                        createVNode("i", { class: "fas fa-edit" }),
                        createTextVNode(" Edit Status ")
                      ]),
                      createVNode("div", { class: "mt-4" }, [
                        createVNode("div", { class: "flex flex-col items-center justify-between" }, [
                          createVNode("div", null, [
                            createVNode("img", {
                              src: modalItem.value.image,
                              alt: "",
                              class: "max-h-96 rounded-lg object-cover"
                            }, null, 8, ["src"])
                          ]),
                          createVNode("div", null, [
                            createVNode("div", { class: "grid grid-cols-2 md:grid-cols-4 gap-4" }, [
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "height",
                                  value: "Tinggi"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "number",
                                  modelValue: modalItem.value.height,
                                  "onUpdate:modelValue": ($event) => modalItem.value.height = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "weight",
                                  value: "Berat"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "number",
                                  modelValue: modalItem.value.weight,
                                  "onUpdate:modelValue": ($event) => modalItem.value.weight = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "blood_type",
                                  value: "Tekanan Darah"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.blood_pressure,
                                  "onUpdate:modelValue": ($event) => modalItem.value.blood_pressure = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "blood_type",
                                  value: "Golongan Darah"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.blood_type,
                                  "onUpdate:modelValue": ($event) => modalItem.value.blood_type = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "blood_sugar",
                                  value: "Gula Darah"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.blood_sugar,
                                  "onUpdate:modelValue": ($event) => modalItem.value.blood_sugar = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "is_smoking",
                                  value: "Perokok"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.is_smoking,
                                  "onUpdate:modelValue": ($event) => modalItem.value.is_smoking = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "color_blind",
                                  value: "Buta Warna"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.color_blind,
                                  "onUpdate:modelValue": ($event) => modalItem.value.color_blind = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "is_disability",
                                  value: "Disabilitas"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.is_disability,
                                  "onUpdate:modelValue": ($event) => modalItem.value.is_disability = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-4" }, [
                                createVNode(_sfc_main$3, {
                                  for: "note",
                                  value: "Cacatan Disabilitas"
                                }),
                                createVNode(_sfc_main$5, {
                                  type: "text",
                                  modelValue: modalItem.value.note,
                                  "onUpdate:modelValue": ($event) => modalItem.value.note = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ])
                            ]),
                            createVNode("div", { class: "mt-4" }, [
                              createVNode(_sfc_main$3, {
                                for: "status",
                                value: "Status"
                              }),
                              createVNode(_sfc_main$6, {
                                modelValue: unref(form).status,
                                "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                "option-value": [
                                  {
                                    text: "Waiting",
                                    value: "waiting"
                                  },
                                  {
                                    text: "Submitted",
                                    value: "submitted"
                                  },
                                  {
                                    text: "Approved",
                                    value: "approved"
                                  },
                                  {
                                    text: "Rejected",
                                    value: "rejected"
                                  }
                                ],
                                class: "mt-1 block w-full"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$7, {
                                message: unref(form).errors.status
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "mt-4" }, [
                              createVNode(_sfc_main$3, {
                                for: "admin_note",
                                value: "Catatan"
                              }),
                              createVNode(_sfc_main$5, {
                                modelValue: unref(form).admin_note,
                                "onUpdate:modelValue": ($event) => unref(form).admin_note = $event,
                                class: "mt-1 block w-full"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$7, {
                                message: unref(form).errors.admin_note
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "mt-4 flex gap-3" }, [
                              createVNode(PrimaryButton, { onClick: save }, {
                                default: withCtx(() => [
                                  createTextVNode(" Simpan ")
                                ]),
                                _: 1
                              }),
                              createVNode(_sfc_main$8, { onClick: close }, {
                                default: withCtx(() => [
                                  createTextVNode(" Batal ")
                                ]),
                                _: 1
                              })
                            ])
                          ])
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "bg-white p-4 sm:p-8 shadow-md sm:shadow-lg rounded-lg" }, [
                    createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Nama"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " No Hp "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Status "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.health.data, (item) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: item.id
                            }, [
                              createVNode("th", {
                                scope: "row",
                                class: "flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"
                              }, [
                                createVNode("div", null, [
                                  createVNode("div", { class: "text-base font-semibold" }, toDisplayString(item.user), 1),
                                  createVNode("div", { class: "text-sm text-gray-500 font-semibold" }, toDisplayString(item.email), 1)
                                ])
                              ]),
                              createVNode("td", { class: "px-6 py-4 capitalize truncate text-center" }, toDisplayString(item.phone), 1),
                              createVNode("td", { class: "px-6 py-4 capitalize truncate text-center" }, toDisplayString(item.status), 1),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex justify-center" }, [
                                  createVNode("button", {
                                    type: "button",
                                    class: "text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300",
                                    onClick: withModifiers(($event) => open(item), ["prevent"])
                                  }, [
                                    createVNode("i", { class: "fas fa-edit" })
                                  ], 8, ["onClick"])
                                ])
                              ])
                            ]);
                          }), 128))
                        ])
                      ]),
                      __props.health.data.length === 0 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "flex items-center justify-center p-4"
                      }, [
                        createVNode("p", { class: "text-gray-500 dark:text-gray-400" }, " Tidak ada yang perlu divalidasi ")
                      ])) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "py-1 px-4" }, [
                      createVNode("nav", { class: "flex items-center space-x-1" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.health.links, (link) => {
                          return openBlock(), createBlock("button", {
                            type: "button",
                            class: "min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10",
                            "aria-current": "page",
                            key: link.label,
                            disabled: link.active,
                            onClick: withModifiers(($event) => navigateTo(link.url), ["prevent"])
                          }, [
                            createVNode("span", {
                              innerHTML: link.label,
                              class: "truncate"
                            }, null, 8, ["innerHTML"])
                          ], 8, ["disabled", "onClick"]);
                        }), 128))
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: modalStatus.value,
                  maxWidth: "4xl",
                  onClose: ($event) => modalStatus.value = false
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-xl font-semibold text-gray-800 dark:text-gray-100" }, [
                        createVNode("i", { class: "fas fa-edit" }),
                        createTextVNode(" Edit Status ")
                      ]),
                      createVNode("div", { class: "mt-4" }, [
                        createVNode("div", { class: "flex flex-col items-center justify-between" }, [
                          createVNode("div", null, [
                            createVNode("img", {
                              src: modalItem.value.image,
                              alt: "",
                              class: "max-h-96 rounded-lg object-cover"
                            }, null, 8, ["src"])
                          ]),
                          createVNode("div", null, [
                            createVNode("div", { class: "grid grid-cols-2 md:grid-cols-4 gap-4" }, [
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "height",
                                  value: "Tinggi"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "number",
                                  modelValue: modalItem.value.height,
                                  "onUpdate:modelValue": ($event) => modalItem.value.height = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "weight",
                                  value: "Berat"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "number",
                                  modelValue: modalItem.value.weight,
                                  "onUpdate:modelValue": ($event) => modalItem.value.weight = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "blood_type",
                                  value: "Tekanan Darah"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.blood_pressure,
                                  "onUpdate:modelValue": ($event) => modalItem.value.blood_pressure = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "blood_type",
                                  value: "Golongan Darah"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.blood_type,
                                  "onUpdate:modelValue": ($event) => modalItem.value.blood_type = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "blood_sugar",
                                  value: "Gula Darah"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.blood_sugar,
                                  "onUpdate:modelValue": ($event) => modalItem.value.blood_sugar = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "is_smoking",
                                  value: "Perokok"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.is_smoking,
                                  "onUpdate:modelValue": ($event) => modalItem.value.is_smoking = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "color_blind",
                                  value: "Buta Warna"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.color_blind,
                                  "onUpdate:modelValue": ($event) => modalItem.value.color_blind = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", null, [
                                createVNode(_sfc_main$3, {
                                  for: "is_disability",
                                  value: "Disabilitas"
                                }),
                                createVNode(_sfc_main$4, {
                                  type: "text",
                                  modelValue: modalItem.value.is_disability,
                                  "onUpdate:modelValue": ($event) => modalItem.value.is_disability = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-4" }, [
                                createVNode(_sfc_main$3, {
                                  for: "note",
                                  value: "Cacatan Disabilitas"
                                }),
                                createVNode(_sfc_main$5, {
                                  type: "text",
                                  modelValue: modalItem.value.note,
                                  "onUpdate:modelValue": ($event) => modalItem.value.note = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ])
                            ]),
                            createVNode("div", { class: "mt-4" }, [
                              createVNode(_sfc_main$3, {
                                for: "status",
                                value: "Status"
                              }),
                              createVNode(_sfc_main$6, {
                                modelValue: unref(form).status,
                                "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                "option-value": [
                                  {
                                    text: "Waiting",
                                    value: "waiting"
                                  },
                                  {
                                    text: "Submitted",
                                    value: "submitted"
                                  },
                                  {
                                    text: "Approved",
                                    value: "approved"
                                  },
                                  {
                                    text: "Rejected",
                                    value: "rejected"
                                  }
                                ],
                                class: "mt-1 block w-full"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$7, {
                                message: unref(form).errors.status
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "mt-4" }, [
                              createVNode(_sfc_main$3, {
                                for: "admin_note",
                                value: "Catatan"
                              }),
                              createVNode(_sfc_main$5, {
                                modelValue: unref(form).admin_note,
                                "onUpdate:modelValue": ($event) => unref(form).admin_note = $event,
                                class: "mt-1 block w-full"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$7, {
                                message: unref(form).errors.admin_note
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "mt-4 flex gap-3" }, [
                              createVNode(PrimaryButton, { onClick: save }, {
                                default: withCtx(() => [
                                  createTextVNode(" Simpan ")
                                ]),
                                _: 1
                              }),
                              createVNode(_sfc_main$8, { onClick: close }, {
                                default: withCtx(() => [
                                  createTextVNode(" Batal ")
                                ]),
                                _: 1
                              })
                            ])
                          ])
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show", "onClose"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Verification/Health/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
