import { ref, unref, withCtx, createTextVNode, createVNode, toDisplayString, openBlock, createBlock, withDirectives, vModelText, Fragment, renderList, withModifiers, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrRenderClass, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { useForm, usePage, Head, router } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { _ as _sfc_main$4 } from "./Combobox-8f85dcc2.js";
import { _ as _sfc_main$7 } from "./TextareaInput-ea5736c3.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$8 } from "./SecondaryButton-33aab301.js";
import "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$3 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$5 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$6 } from "./DateInput-00587317.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    interviews: Object
  },
  setup(__props) {
    const navigateTo = (url) => {
      if (url === null)
        return;
      return router.visit(url);
    };
    const form = useForm({
      status: null,
      note: null,
      interview_date: null
    });
    const modalStatus = ref(false);
    const modalItem = ref(null);
    const search = ref("");
    const timeoutId = ref(null);
    const interview = ref(usePage().props.interviews);
    const open = (item) => {
      modalStatus.value = true;
      modalItem.value = item;
      form.status = item.status;
      form.note = item.note || ``;
      form.interview_date = item.interview_date || ``;
    };
    const close = () => {
      modalStatus.value = false;
      modalItem.value = null;
      form.reset();
    };
    const save = () => {
      form.post(route("admin.interview.update", modalItem.value.id), {
        preserveScroll: true,
        onSuccess: () => {
          close();
        }
      });
    };
    const find = async () => {
      if (search.value === "") {
        return interview.value = usePage().props.interviews;
      }
      if (timeoutId.value) {
        clearTimeout(timeoutId.value);
      }
      timeoutId.value = setTimeout(() => {
        fetch(route("admin.interview.search", { search: search.value })).then((response) => response.json()).then((data) => {
          console.log(data);
          return interview.value = data;
        });
      }, 1e3);
      return usePage().props.interviews;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Validasi Interview" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="bg-white p-4 sm:p-8 shadow-md sm:shadow-lg rounded-lg"${_scopeId}><header${_scopeId}><div class="flex items-center justify-between flex-column flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900"${_scopeId}><h2 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId}> Validasi Interview <span class="text-sm text-gray-500 dark:text-gray-400"${_scopeId}> (${ssrInterpolate(__props.interviews.data.length)}) </span></h2><label for="table-search" class="sr-only"${_scopeId}>Search</label><div class="relative"${_scopeId}><div class="absolute inset-y-0 rtl:inset-r-0 start-0 flex items-center ps-3 pointer-events-none"${_scopeId}><svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20"${_scopeId}><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"${_scopeId}></path></svg></div><input type="text" id="table-search-users"${ssrRenderAttr("value", search.value)} class="block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search for users"${_scopeId}></div></div></header><div class="relative overflow-x-auto shadow-md sm:rounded-lg"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}> Kandidat </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> No Ujian </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Tanggal </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Status </th><th scope="col" class="px-6 py-3 text-center"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.interviews.data, (item) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><th scope="row" class="flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}><div${_scopeId}><div class="text-base font-semibold"${_scopeId}>${ssrInterpolate(item.user.name)}</div><div class="text-sm text-gray-500 font-semibold"${_scopeId}> Email: ${ssrInterpolate(item.user.email)}</div><div class="text-sm text-gray-500 font-semibold"${_scopeId}> No. Hp: ${ssrInterpolate(item.user.phone)}</div></div></th><td class="px-6 py-4 text-center"${_scopeId}>${ssrInterpolate(item.no_exam)}</td><td class="px-6 py-4 text-center"${_scopeId}>${ssrInterpolate(item.interview_date ? new Date(
                item.interview_date
              ).toLocaleDateString() : "-")}</td><td class="px-6 py-4 capitalize truncate text-center"${_scopeId}><span class="${ssrRenderClass([{
                "bg-green-100 text-green-800 dark:bg-green-500 dark:text-green-100": item.status === "approved",
                "bg-yellow-100 text-yellow-800 dark:bg-yellow-500 dark:text-yellow-100": item.status === "pending",
                "bg-red-100 text-red-800 dark:bg-red-500 dark:text-red-100": item.status === "rejected"
              }, "px-2 py-1 rounded-full"])}"${_scopeId}>${ssrInterpolate(item.status)}</span></td><td class="px-6 py-4"${_scopeId}><div class="flex justify-center"${_scopeId}><button type="button" class="text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"${_scopeId}><i class="fas fa-edit"${_scopeId}></i></button></div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table>`);
            if (__props.interviews.data.length === 0) {
              _push2(`<div class="flex items-center justify-center p-4"${_scopeId}><p class="text-gray-500 dark:text-gray-400 text-xs md:text-base"${_scopeId}> Tidak ada yang mengajukan interview </p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="py-1 px-4"${_scopeId}><nav class="flex items-center space-x-1"${_scopeId}><!--[-->`);
            ssrRenderList(__props.interviews.links, (link) => {
              _push2(`<button type="button" class="min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10" aria-current="page"${ssrIncludeBooleanAttr(link.active) ? " disabled" : ""}${_scopeId}><span class="truncate"${_scopeId}>${link.label}</span></button>`);
            });
            _push2(`<!--]--></nav></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: modalStatus.value,
              onClose: close
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><header${_scopeId2}><h2 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId2}> Update Status Interview </h2></header><div class="mt-4 grid grid-cols-1 gap-4"${_scopeId2}><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "status",
                    value: "Status"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    modelValue: unref(form).status,
                    "onUpdate:modelValue": ($event) => unref(form).status = $event,
                    class: "w-full",
                    "option-value": [
                      { label: "Pending", text: "pending" },
                      { label: "Approved", text: "approved" },
                      { label: "Rejected", text: "rejected" }
                    ]
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$5, {
                    message: unref(form).errors.status
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "interview_date",
                    value: "Waktu interview"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$6, {
                    id: "interview_date",
                    class: "mt-1 block w-full",
                    modelValue: unref(form).interview_date,
                    "onUpdate:modelValue": ($event) => unref(form).interview_date = $event,
                    type: "datetime-local"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$5, {
                    class: "mt-2",
                    message: unref(form).errors.interview_date
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    for: "note",
                    value: "Catatan Admin"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$7, {
                    modelValue: unref(form).note,
                    "onUpdate:modelValue": ($event) => unref(form).note = $event,
                    class: "w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$5, {
                    message: unref(form).errors.note
                  }, null, _parent3, _scopeId2));
                  _push3(`</div></div><div class="mt-4 flex justify-end gap-3"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$8, { onClick: close }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Batal `);
                      } else {
                        return [
                          createTextVNode(" Batal ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(PrimaryButton, {
                    onClick: save,
                    disabled: unref(form).processing
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Simpan `);
                      } else {
                        return [
                          createTextVNode(" Simpan ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Update Status Interview ")
                      ]),
                      createVNode("div", { class: "mt-4 grid grid-cols-1 gap-4" }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "status",
                            value: "Status"
                          }),
                          createVNode(_sfc_main$4, {
                            modelValue: unref(form).status,
                            "onUpdate:modelValue": ($event) => unref(form).status = $event,
                            class: "w-full",
                            "option-value": [
                              { label: "Pending", text: "pending" },
                              { label: "Approved", text: "approved" },
                              { label: "Rejected", text: "rejected" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.status
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "interview_date",
                            value: "Waktu interview"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "interview_date",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).interview_date,
                            "onUpdate:modelValue": ($event) => unref(form).interview_date = $event,
                            type: "datetime-local"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            class: "mt-2",
                            message: unref(form).errors.interview_date
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "note",
                            value: "Catatan Admin"
                          }),
                          createVNode(_sfc_main$7, {
                            modelValue: unref(form).note,
                            "onUpdate:modelValue": ($event) => unref(form).note = $event,
                            class: "w-full"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.note
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "mt-4 flex justify-end gap-3" }, [
                        createVNode(_sfc_main$8, { onClick: close }, {
                          default: withCtx(() => [
                            createTextVNode(" Batal ")
                          ]),
                          _: 1
                        }),
                        createVNode(PrimaryButton, {
                          onClick: save,
                          disabled: unref(form).processing
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Simpan ")
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "bg-white p-4 sm:p-8 shadow-md sm:shadow-lg rounded-lg" }, [
                    createVNode("header", null, [
                      createVNode("div", { class: "flex items-center justify-between flex-column flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900" }, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, [
                          createTextVNode(" Validasi Interview "),
                          createVNode("span", { class: "text-sm text-gray-500 dark:text-gray-400" }, " (" + toDisplayString(__props.interviews.data.length) + ") ", 1)
                        ]),
                        createVNode("label", {
                          for: "table-search",
                          class: "sr-only"
                        }, "Search"),
                        createVNode("div", { class: "relative" }, [
                          createVNode("div", { class: "absolute inset-y-0 rtl:inset-r-0 start-0 flex items-center ps-3 pointer-events-none" }, [
                            (openBlock(), createBlock("svg", {
                              class: "w-4 h-4 text-gray-500 dark:text-gray-400",
                              "aria-hidden": "true",
                              xmlns: "http://www.w3.org/2000/svg",
                              fill: "none",
                              viewBox: "0 0 20 20"
                            }, [
                              createVNode("path", {
                                stroke: "currentColor",
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                "stroke-width": "2",
                                d: "m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                              })
                            ]))
                          ]),
                          withDirectives(createVNode("input", {
                            type: "text",
                            id: "table-search-users",
                            "onUpdate:modelValue": ($event) => search.value = $event,
                            class: "block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
                            placeholder: "Search for users",
                            onKeyup: find
                          }, null, 40, ["onUpdate:modelValue"]), [
                            [vModelText, search.value]
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Kandidat "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " No Ujian "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Tanggal "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Status "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-center"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.interviews.data, (item) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: item.id
                            }, [
                              createVNode("th", {
                                scope: "row",
                                class: "flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"
                              }, [
                                createVNode("div", null, [
                                  createVNode("div", { class: "text-base font-semibold" }, toDisplayString(item.user.name), 1),
                                  createVNode("div", { class: "text-sm text-gray-500 font-semibold" }, " Email: " + toDisplayString(item.user.email), 1),
                                  createVNode("div", { class: "text-sm text-gray-500 font-semibold" }, " No. Hp: " + toDisplayString(item.user.phone), 1)
                                ])
                              ]),
                              createVNode("td", { class: "px-6 py-4 text-center" }, toDisplayString(item.no_exam), 1),
                              createVNode("td", { class: "px-6 py-4 text-center" }, toDisplayString(item.interview_date ? new Date(
                                item.interview_date
                              ).toLocaleDateString() : "-"), 1),
                              createVNode("td", { class: "px-6 py-4 capitalize truncate text-center" }, [
                                createVNode("span", {
                                  class: ["px-2 py-1 rounded-full", {
                                    "bg-green-100 text-green-800 dark:bg-green-500 dark:text-green-100": item.status === "approved",
                                    "bg-yellow-100 text-yellow-800 dark:bg-yellow-500 dark:text-yellow-100": item.status === "pending",
                                    "bg-red-100 text-red-800 dark:bg-red-500 dark:text-red-100": item.status === "rejected"
                                  }]
                                }, toDisplayString(item.status), 3)
                              ]),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex justify-center" }, [
                                  createVNode("button", {
                                    type: "button",
                                    class: "text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300",
                                    onClick: withModifiers(($event) => open(item), ["prevent"])
                                  }, [
                                    createVNode("i", { class: "fas fa-edit" })
                                  ], 8, ["onClick"])
                                ])
                              ])
                            ]);
                          }), 128))
                        ])
                      ]),
                      __props.interviews.data.length === 0 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "flex items-center justify-center p-4"
                      }, [
                        createVNode("p", { class: "text-gray-500 dark:text-gray-400 text-xs md:text-base" }, " Tidak ada yang mengajukan interview ")
                      ])) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "py-1 px-4" }, [
                      createVNode("nav", { class: "flex items-center space-x-1" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.interviews.links, (link) => {
                          return openBlock(), createBlock("button", {
                            type: "button",
                            class: "min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10",
                            "aria-current": "page",
                            key: link.label,
                            disabled: link.active,
                            onClick: withModifiers(($event) => navigateTo(link.url), ["prevent"])
                          }, [
                            createVNode("span", {
                              innerHTML: link.label,
                              class: "truncate"
                            }, null, 8, ["innerHTML"])
                          ], 8, ["disabled", "onClick"]);
                        }), 128))
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: modalStatus.value,
                  onClose: close
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, " Update Status Interview ")
                      ]),
                      createVNode("div", { class: "mt-4 grid grid-cols-1 gap-4" }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "status",
                            value: "Status"
                          }),
                          createVNode(_sfc_main$4, {
                            modelValue: unref(form).status,
                            "onUpdate:modelValue": ($event) => unref(form).status = $event,
                            class: "w-full",
                            "option-value": [
                              { label: "Pending", text: "pending" },
                              { label: "Approved", text: "approved" },
                              { label: "Rejected", text: "rejected" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.status
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "interview_date",
                            value: "Waktu interview"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "interview_date",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).interview_date,
                            "onUpdate:modelValue": ($event) => unref(form).interview_date = $event,
                            type: "datetime-local"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            class: "mt-2",
                            message: unref(form).errors.interview_date
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "note",
                            value: "Catatan Admin"
                          }),
                          createVNode(_sfc_main$7, {
                            modelValue: unref(form).note,
                            "onUpdate:modelValue": ($event) => unref(form).note = $event,
                            class: "w-full"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.note
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "mt-4 flex justify-end gap-3" }, [
                        createVNode(_sfc_main$8, { onClick: close }, {
                          default: withCtx(() => [
                            createTextVNode(" Batal ")
                          ]),
                          _: 1
                        }),
                        createVNode(PrimaryButton, {
                          onClick: save,
                          disabled: unref(form).processing
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Simpan ")
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Verification/Interview/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
