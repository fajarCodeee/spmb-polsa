import { ref, unref, withCtx, createTextVNode, createVNode, toDisplayString, openBlock, createBlock, createCommentVNode, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { useForm, Head, usePage } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$6 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$4 } from "./TextInput-f08fe8c3.js";
import "./NumberInput-74774052.js";
import { _ as _sfc_main$3 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$5 } from "./InputError-83b094c2.js";
import "./Combobox-8f85dcc2.js";
import "@vueform/multiselect";
/* empty css                                                            */import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Kelas",
  __ssrInlineRender: true,
  props: {
    kelas: {
      type: Object
    }
  },
  setup(__props) {
    const form = useForm({
      nama_kelas: ""
    });
    const dialogCreateKelas = ref(false);
    const dialogEditKelas = ref(false);
    const itemKelas = ref(null);
    const dialogDeleteKelas = ref(false);
    const createKelas = () => {
      if (dialogCreateKelas.value) {
        form.post(route("admin.kelas.store"), {
          preserveScroll: true,
          onSuccess: () => closeModal(),
          onError: () => nama_kelasInput.value.focus(),
          onFinish: () => form.reset()
        });
      } else {
        dialogCreateKelas.value = true;
      }
    };
    const editKelas = (item = null) => {
      if (dialogEditKelas.value) {
        form.patch(route("admin.kelas.update", { id: item }), {
          preserveScroll: true,
          onSuccess: () => closeModal(),
          onError: () => nama_kelasInput.value.focus(),
          onFinish: () => form.reset()
        });
      } else {
        dialogEditKelas.value = true;
        itemKelas.value = item;
        let findKelas = usePage().props.kelas.find(
          (item2) => item2.id == itemKelas.value
        );
        form.nama_kelas = findKelas.nama_kelas;
      }
    };
    const deleteKelas = (item = null) => {
      if (dialogDeleteKelas.value) {
        form.delete(route("admin.kelas.destroy", { id: item }), {
          preserveScroll: true,
          onSuccess: () => closeModal(),
          onError: () => nama_kelasInput.value.focus(),
          onFinish: () => form.reset()
        });
      } else {
        dialogDeleteKelas.value = true;
        itemKelas.value = item;
      }
    };
    const closeModal = () => {
      dialogCreateKelas.value = false;
      dialogEditKelas.value = false;
      dialogDeleteKelas.value = false;
      itemKelas.value = null;
      form.reset();
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Setting Kelas" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="shadow-md sm:shadow-lg p-4 sm:p-8 bg-white"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}> Kelas </h2></header>`);
            _push2(ssrRenderComponent(PrimaryButton, { onClick: createKelas }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Create`);
                } else {
                  return [
                    createTextVNode("Create")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="relative overflow-x-auto"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}>Nama Kelas</th><th scope="col" class="px-6 py-3"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.kelas, (kelas) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(kelas.nama_kelas)}</th><td class="px-6 py-4 flex gap-2"${_scopeId}><button class="text-indigo-600 hover:text-indigo-900"${_scopeId}><i class="fa-solid fa-pencil"${_scopeId}></i></button><button class="text-red-600 hover:text-red-900"${_scopeId}><i class="fa-solid fa-trash"${_scopeId}></i></button></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: dialogCreateKelas.value || dialogEditKelas.value || dialogDeleteKelas.value,
              onClose: closeModal
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId2}>${ssrInterpolate(dialogCreateKelas.value ? "Create" : "Edit")}</h2>`);
                  if (!dialogDeleteKelas.value) {
                    _push3(`<div class="mt-6 grid grid-cols-1 gap-4"${_scopeId2}><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "nama_kelas",
                      value: "Nama Kelas"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "nama_kelas",
                      ref: "nameInput",
                      modelValue: unref(form).nama_kelas,
                      "onUpdate:modelValue": ($event) => unref(form).nama_kelas = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      placeholder: "Reguler / Karyawan"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.nama_kelas,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="mt-6"${_scopeId2}>`);
                    if (dialogCreateKelas.value) {
                      _push3(ssrRenderComponent(PrimaryButton, { onClick: createKelas }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`Create`);
                          } else {
                            return [
                              createTextVNode("Create")
                            ];
                          }
                        }),
                        _: 1
                      }, _parent3, _scopeId2));
                    } else {
                      _push3(`<!---->`);
                    }
                    if (dialogEditKelas.value) {
                      _push3(ssrRenderComponent(PrimaryButton, {
                        onClick: ($event) => editKelas(itemKelas.value)
                      }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`Edit`);
                          } else {
                            return [
                              createTextVNode("Edit")
                            ];
                          }
                        }),
                        _: 1
                      }, _parent3, _scopeId2));
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      onClick: closeModal,
                      class: "ml-2"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Cancel `);
                        } else {
                          return [
                            createTextVNode(" Cancel ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  } else {
                    _push3(`<div${_scopeId2}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId2}> Are you sure you want to delete this kelas? </h2><div class="mt-6"${_scopeId2}>`);
                    if (dialogDeleteKelas.value) {
                      _push3(ssrRenderComponent(PrimaryButton, {
                        onClick: ($event) => deleteKelas(itemKelas.value)
                      }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`Delete `);
                          } else {
                            return [
                              createTextVNode("Delete ")
                            ];
                          }
                        }),
                        _: 1
                      }, _parent3, _scopeId2));
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      onClick: closeModal,
                      class: "ml-2"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Cancel `);
                        } else {
                          return [
                            createTextVNode(" Cancel ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  }
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(dialogCreateKelas.value ? "Create" : "Edit"), 1),
                      !dialogDeleteKelas.value ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-6 grid grid-cols-1 gap-4"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "nama_kelas",
                            value: "Nama Kelas"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "nama_kelas",
                            ref: "nameInput",
                            modelValue: unref(form).nama_kelas,
                            "onUpdate:modelValue": ($event) => unref(form).nama_kelas = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Reguler / Karyawan"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.nama_kelas,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "mt-6" }, [
                          dialogCreateKelas.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 0,
                            onClick: createKelas
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Create")
                            ]),
                            _: 1
                          })) : createCommentVNode("", true),
                          dialogEditKelas.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 1,
                            onClick: ($event) => editKelas(itemKelas.value)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Edit")
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true),
                          createVNode(_sfc_main$6, {
                            onClick: closeModal,
                            class: "ml-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          })
                        ])
                      ])) : (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Are you sure you want to delete this kelas? "),
                        createVNode("div", { class: "mt-6" }, [
                          dialogDeleteKelas.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 0,
                            onClick: ($event) => deleteKelas(itemKelas.value)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Delete ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true),
                          createVNode(_sfc_main$6, {
                            onClick: closeModal,
                            class: "ml-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          })
                        ])
                      ]))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "shadow-md sm:shadow-lg p-4 sm:p-8 bg-white" }, [
                    createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Kelas ")
                      ]),
                      createVNode(PrimaryButton, { onClick: createKelas }, {
                        default: withCtx(() => [
                          createTextVNode("Create")
                        ]),
                        _: 1
                      })
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Nama Kelas"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.kelas, (kelas) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: kelas.id
                            }, [
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(kelas.nama_kelas), 1),
                              createVNode("td", { class: "px-6 py-4 flex gap-2" }, [
                                createVNode("button", {
                                  onClick: ($event) => editKelas(kelas.id),
                                  class: "text-indigo-600 hover:text-indigo-900"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-pencil" })
                                ], 8, ["onClick"]),
                                createVNode("button", {
                                  onClick: ($event) => deleteKelas(kelas.id),
                                  class: "text-red-600 hover:text-red-900"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-trash" })
                                ], 8, ["onClick"])
                              ])
                            ]);
                          }), 128))
                        ])
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: dialogCreateKelas.value || dialogEditKelas.value || dialogDeleteKelas.value,
                  onClose: closeModal
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(dialogCreateKelas.value ? "Create" : "Edit"), 1),
                      !dialogDeleteKelas.value ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-6 grid grid-cols-1 gap-4"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "nama_kelas",
                            value: "Nama Kelas"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "nama_kelas",
                            ref: "nameInput",
                            modelValue: unref(form).nama_kelas,
                            "onUpdate:modelValue": ($event) => unref(form).nama_kelas = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Reguler / Karyawan"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.nama_kelas,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "mt-6" }, [
                          dialogCreateKelas.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 0,
                            onClick: createKelas
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Create")
                            ]),
                            _: 1
                          })) : createCommentVNode("", true),
                          dialogEditKelas.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 1,
                            onClick: ($event) => editKelas(itemKelas.value)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Edit")
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true),
                          createVNode(_sfc_main$6, {
                            onClick: closeModal,
                            class: "ml-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          })
                        ])
                      ])) : (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Are you sure you want to delete this kelas? "),
                        createVNode("div", { class: "mt-6" }, [
                          dialogDeleteKelas.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 0,
                            onClick: ($event) => deleteKelas(itemKelas.value)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Delete ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true),
                          createVNode(_sfc_main$6, {
                            onClick: closeModal,
                            class: "ml-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          })
                        ])
                      ]))
                    ])
                  ]),
                  _: 1
                }, 8, ["show"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Kelas.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
