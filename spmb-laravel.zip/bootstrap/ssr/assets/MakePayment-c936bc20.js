import { ref, mergeProps, unref, withCtx, createTextVNode, createVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderClass, ssrRenderComponent } from "vue/server-renderer";
import { Link } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "MakePayment",
  __ssrInlineRender: true,
  props: {
    wave: Object,
    amount: Number,
    code: String
  },
  setup(__props) {
    const statusCopy = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6" }, _attrs))}><div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg"><h2 class="font-bold text-left text-black text-2xl capitalize"> Pembayaran formulir pendaftaran </h2><p> Anda sudah mengajukan pendaftaran untuk tahun ajaran <span class="font-semibold">${ssrInterpolate(__props.wave.tahun_akademik)}</span>, silahkan melakukan pembayaran pendaftaran untuk melanjutkan proses pendaftaran </p><div class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8"><div class="shadow-md sm:shadow-lg p-4 sm:p-8"><h3 class="font-semibold text-left text-black text-xl capitalize"> Informasi Pembayaran </h3><p> Lakukan pembayaran sebesar <span class="font-semibold text-blue-700">${ssrInterpolate(new Intl.NumberFormat("id-ID", {
        style: "currency",
        currency: "IDR"
      }).format(__props.amount))}</span> ke rekening berikut: </p><div class="mt-4"><p class="font-semibold text-lg">${ssrInterpolate(_ctx.$page.props.web_settings.payment_bank)}</p><div class="inline-flex items-center gap-x-3"><div class="text-sm font-medium text-gray-800 dark:text-white">${ssrInterpolate(_ctx.$page.props.web_settings.payment_account)}</div><button type="button" class="p-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-white dark:hover:bg-gray-800 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="${ssrRenderClass([{
        "hidden ": statusCopy.value
      }, "w-4 h-4 group-hover:rotate-6 transition"])}"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"></rect><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path></svg><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="${ssrRenderClass([{
        "block ": statusCopy.value,
        hidden: !statusCopy.value
      }, "w-4 h-4 text-blue-600"])}"><polyline points="20 6 9 17 4 12"></polyline></svg></button></div><p>A.n ${ssrInterpolate(_ctx.$page.props.web_settings.payment_name)}</p><p class="mt-4"><span class="font-semibold text-base">Kode Pembayaran: </span><span class="font-semibold text-blue-700">${ssrInterpolate(__props.code)}</span></p><div class="flex justify-end gap-4 mt-8">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("form.payment"),
        as: "button",
        type: "button"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(PrimaryButton, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Upload Bukti Pembayaran`);
                } else {
                  return [
                    createTextVNode("Upload Bukti Pembayaran")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(PrimaryButton, null, {
                default: withCtx(() => [
                  createTextVNode("Upload Bukti Pembayaran")
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div><div class="shadow-md sm:shadow-lg p-4 sm:p-8"><h3 class="font-semibold text-left text-black text-xl capitalize"> Catatan Sebelum melakukan pembayaran </h3><div class="mt-4"><ul class="max-w-md space-y-1 text-gray-500 list-disc list-inside dark:text-gray-400"><li> Apabila pembayaran melalui setor tunai ke ${ssrInterpolate(_ctx.$page.props.web_settings.payment_bank)} ataupun beda BANK, anda harus menuliskan kode pembayaran pada kolom &quot;catatan&quot; atau &quot;berita untuk penerima&quot; pada slip setoran </li><li> Untuk pembayaran melalui mesin ATM harus mengupload struk transfer dengan menuliskan kode pembayaran pada struk tersebut </li></ul></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Submission/Partials/MakePayment.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
