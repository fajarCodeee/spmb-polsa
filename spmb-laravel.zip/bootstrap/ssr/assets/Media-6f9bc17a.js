import { ref, unref, withCtx, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { useForm, Head } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { _ as _sfc_main$5 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$3 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$4 } from "./InputError-83b094c2.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Media",
  __ssrInlineRender: true,
  props: {
    brosur: String,
    rincian_biaya: String
  },
  setup(__props) {
    const file = ref(null);
    const url = ref(null);
    const form = useForm({
      brosur: null,
      rincian_biaya: null
    });
    const form_type = [
      "brosur",
      "rincian_biaya"
    ];
    const onFileChange = (e) => {
      file.value = e.target.files[0];
      form[dialogItem.value] = e.target.files[0];
      if (file.value) {
        url.value = URL.createObjectURL(file.value);
      } else {
        url.value = null;
      }
    };
    const dialog = ref(false);
    const dialogIndex = ref(null);
    const dialogItem = ref(null);
    const open = (type, item = null) => {
      dialogItem.value = item;
      dialog.value = true;
      dialogIndex.value = type;
    };
    const close = () => {
      dialog.value = false;
      dialogItem.value = null;
      dialogIndex.value = null;
      url.value = null;
      file.value = null;
      form.reset();
    };
    const save = () => {
      form.post(route("admin.media.update"), {
        onSuccess: () => {
          close();
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Media" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="bg-white p-4 shadow-md rounded-lg"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-lg font-bold text-gray-900 dark:text-gray-100"${_scopeId}> Media </h2></header></div><div class="relative overflow-x-auto shadow-md sm:rounded-lg"${_scopeId}><div class="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4"${_scopeId}><!--[-->`);
            ssrRenderList(form_type, (document, index) => {
              _push2(`<div class="dark:bg-gray-800 rounded-lg shadow-md p-4"${_scopeId}><header${_scopeId}><h3 class="font-semibold text-gray-900 dark:text-gray-100 capitalize"${_scopeId}>${ssrInterpolate(document.replace("_", " "))}</h3></header><button class="mt-4 h-40 w-full hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg overflow-hidden"${_scopeId}>`);
              if (_ctx.$page.props[document]) {
                _push2(`<img${ssrRenderAttr("src", _ctx.$page.props[document])}${ssrRenderAttr("alt", document)} class="overflow-hidden object-cover w-full h-full rounded-lg"${_scopeId}>`);
              } else {
                _push2(`<div class="flex items-center justify-center h-full"${_scopeId}><p class="text-gray-400"${_scopeId}> Belum ada ${ssrInterpolate(document.replace("_", " "))} yang diunggah </p></div>`);
              }
              _push2(`</button></div>`);
            });
            _push2(`<!--]--></div></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: dialog.value,
              onClose: ($event) => close()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 capitalize"${_scopeId2}> Edit ${ssrInterpolate(dialogItem.value.replace("_", " "))}</h2><div class="mt-6 grid grid-cols-1 gap-4"${_scopeId2}><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    class: "capitalize",
                    for: "name"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${ssrInterpolate(dialogItem.value.replace("_", " "))}`);
                      } else {
                        return [
                          createTextVNode(toDisplayString(dialogItem.value.replace("_", " ")), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="flex items-center justify-center w-full"${_scopeId2}><label for="dropzone-file" class="flex flex-col items-center justify-center w-full h-auto border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"${_scopeId2}>`);
                  if (!url.value) {
                    _push3(`<div class="flex flex-col items-center justify-center pt-5 pb-6"${_scopeId2}><i class="fa-solid fa-cloud-arrow-up text-lg"${_scopeId2}></i><p class="mb-2 text-sm text-gray-500 dark:text-gray-400"${_scopeId2}><span class="font-semibold"${_scopeId2}>Click to upload</span> or drag and drop </p><p class="text-xs text-red-500 dark:text-gray-400"${_scopeId2}> Mohon upload gambar dalam format gambar </p></div>`);
                  } else {
                    _push3(`<div class="flex flex-col items-center justify-center pt-5 pb-6"${_scopeId2}><img${ssrRenderAttr("src", url.value)}${ssrRenderAttr("alt", dialogItem.value)} class="object-contain w-full h-full"${_scopeId2}></div>`);
                  }
                  _push3(`<input id="dropzone-file" type="file" class="hidden" accept="image/*"${_scopeId2}></label></div>`);
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    message: unref(form).errors[dialogItem.value],
                    class: "mt-2"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div></div><div class="mt-6"${_scopeId2}><div class="flex justify-end"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$5, {
                    onClick: ($event) => close()
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Cancel `);
                      } else {
                        return [
                          createTextVNode(" Cancel ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(PrimaryButton, {
                    class: "ml-2",
                    onClick: ($event) => save()
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` save `);
                      } else {
                        return [
                          createTextVNode(" save ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100 capitalize" }, " Edit " + toDisplayString(dialogItem.value.replace("_", " ")), 1),
                      createVNode("div", { class: "mt-6 grid grid-cols-1 gap-4" }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            class: "capitalize",
                            for: "name"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(dialogItem.value.replace("_", " ")), 1)
                            ]),
                            _: 1
                          }),
                          createVNode("div", { class: "flex items-center justify-center w-full" }, [
                            createVNode("label", {
                              for: "dropzone-file",
                              class: "flex flex-col items-center justify-center w-full h-auto border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
                            }, [
                              !url.value ? (openBlock(), createBlock("div", {
                                key: 0,
                                class: "flex flex-col items-center justify-center pt-5 pb-6"
                              }, [
                                createVNode("i", { class: "fa-solid fa-cloud-arrow-up text-lg" }),
                                createVNode("p", { class: "mb-2 text-sm text-gray-500 dark:text-gray-400" }, [
                                  createVNode("span", { class: "font-semibold" }, "Click to upload"),
                                  createTextVNode(" or drag and drop ")
                                ]),
                                createVNode("p", { class: "text-xs text-red-500 dark:text-gray-400" }, " Mohon upload gambar dalam format gambar ")
                              ])) : (openBlock(), createBlock("div", {
                                key: 1,
                                class: "flex flex-col items-center justify-center pt-5 pb-6"
                              }, [
                                createVNode("img", {
                                  src: url.value,
                                  alt: dialogItem.value,
                                  class: "object-contain w-full h-full"
                                }, null, 8, ["src", "alt"])
                              ])),
                              createVNode("input", {
                                id: "dropzone-file",
                                type: "file",
                                class: "hidden",
                                accept: "image/*",
                                onChange: onFileChange
                              }, null, 32)
                            ])
                          ]),
                          createVNode(_sfc_main$4, {
                            message: unref(form).errors[dialogItem.value],
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode(_sfc_main$5, {
                            onClick: ($event) => close()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(PrimaryButton, {
                            class: "ml-2",
                            onClick: ($event) => save()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" save ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "bg-white p-4 shadow-md rounded-lg" }, [
                    createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap items-center justify-between pb-4" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-lg font-bold text-gray-900 dark:text-gray-100" }, " Media ")
                      ])
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg" }, [
                      createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 gap-4 p-4" }, [
                        (openBlock(), createBlock(Fragment, null, renderList(form_type, (document, index) => {
                          return createVNode("div", {
                            class: "dark:bg-gray-800 rounded-lg shadow-md p-4",
                            key: index
                          }, [
                            createVNode("header", null, [
                              createVNode("h3", { class: "font-semibold text-gray-900 dark:text-gray-100 capitalize" }, toDisplayString(document.replace("_", " ")), 1)
                            ]),
                            createVNode("button", {
                              class: "mt-4 h-40 w-full hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg overflow-hidden",
                              onClick: ($event) => open(1, document)
                            }, [
                              _ctx.$page.props[document] ? (openBlock(), createBlock("img", {
                                key: 0,
                                src: _ctx.$page.props[document],
                                alt: document,
                                class: "overflow-hidden object-cover w-full h-full rounded-lg"
                              }, null, 8, ["src", "alt"])) : (openBlock(), createBlock("div", {
                                key: 1,
                                class: "flex items-center justify-center h-full"
                              }, [
                                createVNode("p", { class: "text-gray-400" }, " Belum ada " + toDisplayString(document.replace("_", " ")) + " yang diunggah ", 1)
                              ]))
                            ], 8, ["onClick"])
                          ]);
                        }), 64))
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: dialog.value,
                  onClose: ($event) => close()
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100 capitalize" }, " Edit " + toDisplayString(dialogItem.value.replace("_", " ")), 1),
                      createVNode("div", { class: "mt-6 grid grid-cols-1 gap-4" }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            class: "capitalize",
                            for: "name"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(dialogItem.value.replace("_", " ")), 1)
                            ]),
                            _: 1
                          }),
                          createVNode("div", { class: "flex items-center justify-center w-full" }, [
                            createVNode("label", {
                              for: "dropzone-file",
                              class: "flex flex-col items-center justify-center w-full h-auto border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
                            }, [
                              !url.value ? (openBlock(), createBlock("div", {
                                key: 0,
                                class: "flex flex-col items-center justify-center pt-5 pb-6"
                              }, [
                                createVNode("i", { class: "fa-solid fa-cloud-arrow-up text-lg" }),
                                createVNode("p", { class: "mb-2 text-sm text-gray-500 dark:text-gray-400" }, [
                                  createVNode("span", { class: "font-semibold" }, "Click to upload"),
                                  createTextVNode(" or drag and drop ")
                                ]),
                                createVNode("p", { class: "text-xs text-red-500 dark:text-gray-400" }, " Mohon upload gambar dalam format gambar ")
                              ])) : (openBlock(), createBlock("div", {
                                key: 1,
                                class: "flex flex-col items-center justify-center pt-5 pb-6"
                              }, [
                                createVNode("img", {
                                  src: url.value,
                                  alt: dialogItem.value,
                                  class: "object-contain w-full h-full"
                                }, null, 8, ["src", "alt"])
                              ])),
                              createVNode("input", {
                                id: "dropzone-file",
                                type: "file",
                                class: "hidden",
                                accept: "image/*",
                                onChange: onFileChange
                              }, null, 32)
                            ])
                          ]),
                          createVNode(_sfc_main$4, {
                            message: unref(form).errors[dialogItem.value],
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode(_sfc_main$5, {
                            onClick: ($event) => close()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(PrimaryButton, {
                            class: "ml-2",
                            onClick: ($event) => save()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" save ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show", "onClose"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Media.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
