import { mergeProps, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./Display-b7d04753.js";
import { _ as _sfc_main$2 } from "./SecondaryButton-33aab301.js";
const _sfc_main = {
  __name: "ModalView",
  __ssrInlineRender: true,
  props: {
    item: Object,
    close: Function
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-6" }, _attrs))}><h1 class="text-2xl font-semibold">Formulir</h1><div class="mt-4 flex flex-col gap-4"><div class="grid grid-cols-1 md:grid-cols-2 gap-3"><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        label: "Nama",
        value: __props.item.form.name
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        label: "Email",
        value: __props.item.form.email
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        label: "No. Hp",
        value: __props.item.form.phone
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        label: "Nomor Pendaftaran",
        value: (_a = __props.item.form) == null ? void 0 : _a.no_exam
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        label: "Nilai Rata Rata Ijazah",
        value: __props.item.form.grade
      }, null, _parent));
      _push(`</div></div><div class="grid grid-cols-1 md:grid-cols-2 gap-3"><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        label: "Pilihan Prodi",
        value: (_b = __props.item.prodi) == null ? void 0 : _b.nama_prodi
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        label: "Status Formulir",
        value: (_c = __props.item.form) == null ? void 0 : _c.status
      }, null, _parent));
      _push(`</div></div>`);
      if (__props.item.prodi.tes_kesehatan) {
        _push(`<div class="border-2 border-gray-200 dark:border-gray-700 rounded-lg p-4 mt-4"><label class="block text-xl font-medium text-gray-700 border-b-2 border-gray-200 dark:text-gray-300"> Kesehatan </label><div class="flex flex-col gap-3"><div>`);
        _push(ssrRenderComponent(_sfc_main$1, {
          label: "Status",
          value: (_d = __props.item.health) == null ? void 0 : _d.status
        }, null, _parent));
        _push(`</div><div>`);
        _push(ssrRenderComponent(_sfc_main$1, {
          label: "Catatan Admin",
          value: (_e = __props.item.health) == null ? void 0 : _e.admin_note
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.item.prodi.tes_wawancara) {
        _push(`<div class="border-2 border-gray-200 dark:border-gray-700 rounded-lg p-4 mt-4"><label class="block text-xl font-medium text-gray-700 border-b-2 border-gray-200 dark:text-gray-300"> Inteview </label><div class="flex flex-col gap-3"><div>`);
        _push(ssrRenderComponent(_sfc_main$1, {
          label: "Status",
          value: (_f = __props.item.interview) == null ? void 0 : _f.status
        }, null, _parent));
        _push(`</div><div>`);
        _push(ssrRenderComponent(_sfc_main$1, {
          label: "Catatan Admin",
          value: (_g = __props.item.interview) == null ? void 0 : _g.note
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.item.prodi.tes_ujian) {
        _push(`<div class="border-2 border-gray-200 dark:border-gray-700 rounded-lg p-4 mt-4"><label class="block text-xl font-medium text-gray-700 border-b-2 border-gray-200 dark:text-gray-300"> Ujian </label><div class="mt-8"><div class="relative overflow-x-auto"><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"><tr><th scope="col" class="px-6 py-3"> Nama Ujian </th><th scope="col" class="px-6 py-3">Score</th></tr></thead>`);
        if (__props.item.form.grade < __props.item.prodi.nilai_dibawah) {
          _push(`<tbody><!--[-->`);
          ssrRenderList(__props.item.exam, (i, index) => {
            var _a2;
            _push(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700"><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">${ssrInterpolate((_a2 = i.exam) == null ? void 0 : _a2.name)}</th><td class="px-6 py-4">${ssrInterpolate(i == null ? void 0 : i.score)}</td></tr>`);
          });
          _push(`<!--]--></tbody>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</table><div class="mt-4">`);
        if (__props.item.form.grade && __props.item.form.grade > __props.item.prodi.nilai_dibawah) {
          _push(`<div class="flex items-center justify-center p-4"><p class="text-gray-500 dark:text-gray-400"> Nilai diatas batas minimal </p></div>`);
        } else if (__props.item.prodi.ujian && ((_h = __props.item.prodi.ujian) == null ? void 0 : _h.split(",").length) > __props.item.exam.length) {
          _push(`<div class="flex items-center justify-center p-4"><p class="text-gray-500 dark:text-gray-400"> Ada ${ssrInterpolate(((_i = __props.item.prodi.ujian) == null ? void 0 : _i.split(",").length) - __props.item.exam.length)} ujian yang belum dikerjakan </p></div>`);
        } else if (__props.item.exam.length === 0) {
          _push(`<div class="flex items-center justify-center p-4"><p class="text-gray-500 dark:text-gray-400"> Tidak ada data </p></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="mt-4 flex justify-end">`);
      _push(ssrRenderComponent(_sfc_main$2, { onClick: __props.close }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Tutup `);
          } else {
            return [
              createTextVNode(" Tutup ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Verification/End/Partials/ModalView.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
