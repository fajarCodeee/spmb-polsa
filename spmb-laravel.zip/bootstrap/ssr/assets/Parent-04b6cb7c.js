import { unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderList, ssrInterpolate, ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$4 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$1 } from "./InputLabel-5e383564.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$3 } from "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$2 } from "./DateInput-00587317.js";
import { usePage, useForm } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Parent",
  __ssrInlineRender: true,
  props: {
    mustVerifyEmail: {
      type: Boolean
    },
    status: {
      type: String
    }
  },
  setup(__props) {
    usePage().props.auth.user;
    const form_data = usePage().props.form;
    const form = useForm({
      familyMembers: [
        {
          role: "father",
          name: form_data.father_name || "",
          birth_date: form_data.father_birth_date || "",
          place: form_data.father_place || "",
          last_education: form_data.father_last_education || "",
          job: form_data.father_job || "",
          phone: form_data.father_phone || "",
          email: form_data.father_email || ""
        },
        {
          role: "mother",
          name: form_data.mother_name || "",
          birth_date: form_data.mother_birth_date || "",
          place: form_data.mother_place || "",
          last_education: form_data.mother_last_education || "",
          job: form_data.mother_job || "",
          phone: form_data.mother_phone || "",
          email: form_data.mother_email || ""
        },
        {
          role: "guardian",
          name: form_data.guardian_name || "",
          birth_date: form_data.guardian_birth_date || "",
          place: form_data.guardian_place || "",
          last_education: form_data.guardian_last_education || "",
          job: form_data.guardian_job || "",
          phone: form_data.guardian_phone || "",
          email: form_data.guardian_email || "",
          relation: form_data.guardian_relation || ""
        }
      ]
    }).transform((data) => {
      const transformedData = {};
      data.familyMembers.forEach((person) => {
        const prefix = person.role.toLowerCase();
        Object.keys(person).forEach((key) => {
          if (key !== "role" && person[key]) {
            const newKey = `${prefix}_${key}`;
            transformedData[newKey] = person[key];
          }
        });
      });
      return transformedData;
    });
    const memberFields = {
      name: "Nama",
      birth_date: "Tanggal Lahir",
      place: "Tempat Lahir",
      last_education: "Pendidikan Terakhir",
      job: "Pekerjaan",
      phone: "Nomor Telepon",
      email: "Email"
    };
    const getFieldId = (role, field) => {
      return `${role}_${field}`;
    };
    const capitalize = (string) => {
      return string.charAt(0).toUpperCase() + string.slice(1);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(_attrs)}><header><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"> Orang Tua / Wali </h2><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"> Update data orang tua / wali. </p></header><form class="mt-6 space-y-6"><!--[-->`);
      ssrRenderList(unref(form).familyMembers, (member) => {
        _push(`<div><h3 class="text-black dark:text-white font-bold text-1xl">${ssrInterpolate(
          // member.role.charAt(0).toUpperCase() +
          // member.role.slice(1)
          member.role === "father" ? "Ayah" : member.role === "mother" ? "Ibu" : member.role === "guardian" ? "Wali" : ""
        )}</h3><div class="grid grid-cols-1 md:grid-cols-4 gap-4"><!--[-->`);
        ssrRenderList(Object.keys(memberFields), (field) => {
          _push(`<div class="col-span-2">`);
          _push(ssrRenderComponent(_sfc_main$1, {
            for: "getFieldId(member.role, field)",
            value: capitalize(memberFields[field])
          }, null, _parent));
          if (field === "birth_date") {
            _push(ssrRenderComponent(_sfc_main$2, {
              id: getFieldId(member.role, field),
              class: "mt-1 block w-full",
              modelValue: member[field],
              "onUpdate:modelValue": ($event) => member[field] = $event
            }, null, _parent));
          } else if (field === "phone") {
            _push(ssrRenderComponent(_sfc_main$3, {
              id: getFieldId(member.role, field),
              type: "number",
              class: "mt-1 block w-full [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none",
              modelValue: member[field],
              "onUpdate:modelValue": ($event) => member[field] = $event
            }, null, _parent));
          } else if (field === "email") {
            _push(ssrRenderComponent(_sfc_main$3, {
              id: getFieldId(member.role, field),
              type: "email",
              class: "mt-1 block w-full",
              modelValue: member[field],
              "onUpdate:modelValue": ($event) => member[field] = $event
            }, null, _parent));
          } else {
            _push(ssrRenderComponent(_sfc_main$3, {
              id: getFieldId(member.role, field),
              type: "text",
              class: "mt-1 block w-full",
              modelValue: member[field],
              "onUpdate:modelValue": ($event) => member[field] = $event
            }, null, _parent));
          }
          _push(ssrRenderComponent(_sfc_main$4, {
            class: "mt-2",
            message: unref(form).errors[field]
          }, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div></div>`);
      });
      _push(`<!--]--><div class="flex justify-end gap-4">`);
      _push(ssrRenderComponent(PrimaryButton, {
        disabled: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Save`);
          } else {
            return [
              createTextVNode("Save")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></form></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Form/Partials/Parent.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
