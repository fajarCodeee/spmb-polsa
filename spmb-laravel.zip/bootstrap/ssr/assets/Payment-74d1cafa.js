import { ref, onMounted, unref, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrRenderAttr, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { useForm, Head, router } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$9 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$5 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$7 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$6 } from "./Combobox-8f85dcc2.js";
import { _ as _sfc_main$8 } from "./TextareaInput-ea5736c3.js";
import { _ as _sfc_main$3 } from "./Grid-9e8ae324.js";
import { _ as _sfc_main$4 } from "./Display-b7d04753.js";
import "./SearchForm-7aa89cac.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Payment",
  __ssrInlineRender: true,
  props: {
    payment: {
      type: Array
    }
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      status: "",
      // approved, pending, rejected
      note: ""
    });
    const dialogIndex = ref(null);
    const dialog = ref(false);
    const dialogItem = ref(null);
    const open = (index, item = null) => {
      dialogIndex.value = index;
      dialogItem.value = item;
      dialog.value = true;
      if (index == 1) {
        form.status = item.status;
        form.note = item.note;
      }
    };
    const close = () => {
      dialog.value = false;
      dialogIndex.value = null;
      dialogItem.value = null;
    };
    const save = () => {
      if (dialogIndex.value == 0)
        ;
      else if (dialogIndex.value == 1) {
        form.patch(route("admin.payment.update", dialogItem.value.id), {
          preserveScroll: true,
          onSuccess: () => {
            close();
          }
        });
      } else if (dialogIndex.value == 2) {
        form.delete(route("admin.payment.destroy", dialogItem.value.id), {
          preserveScroll: true,
          onSuccess: () => {
            close();
          }
        });
      }
    };
    onMounted(() => {
      console.log(props.payment.data);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Pembayaran" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="shadow-md sm:shadow-lg p-4 sm:p-8 bg-white"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-lg font-bold text-gray-900 dark:text-gray-100"${_scopeId}> Kelola Pembayaran </h2></header></div><div class="relative overflow-x-auto"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}>Bank</th><th scope="col" class="px-6 py-3"${_scopeId}> Nama Rekening </th><th scope="col" class="px-6 py-3"${_scopeId}> Nomor Rekening </th><th scope="col" class="px-6 py-3"${_scopeId}> Kode Pembayaran </th><th scope="col" class="px-6 py-3"${_scopeId}> Jumlah </th><th scope="col" class="px-6 py-3"${_scopeId}> Tanggal </th><th scope="col" class="px-6 py-3"${_scopeId}> Status </th><th scope="col" class="relative px-6 py-3"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(props.payment.data, (item) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(item.bank)}</th><td class="px-6 py-4 truncate"${_scopeId}>${ssrInterpolate(item.account_name)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(item.account_number)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(item.code)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(new Intl.NumberFormat("id-ID", {
                style: "currency",
                currency: "IDR"
              }).format(item.amount) || 0)}</td><td class="px-6 py-4 truncate"${_scopeId}>${ssrInterpolate(item.date)}</td><td class="px-6 py-4"${_scopeId}><i class="${ssrRenderClass([{
                "text-green-500": item.status == "approved",
                "text-yellow-500": item.status == "pending",
                "text-red-500": item.status == "rejected"
              }, "fas fa-circle"])}"${_scopeId}></i></td><td class="px-6 py-4"${_scopeId}><div class="flex gap-2"${_scopeId}><button class="text-indigo-600 hover:text-indigo-900"${_scopeId}><i class="fa-solid fa-pencil"${_scopeId}></i></button><button class="text-red-600 hover:text-red-900"${_scopeId}><i class="fa-solid fa-trash"${_scopeId}></i></button></div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div><div class="py-1 px-4"${_scopeId}><nav class="flex items-center space-x-1"${_scopeId}><!--[-->`);
            ssrRenderList(__props.payment.links, (link) => {
              _push2(`<button class="${ssrRenderClass([{
                "cursor-not-allowed opacity-50": link.active || !link.url
              }, "min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10"])}"${ssrRenderAttr("href", link.url || "")}${ssrIncludeBooleanAttr(link.active) ? " disabled" : ""}${_scopeId}><span class="truncate"${_scopeId}>${link.label}</span></button>`);
            });
            _push2(`<!--]--></nav></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: dialog.value,
              onClose: ($event) => close()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId2}>${ssrInterpolate(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Kelola Pembayaran" : "Hapus Pembayaran")}</h2>`);
                  if (dialogIndex.value != 2) {
                    _push3(`<div class="mt-6 grid grid-cols-1 gap-4"${_scopeId2}><div class="col-span-1"${_scopeId2}><img${ssrRenderAttr("src", dialogItem.value.image)}${ssrRenderAttr("alt", `Bukti pembayaran ${console.log(dialogItem.value)}`)} class="w-full"${_scopeId2}></div>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      col: "3",
                      class: "mt-4 mb-6"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        var _a, _b, _c, _d;
                        if (_push4) {
                          _push4(ssrRenderComponent(_sfc_main$4, {
                            label: "Pilihan Prodi",
                            value: (_a = dialogItem.value) == null ? void 0 : _a.prodi.nama_prodi
                          }, null, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(_sfc_main$4, {
                            label: "Jumlah",
                            value: new Intl.NumberFormat("id-ID", {
                              style: "currency",
                              currency: "IDR"
                            }).format(
                              (_b = dialogItem.value) == null ? void 0 : _b.amount
                            )
                          }, null, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(_sfc_main$4, {
                            label: "Kode Pembayaran",
                            value: dialogItem.value.code
                          }, null, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(_sfc_main$4, {
                            label: "Tipe Pembayaran",
                            value: dialogItem.value.type_payment == "registration" ? "Registrasi" : "Pendaftaran"
                          }, null, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(_sfc_main$4, {
                              label: "Pilihan Prodi",
                              value: (_c = dialogItem.value) == null ? void 0 : _c.prodi.nama_prodi
                            }, null, 8, ["value"]),
                            createVNode(_sfc_main$4, {
                              label: "Jumlah",
                              value: new Intl.NumberFormat("id-ID", {
                                style: "currency",
                                currency: "IDR"
                              }).format(
                                (_d = dialogItem.value) == null ? void 0 : _d.amount
                              )
                            }, null, 8, ["value"]),
                            createVNode(_sfc_main$4, {
                              label: "Kode Pembayaran",
                              value: dialogItem.value.code
                            }, null, 8, ["value"]),
                            createVNode(_sfc_main$4, {
                              label: "Tipe Pembayaran",
                              value: dialogItem.value.type_payment == "registration" ? "Registrasi" : "Pendaftaran"
                            }, null, 8, ["value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`<div class="col-span-1"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$5, { for: "status" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Status`);
                        } else {
                          return [
                            createTextVNode("Status")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      modelValue: unref(form).status,
                      "onUpdate:modelValue": ($event) => unref(form).status = $event,
                      id: "status",
                      class: "mt-1 block w-full",
                      "option-value": [
                        { value: "approved", text: "Approved" },
                        { value: "pending", text: "Pending" },
                        { value: "rejected", text: "Rejected" }
                      ]
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$7, {
                      message: unref(form).errors.status
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-1"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$5, { for: "note" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Catatan`);
                        } else {
                          return [
                            createTextVNode("Catatan")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$8, {
                      modelValue: unref(form).note,
                      "onUpdate:modelValue": ($event) => unref(form).note = $event,
                      id: "note",
                      class: "mt-1 block w-full"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$7, {
                      message: unref(form).errors.note
                    }, null, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  } else {
                    _push3(`<div${_scopeId2}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId2}> Anda yakin ingin menghapus pembayaran ini? </h2></div>`);
                  }
                  _push3(`<div class="mt-6"${_scopeId2}>`);
                  _push3(ssrRenderComponent(PrimaryButton, {
                    onClick: ($event) => save()
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${ssrInterpolate(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete")}`);
                      } else {
                        return [
                          createTextVNode(toDisplayString(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$9, {
                    onClick: close,
                    class: "ml-2"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Cancel `);
                      } else {
                        return [
                          createTextVNode(" Cancel ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Kelola Pembayaran" : "Hapus Pembayaran"), 1),
                      dialogIndex.value != 2 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-6 grid grid-cols-1 gap-4"
                      }, [
                        createVNode("div", { class: "col-span-1" }, [
                          createVNode("img", {
                            src: dialogItem.value.image,
                            alt: `Bukti pembayaran ${console.log(dialogItem.value)}`,
                            class: "w-full"
                          }, null, 8, ["src", "alt"])
                        ]),
                        createVNode(_sfc_main$3, {
                          col: "3",
                          class: "mt-4 mb-6"
                        }, {
                          default: withCtx(() => {
                            var _a, _b;
                            return [
                              createVNode(_sfc_main$4, {
                                label: "Pilihan Prodi",
                                value: (_a = dialogItem.value) == null ? void 0 : _a.prodi.nama_prodi
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$4, {
                                label: "Jumlah",
                                value: new Intl.NumberFormat("id-ID", {
                                  style: "currency",
                                  currency: "IDR"
                                }).format(
                                  (_b = dialogItem.value) == null ? void 0 : _b.amount
                                )
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$4, {
                                label: "Kode Pembayaran",
                                value: dialogItem.value.code
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$4, {
                                label: "Tipe Pembayaran",
                                value: dialogItem.value.type_payment == "registration" ? "Registrasi" : "Pendaftaran"
                              }, null, 8, ["value"])
                            ];
                          }),
                          _: 1
                        }),
                        createVNode("div", { class: "col-span-1" }, [
                          createVNode(_sfc_main$5, { for: "status" }, {
                            default: withCtx(() => [
                              createTextVNode("Status")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$6, {
                            modelValue: unref(form).status,
                            "onUpdate:modelValue": ($event) => unref(form).status = $event,
                            id: "status",
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: "approved", text: "Approved" },
                              { value: "pending", text: "Pending" },
                              { value: "rejected", text: "Rejected" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$7, {
                            message: unref(form).errors.status
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "col-span-1" }, [
                          createVNode(_sfc_main$5, { for: "note" }, {
                            default: withCtx(() => [
                              createTextVNode("Catatan")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$8, {
                            modelValue: unref(form).note,
                            "onUpdate:modelValue": ($event) => unref(form).note = $event,
                            id: "note",
                            class: "mt-1 block w-full"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$7, {
                            message: unref(form).errors.note
                          }, null, 8, ["message"])
                        ])
                      ])) : (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Anda yakin ingin menghapus pembayaran ini? ")
                      ])),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode(PrimaryButton, {
                          onClick: ($event) => save()
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete"), 1)
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_sfc_main$9, {
                          onClick: close,
                          class: "ml-2"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Cancel ")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "shadow-md sm:shadow-lg p-4 sm:p-8 bg-white" }, [
                    createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-lg font-bold text-gray-900 dark:text-gray-100" }, " Kelola Pembayaran ")
                      ])
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Bank"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Nama Rekening "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Nomor Rekening "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Kode Pembayaran "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Jumlah "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Tanggal "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Status "),
                            createVNode("th", {
                              scope: "col",
                              class: "relative px-6 py-3"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(props.payment.data, (item) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: item.id
                            }, [
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(item.bank), 1),
                              createVNode("td", { class: "px-6 py-4 truncate" }, toDisplayString(item.account_name), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(item.account_number), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(item.code), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(new Intl.NumberFormat("id-ID", {
                                style: "currency",
                                currency: "IDR"
                              }).format(item.amount) || 0), 1),
                              createVNode("td", { class: "px-6 py-4 truncate" }, toDisplayString(item.date), 1),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("i", {
                                  class: ["fas fa-circle", {
                                    "text-green-500": item.status == "approved",
                                    "text-yellow-500": item.status == "pending",
                                    "text-red-500": item.status == "rejected"
                                  }]
                                }, null, 2)
                              ]),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex gap-2" }, [
                                  createVNode("button", {
                                    onClick: ($event) => open(1, item),
                                    class: "text-indigo-600 hover:text-indigo-900"
                                  }, [
                                    createVNode("i", { class: "fa-solid fa-pencil" })
                                  ], 8, ["onClick"]),
                                  createVNode("button", {
                                    onClick: ($event) => open(2, item),
                                    class: "text-red-600 hover:text-red-900"
                                  }, [
                                    createVNode("i", { class: "fa-solid fa-trash" })
                                  ], 8, ["onClick"])
                                ])
                              ])
                            ]);
                          }), 128))
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "py-1 px-4" }, [
                      createVNode("nav", { class: "flex items-center space-x-1" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.payment.links, (link) => {
                          return openBlock(), createBlock("button", {
                            class: ["min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10", {
                              "cursor-not-allowed opacity-50": link.active || !link.url
                            }],
                            key: link.label,
                            href: link.url || "",
                            disabled: link.active,
                            onClick: withModifiers(($event) => unref(router).visit(link.url), ["prevent"])
                          }, [
                            createVNode("span", {
                              innerHTML: link.label,
                              class: "truncate"
                            }, null, 8, ["innerHTML"])
                          ], 10, ["href", "disabled", "onClick"]);
                        }), 128))
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: dialog.value,
                  onClose: ($event) => close()
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Kelola Pembayaran" : "Hapus Pembayaran"), 1),
                      dialogIndex.value != 2 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-6 grid grid-cols-1 gap-4"
                      }, [
                        createVNode("div", { class: "col-span-1" }, [
                          createVNode("img", {
                            src: dialogItem.value.image,
                            alt: `Bukti pembayaran ${console.log(dialogItem.value)}`,
                            class: "w-full"
                          }, null, 8, ["src", "alt"])
                        ]),
                        createVNode(_sfc_main$3, {
                          col: "3",
                          class: "mt-4 mb-6"
                        }, {
                          default: withCtx(() => {
                            var _a, _b;
                            return [
                              createVNode(_sfc_main$4, {
                                label: "Pilihan Prodi",
                                value: (_a = dialogItem.value) == null ? void 0 : _a.prodi.nama_prodi
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$4, {
                                label: "Jumlah",
                                value: new Intl.NumberFormat("id-ID", {
                                  style: "currency",
                                  currency: "IDR"
                                }).format(
                                  (_b = dialogItem.value) == null ? void 0 : _b.amount
                                )
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$4, {
                                label: "Kode Pembayaran",
                                value: dialogItem.value.code
                              }, null, 8, ["value"]),
                              createVNode(_sfc_main$4, {
                                label: "Tipe Pembayaran",
                                value: dialogItem.value.type_payment == "registration" ? "Registrasi" : "Pendaftaran"
                              }, null, 8, ["value"])
                            ];
                          }),
                          _: 1
                        }),
                        createVNode("div", { class: "col-span-1" }, [
                          createVNode(_sfc_main$5, { for: "status" }, {
                            default: withCtx(() => [
                              createTextVNode("Status")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$6, {
                            modelValue: unref(form).status,
                            "onUpdate:modelValue": ($event) => unref(form).status = $event,
                            id: "status",
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: "approved", text: "Approved" },
                              { value: "pending", text: "Pending" },
                              { value: "rejected", text: "Rejected" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$7, {
                            message: unref(form).errors.status
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "col-span-1" }, [
                          createVNode(_sfc_main$5, { for: "note" }, {
                            default: withCtx(() => [
                              createTextVNode("Catatan")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$8, {
                            modelValue: unref(form).note,
                            "onUpdate:modelValue": ($event) => unref(form).note = $event,
                            id: "note",
                            class: "mt-1 block w-full"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$7, {
                            message: unref(form).errors.note
                          }, null, 8, ["message"])
                        ])
                      ])) : (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Anda yakin ingin menghapus pembayaran ini? ")
                      ])),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode(PrimaryButton, {
                          onClick: ($event) => save()
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(dialogIndex.value == 0 ? "Create" : dialogIndex.value == 1 ? "Edit" : "Delete"), 1)
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_sfc_main$9, {
                          onClick: close,
                          class: "ml-2"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Cancel ")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show", "onClose"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Payment.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
