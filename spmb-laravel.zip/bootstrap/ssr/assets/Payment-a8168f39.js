import { ref, unref, withCtx, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, createCommentVNode, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$6 } from "./DateInput-00587317.js";
import { _ as _sfc_main$5 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$3 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$4 } from "./TextInput-f08fe8c3.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$9 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { _ as _sfc_main$8 } from "./FileInput-6748ff0d.js";
import { _ as _sfc_main$7 } from "./Combobox-8f85dcc2.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Payment",
  __ssrInlineRender: true,
  props: {
    payment: Object
  },
  setup(__props) {
    const dialog = ref(false);
    const dialogType = ref(null);
    const dialogItem = ref(null);
    const form = useForm({
      image: null,
      bank: "",
      date: "",
      account_name: "",
      account_number: "",
      amount: "",
      type_payment: "form",
      code: ""
    });
    const open = (i = 0, item = null) => {
      dialogType.value = i;
      dialog.value = true;
      if (i !== 0)
        dialogItem.value = item;
      if (i == 1) {
        form.bank = payment.bank;
        form.account_name = payment.account_name;
        form.account_number = payment.account_number;
        form.amount = payment.amount;
        form.date = payment.date;
        form.type_payment = payment.type_payment;
      }
    };
    const save = () => {
      if (dialogType.value == 0) {
        form.post(route("form.payment.store"), {
          preserveScroll: true,
          onSuccess: () => close()
          // onFinish: () => form.reset(),
        });
      } else if (dialogType.value == 1) {
        form.put(route("form.payment.update", dialogItem.value));
      } else {
        form.delete(route("form.payment.destroy", dialogItem.value), {
          preserveScroll: true,
          onSuccess: () => close(),
          onFinish: () => form.reset()
        });
      }
    };
    const close = () => {
      dialog.value = false;
      dialogType.value = null;
      dialogItem.value = null;
      form.image = null;
      form.reset();
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Bukti Pembayaran" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto bg-white shadow-md sm:shadow-lg p-4 sm:p-8"${_scopeId}><div class="flex flex-column sm:flex-grow flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4"${_scopeId}><header class="text-lg font-semibold text-gray-900 dark:text-gray-100"${_scopeId}> Bukti pembayaran </header>`);
            _push2(ssrRenderComponent(PrimaryButton, {
              onClick: ($event) => open()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Upload`);
                } else {
                  return [
                    createTextVNode("Upload")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="relative overflow-x-auto"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}>Bank</th><th scope="col" class="px-6 py-3"${_scopeId}> Pemilik Rekening </th><th scope="col" class="px-6 py-3"${_scopeId}> Nomor Rekening </th><th scope="col" class="px-6 py-3"${_scopeId}>Jumlah</th><th scope="col" class="px-6 py-3"${_scopeId}>Tanggal</th><th scope="col" class="px-6 py-3"${_scopeId}>Jenis</th><th scope="col" class="px-6 py-3"${_scopeId}>Status</th><th scope="col" class="px-6 py-3"${_scopeId}>Action</th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.payment, (item) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(item.bank)}</th><td class="px-6 py-4 truncate"${_scopeId}>${ssrInterpolate(item.account_name)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(item.account_number)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(item.amount == "-" ? "-" : new Intl.NumberFormat("id-ID", {
                style: "currency",
                currency: "IDR"
              }).format(item.amount))}</td><td class="px-6 py-4 truncate"${_scopeId}>${ssrInterpolate(item.date)}</td><td class="px-6 py-4 truncate"${_scopeId}>`);
              if (item.type_payment !== "-") {
                _push2(`<span${_scopeId}>${ssrInterpolate(item.type_payment == "form" ? "Formulir" : "Pendaftaran")}</span>`);
              } else {
                _push2(`<span${_scopeId}>-</span>`);
              }
              _push2(`</td><td class="px-6 py-4"${_scopeId}><div class="flex items-center justify-center"${_scopeId}>`);
              if (item.status !== "-") {
                _push2(`<i class="${ssrRenderClass([{
                  "text-green-500": item.status == "approved",
                  "text-yellow-500": item.status == "pending",
                  "text-red-500": item.status == "rejected"
                }, "fas fa-circle"])}"${_scopeId}></i>`);
              } else {
                _push2(`<span${_scopeId}>-</span>`);
              }
              _push2(`</div></td>`);
              if (item.bank !== "-") {
                _push2(`<td class="px-6 py-4"${_scopeId}>`);
                if (item.status == "pending") {
                  _push2(`<button class="text-red-600 hover:text-red-900"${_scopeId}><i class="fa-solid fa-trash"${_scopeId}></i></button>`);
                } else {
                  _push2(`<button class="text-blue-600 hover:text-blue-900"${_scopeId}><i class="fa-solid fa-eye"${_scopeId}></i></button>`);
                }
                _push2(`</td>`);
              } else {
                _push2(`<td class="px-6 py-4 flex gap-2"${_scopeId}>-</td>`);
              }
              _push2(`</tr>`);
            });
            _push2(`<!--]--></tbody></table>`);
            if (__props.payment.length === 0) {
              _push2(`<div class="flex items-center justify-center p-4"${_scopeId}><p class="text-gray-500 dark:text-gray-400 text-xs md:text-base"${_scopeId}> Kamu belum mengupload bukti pembayaran </p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: dialog.value,
              onClose: close
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId2}>${ssrInterpolate(dialogType.value == 0 ? "Upload" : dialogType.value == 1 ? "Edit" : dialogType.value == 2 ? "Hapus" : "Detail")} bukti pembayaran </h2><div class="py-2"${_scopeId2}><p class="text-gray-500"${_scopeId2}>${ssrInterpolate(dialogType.value == 0 ? "Silahkan upload bukti pembayaran dibawah ini." : dialogType.value == 1 ? "Silahkan edit bukti pembayaran dibawah ini." : dialogType.value == 2 ? "Apakah anda yakin ingin menghapus bukti pembayaran ini?" : "Berikut adalah detail bukti pembayaran.")}</p></div><div class="mt-6 space-y-6"${_scopeId2}>`);
                  if (dialogType.value !== 2 && dialogType.value !== 4) {
                    _push3(`<div class="grid grid-cols-2 md:grid-cols-4 gap-4"${_scopeId2}><div class="col-span-1 md:col-span-2"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "bank",
                      value: "Nama Bank/E-Wallet"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "bank",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).bank,
                      "onUpdate:modelValue": ($event) => unref(form).bank = $event
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      class: "mt-2",
                      message: unref(form).errors.bank
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-1 md:col-span-2"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "account_number",
                      value: "Nomor rekening/No. Akun E-Wallet"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "account_number",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).account_number,
                      "onUpdate:modelValue": ($event) => unref(form).account_number = $event
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      class: "mt-2",
                      message: unref(form).errors.account_number
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-2 md:col-span-4"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "account_name",
                      value: "Nama pemilik rekening/E-Wallet"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "account_name",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).account_name,
                      "onUpdate:modelValue": ($event) => unref(form).account_name = $event
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      class: "mt-2",
                      message: unref(form).errors.account_name
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-1 md:col-span-2"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "date",
                      value: "Tanggal pembayaran"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      id: "date",
                      ref: "date",
                      modelValue: unref(form).date,
                      "onUpdate:modelValue": ($event) => unref(form).date = $event,
                      class: "mt-1 block w-full",
                      placeholder: "Tanggal pembayaran"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      class: "mt-2",
                      message: unref(form).errors.date
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-1 md:col-span-2"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "amount",
                      value: "Nominal pembayaran",
                      class: "overflow-x-hidden"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "amount",
                      class: "mt-1 block w-full [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none",
                      type: "number",
                      modelValue: unref(form).amount,
                      "onUpdate:modelValue": ($event) => unref(form).amount = $event
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      class: "mt-2",
                      message: unref(form).errors.amount
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-1 md:col-span-2"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "code",
                      value: "Kode pembayaran"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "code",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).code,
                      "onUpdate:modelValue": ($event) => unref(form).code = $event
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      class: "mt-2",
                      message: unref(form).errors.code
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-1 md:col-span-2"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "type_payment",
                      value: "Jenis pembayaran"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$7, {
                      id: "type_payment",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).type_payment,
                      "onUpdate:modelValue": ($event) => unref(form).type_payment = $event,
                      placeholder: "Pilih Jenis Pembayaran",
                      "option-value": [
                        {
                          value: "form",
                          text: "Pendaftaran"
                        },
                        {
                          value: "registration",
                          text: "Registrasi"
                        }
                      ]
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      class: "mt-2",
                      message: unref(form).errors.type_payment
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="col-span-2 md:col-span-4"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "image",
                      value: "Bukti pembayaran"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$8, {
                      id: "image",
                      class: "my-2 p-1 block w-full text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400",
                      modelValue: unref(form).image,
                      "onUpdate:modelValue": ($event) => unref(form).image = $event,
                      accept: "image/*"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      class: "mt-2",
                      message: unref(form).errors.image
                    }, null, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  } else if (dialogType.value !== 2) {
                    _push3(`<div class="grid grid-cols-1"${_scopeId2}><div class="flex items-center justify-center"${_scopeId2}><img${ssrRenderAttr("src", dialogItem.value.image)} alt="" class="max-h-60"${_scopeId2}></div><div class="grid grid-cols-2 gap-4"${_scopeId2}><p class="text-gray-500"${_scopeId2}><span class="font-semibold"${_scopeId2}>Status:</span> ${ssrInterpolate(dialogItem.value.status == "approved" ? "Disetujui" : dialogItem.value.status == "pending" ? "Menunggu" : "Ditolak")}</p><p class="text-gray-500"${_scopeId2}><span class="font-semibold"${_scopeId2}>Kode:</span> ${ssrInterpolate(dialogItem.value.code)}</p>`);
                    if (dialogItem.value.note) {
                      _push3(`<p class="text-gray-500"${_scopeId2}><span class="font-semibold"${_scopeId2}>Catatan:</span> ${ssrInterpolate(dialogItem.value.note)}</p>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(`</div></div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`<div class="flex justify-end gap-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$9, {
                    onClick: close,
                    class: "ml-2"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` close `);
                      } else {
                        return [
                          createTextVNode(" close ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  if (dialogType.value !== 4) {
                    _push3(ssrRenderComponent(PrimaryButton, {
                      onClick: ($event) => save()
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`${ssrInterpolate(dialogType.value == 0 ? "create" : dialogType.value == 1 ? "update" : "delete")}`);
                        } else {
                          return [
                            createTextVNode(toDisplayString(dialogType.value == 0 ? "create" : dialogType.value == 1 ? "update" : "delete"), 1)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(dialogType.value == 0 ? "Upload" : dialogType.value == 1 ? "Edit" : dialogType.value == 2 ? "Hapus" : "Detail") + " bukti pembayaran ", 1),
                      createVNode("div", { class: "py-2" }, [
                        createVNode("p", { class: "text-gray-500" }, toDisplayString(dialogType.value == 0 ? "Silahkan upload bukti pembayaran dibawah ini." : dialogType.value == 1 ? "Silahkan edit bukti pembayaran dibawah ini." : dialogType.value == 2 ? "Apakah anda yakin ingin menghapus bukti pembayaran ini?" : "Berikut adalah detail bukti pembayaran."), 1)
                      ]),
                      createVNode("div", { class: "mt-6 space-y-6" }, [
                        dialogType.value !== 2 && dialogType.value !== 4 ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "grid grid-cols-2 md:grid-cols-4 gap-4"
                        }, [
                          createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                            createVNode(_sfc_main$3, {
                              for: "bank",
                              value: "Nama Bank/E-Wallet"
                            }),
                            createVNode(_sfc_main$4, {
                              id: "bank",
                              class: "mt-1 block w-full",
                              modelValue: unref(form).bank,
                              "onUpdate:modelValue": ($event) => unref(form).bank = $event
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              class: "mt-2",
                              message: unref(form).errors.bank
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                            createVNode(_sfc_main$3, {
                              for: "account_number",
                              value: "Nomor rekening/No. Akun E-Wallet"
                            }),
                            createVNode(_sfc_main$4, {
                              id: "account_number",
                              class: "mt-1 block w-full",
                              modelValue: unref(form).account_number,
                              "onUpdate:modelValue": ($event) => unref(form).account_number = $event
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              class: "mt-2",
                              message: unref(form).errors.account_number
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-4" }, [
                            createVNode(_sfc_main$3, {
                              for: "account_name",
                              value: "Nama pemilik rekening/E-Wallet"
                            }),
                            createVNode(_sfc_main$4, {
                              id: "account_name",
                              class: "mt-1 block w-full",
                              modelValue: unref(form).account_name,
                              "onUpdate:modelValue": ($event) => unref(form).account_name = $event
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              class: "mt-2",
                              message: unref(form).errors.account_name
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                            createVNode(_sfc_main$3, {
                              for: "date",
                              value: "Tanggal pembayaran"
                            }),
                            createVNode(_sfc_main$6, {
                              id: "date",
                              ref: "date",
                              modelValue: unref(form).date,
                              "onUpdate:modelValue": ($event) => unref(form).date = $event,
                              class: "mt-1 block w-full",
                              placeholder: "Tanggal pembayaran"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              class: "mt-2",
                              message: unref(form).errors.date
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                            createVNode(_sfc_main$3, {
                              for: "amount",
                              value: "Nominal pembayaran",
                              class: "overflow-x-hidden"
                            }),
                            createVNode(_sfc_main$4, {
                              id: "amount",
                              class: "mt-1 block w-full [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none",
                              type: "number",
                              modelValue: unref(form).amount,
                              "onUpdate:modelValue": ($event) => unref(form).amount = $event
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              class: "mt-2",
                              message: unref(form).errors.amount
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                            createVNode(_sfc_main$3, {
                              for: "code",
                              value: "Kode pembayaran"
                            }),
                            createVNode(_sfc_main$4, {
                              id: "code",
                              class: "mt-1 block w-full",
                              modelValue: unref(form).code,
                              "onUpdate:modelValue": ($event) => unref(form).code = $event
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              class: "mt-2",
                              message: unref(form).errors.code
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                            createVNode(_sfc_main$3, {
                              for: "type_payment",
                              value: "Jenis pembayaran"
                            }),
                            createVNode(_sfc_main$7, {
                              id: "type_payment",
                              class: "mt-1 block w-full",
                              modelValue: unref(form).type_payment,
                              "onUpdate:modelValue": ($event) => unref(form).type_payment = $event,
                              placeholder: "Pilih Jenis Pembayaran",
                              "option-value": [
                                {
                                  value: "form",
                                  text: "Pendaftaran"
                                },
                                {
                                  value: "registration",
                                  text: "Registrasi"
                                }
                              ]
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              class: "mt-2",
                              message: unref(form).errors.type_payment
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-4" }, [
                            createVNode(_sfc_main$3, {
                              for: "image",
                              value: "Bukti pembayaran"
                            }),
                            createVNode(_sfc_main$8, {
                              id: "image",
                              class: "my-2 p-1 block w-full text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400",
                              modelValue: unref(form).image,
                              "onUpdate:modelValue": ($event) => unref(form).image = $event,
                              accept: "image/*"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              class: "mt-2",
                              message: unref(form).errors.image
                            }, null, 8, ["message"])
                          ])
                        ])) : dialogType.value !== 2 ? (openBlock(), createBlock("div", {
                          key: 1,
                          class: "grid grid-cols-1"
                        }, [
                          createVNode("div", { class: "flex items-center justify-center" }, [
                            createVNode("img", {
                              src: dialogItem.value.image,
                              alt: "",
                              class: "max-h-60"
                            }, null, 8, ["src"])
                          ]),
                          createVNode("div", { class: "grid grid-cols-2 gap-4" }, [
                            createVNode("p", { class: "text-gray-500" }, [
                              createVNode("span", { class: "font-semibold" }, "Status:"),
                              createTextVNode(" " + toDisplayString(dialogItem.value.status == "approved" ? "Disetujui" : dialogItem.value.status == "pending" ? "Menunggu" : "Ditolak"), 1)
                            ]),
                            createVNode("p", { class: "text-gray-500" }, [
                              createVNode("span", { class: "font-semibold" }, "Kode:"),
                              createTextVNode(" " + toDisplayString(dialogItem.value.code), 1)
                            ]),
                            dialogItem.value.note ? (openBlock(), createBlock("p", {
                              key: 0,
                              class: "text-gray-500"
                            }, [
                              createVNode("span", { class: "font-semibold" }, "Catatan:"),
                              createTextVNode(" " + toDisplayString(dialogItem.value.note), 1)
                            ])) : createCommentVNode("", true)
                          ])
                        ])) : createCommentVNode("", true),
                        createVNode("div", { class: "flex justify-end gap-4" }, [
                          createVNode(_sfc_main$9, {
                            onClick: close,
                            class: "ml-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" close ")
                            ]),
                            _: 1
                          }),
                          dialogType.value !== 4 ? (openBlock(), createBlock(PrimaryButton, {
                            key: 0,
                            onClick: ($event) => save()
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(dialogType.value == 0 ? "create" : dialogType.value == 1 ? "update" : "delete"), 1)
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true)
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto bg-white shadow-md sm:shadow-lg p-4 sm:p-8" }, [
                  createVNode("div", { class: "flex flex-column sm:flex-grow flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4" }, [
                    createVNode("header", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100" }, " Bukti pembayaran "),
                    createVNode(PrimaryButton, {
                      onClick: ($event) => open()
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Upload")
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ]),
                  createVNode("div", { class: "relative overflow-x-auto" }, [
                    createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                      createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                        createVNode("tr", null, [
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, "Bank"),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " Pemilik Rekening "),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " Nomor Rekening "),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, "Jumlah"),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, "Tanggal"),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, "Jenis"),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, "Status"),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, "Action")
                        ])
                      ]),
                      createVNode("tbody", null, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.payment, (item) => {
                          return openBlock(), createBlock("tr", {
                            class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                            key: item.id
                          }, [
                            createVNode("th", {
                              scope: "row",
                              class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                            }, toDisplayString(item.bank), 1),
                            createVNode("td", { class: "px-6 py-4 truncate" }, toDisplayString(item.account_name), 1),
                            createVNode("td", { class: "px-6 py-4" }, toDisplayString(item.account_number), 1),
                            createVNode("td", { class: "px-6 py-4" }, toDisplayString(item.amount == "-" ? "-" : new Intl.NumberFormat("id-ID", {
                              style: "currency",
                              currency: "IDR"
                            }).format(item.amount)), 1),
                            createVNode("td", { class: "px-6 py-4 truncate" }, toDisplayString(item.date), 1),
                            createVNode("td", { class: "px-6 py-4 truncate" }, [
                              item.type_payment !== "-" ? (openBlock(), createBlock("span", { key: 0 }, toDisplayString(item.type_payment == "form" ? "Formulir" : "Pendaftaran"), 1)) : (openBlock(), createBlock("span", { key: 1 }, "-"))
                            ]),
                            createVNode("td", { class: "px-6 py-4" }, [
                              createVNode("div", { class: "flex items-center justify-center" }, [
                                item.status !== "-" ? (openBlock(), createBlock("i", {
                                  key: 0,
                                  class: ["fas fa-circle", {
                                    "text-green-500": item.status == "approved",
                                    "text-yellow-500": item.status == "pending",
                                    "text-red-500": item.status == "rejected"
                                  }]
                                }, null, 2)) : (openBlock(), createBlock("span", { key: 1 }, "-"))
                              ])
                            ]),
                            item.bank !== "-" ? (openBlock(), createBlock("td", {
                              key: 0,
                              class: "px-6 py-4"
                            }, [
                              item.status == "pending" ? (openBlock(), createBlock("button", {
                                key: 0,
                                onClick: ($event) => open(2, item.id),
                                class: "text-red-600 hover:text-red-900"
                              }, [
                                createVNode("i", { class: "fa-solid fa-trash" })
                              ], 8, ["onClick"])) : (openBlock(), createBlock("button", {
                                key: 1,
                                onClick: ($event) => open(4, item),
                                class: "text-blue-600 hover:text-blue-900"
                              }, [
                                createVNode("i", { class: "fa-solid fa-eye" })
                              ], 8, ["onClick"]))
                            ])) : (openBlock(), createBlock("td", {
                              key: 1,
                              class: "px-6 py-4 flex gap-2"
                            }, "-"))
                          ]);
                        }), 128))
                      ])
                    ]),
                    __props.payment.length === 0 ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "flex items-center justify-center p-4"
                    }, [
                      createVNode("p", { class: "text-gray-500 dark:text-gray-400 text-xs md:text-base" }, " Kamu belum mengupload bukti pembayaran ")
                    ])) : createCommentVNode("", true)
                  ]),
                  createVNode(_sfc_main$2, {
                    show: dialog.value,
                    onClose: close
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "p-6" }, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(dialogType.value == 0 ? "Upload" : dialogType.value == 1 ? "Edit" : dialogType.value == 2 ? "Hapus" : "Detail") + " bukti pembayaran ", 1),
                        createVNode("div", { class: "py-2" }, [
                          createVNode("p", { class: "text-gray-500" }, toDisplayString(dialogType.value == 0 ? "Silahkan upload bukti pembayaran dibawah ini." : dialogType.value == 1 ? "Silahkan edit bukti pembayaran dibawah ini." : dialogType.value == 2 ? "Apakah anda yakin ingin menghapus bukti pembayaran ini?" : "Berikut adalah detail bukti pembayaran."), 1)
                        ]),
                        createVNode("div", { class: "mt-6 space-y-6" }, [
                          dialogType.value !== 2 && dialogType.value !== 4 ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "grid grid-cols-2 md:grid-cols-4 gap-4"
                          }, [
                            createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                              createVNode(_sfc_main$3, {
                                for: "bank",
                                value: "Nama Bank/E-Wallet"
                              }),
                              createVNode(_sfc_main$4, {
                                id: "bank",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).bank,
                                "onUpdate:modelValue": ($event) => unref(form).bank = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$5, {
                                class: "mt-2",
                                message: unref(form).errors.bank
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                              createVNode(_sfc_main$3, {
                                for: "account_number",
                                value: "Nomor rekening/No. Akun E-Wallet"
                              }),
                              createVNode(_sfc_main$4, {
                                id: "account_number",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).account_number,
                                "onUpdate:modelValue": ($event) => unref(form).account_number = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$5, {
                                class: "mt-2",
                                message: unref(form).errors.account_number
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-2 md:col-span-4" }, [
                              createVNode(_sfc_main$3, {
                                for: "account_name",
                                value: "Nama pemilik rekening/E-Wallet"
                              }),
                              createVNode(_sfc_main$4, {
                                id: "account_name",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).account_name,
                                "onUpdate:modelValue": ($event) => unref(form).account_name = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$5, {
                                class: "mt-2",
                                message: unref(form).errors.account_name
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                              createVNode(_sfc_main$3, {
                                for: "date",
                                value: "Tanggal pembayaran"
                              }),
                              createVNode(_sfc_main$6, {
                                id: "date",
                                ref: "date",
                                modelValue: unref(form).date,
                                "onUpdate:modelValue": ($event) => unref(form).date = $event,
                                class: "mt-1 block w-full",
                                placeholder: "Tanggal pembayaran"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$5, {
                                class: "mt-2",
                                message: unref(form).errors.date
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                              createVNode(_sfc_main$3, {
                                for: "amount",
                                value: "Nominal pembayaran",
                                class: "overflow-x-hidden"
                              }),
                              createVNode(_sfc_main$4, {
                                id: "amount",
                                class: "mt-1 block w-full [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none",
                                type: "number",
                                modelValue: unref(form).amount,
                                "onUpdate:modelValue": ($event) => unref(form).amount = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$5, {
                                class: "mt-2",
                                message: unref(form).errors.amount
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                              createVNode(_sfc_main$3, {
                                for: "code",
                                value: "Kode pembayaran"
                              }),
                              createVNode(_sfc_main$4, {
                                id: "code",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).code,
                                "onUpdate:modelValue": ($event) => unref(form).code = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$5, {
                                class: "mt-2",
                                message: unref(form).errors.code
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1 md:col-span-2" }, [
                              createVNode(_sfc_main$3, {
                                for: "type_payment",
                                value: "Jenis pembayaran"
                              }),
                              createVNode(_sfc_main$7, {
                                id: "type_payment",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).type_payment,
                                "onUpdate:modelValue": ($event) => unref(form).type_payment = $event,
                                placeholder: "Pilih Jenis Pembayaran",
                                "option-value": [
                                  {
                                    value: "form",
                                    text: "Pendaftaran"
                                  },
                                  {
                                    value: "registration",
                                    text: "Registrasi"
                                  }
                                ]
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$5, {
                                class: "mt-2",
                                message: unref(form).errors.type_payment
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-2 md:col-span-4" }, [
                              createVNode(_sfc_main$3, {
                                for: "image",
                                value: "Bukti pembayaran"
                              }),
                              createVNode(_sfc_main$8, {
                                id: "image",
                                class: "my-2 p-1 block w-full text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400",
                                modelValue: unref(form).image,
                                "onUpdate:modelValue": ($event) => unref(form).image = $event,
                                accept: "image/*"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$5, {
                                class: "mt-2",
                                message: unref(form).errors.image
                              }, null, 8, ["message"])
                            ])
                          ])) : dialogType.value !== 2 ? (openBlock(), createBlock("div", {
                            key: 1,
                            class: "grid grid-cols-1"
                          }, [
                            createVNode("div", { class: "flex items-center justify-center" }, [
                              createVNode("img", {
                                src: dialogItem.value.image,
                                alt: "",
                                class: "max-h-60"
                              }, null, 8, ["src"])
                            ]),
                            createVNode("div", { class: "grid grid-cols-2 gap-4" }, [
                              createVNode("p", { class: "text-gray-500" }, [
                                createVNode("span", { class: "font-semibold" }, "Status:"),
                                createTextVNode(" " + toDisplayString(dialogItem.value.status == "approved" ? "Disetujui" : dialogItem.value.status == "pending" ? "Menunggu" : "Ditolak"), 1)
                              ]),
                              createVNode("p", { class: "text-gray-500" }, [
                                createVNode("span", { class: "font-semibold" }, "Kode:"),
                                createTextVNode(" " + toDisplayString(dialogItem.value.code), 1)
                              ]),
                              dialogItem.value.note ? (openBlock(), createBlock("p", {
                                key: 0,
                                class: "text-gray-500"
                              }, [
                                createVNode("span", { class: "font-semibold" }, "Catatan:"),
                                createTextVNode(" " + toDisplayString(dialogItem.value.note), 1)
                              ])) : createCommentVNode("", true)
                            ])
                          ])) : createCommentVNode("", true),
                          createVNode("div", { class: "flex justify-end gap-4" }, [
                            createVNode(_sfc_main$9, {
                              onClick: close,
                              class: "ml-2"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" close ")
                              ]),
                              _: 1
                            }),
                            dialogType.value !== 4 ? (openBlock(), createBlock(PrimaryButton, {
                              key: 0,
                              onClick: ($event) => save()
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(dialogType.value == 0 ? "create" : dialogType.value == 1 ? "update" : "delete"), 1)
                              ]),
                              _: 1
                            }, 8, ["onClick"])) : createCommentVNode("", true)
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  }, 8, ["show"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Form/Payment.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
