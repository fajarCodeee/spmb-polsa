import { onMounted, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle } from "vue/server-renderer";
import { _ as _sfc_main$3 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$1 } from "./InputLabel-5e383564.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$2 } from "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$4 } from "./Combobox-8f85dcc2.js";
import { _ as _sfc_main$5 } from "./DateInput-00587317.js";
import { usePage, useForm, Link } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Personal",
  __ssrInlineRender: true,
  props: {
    mustVerifyEmail: {
      type: Boolean
    },
    status: {
      type: String
    }
  },
  setup(__props) {
    onMounted(() => {
      console.log(form);
    });
    const user = usePage().props.auth.user;
    const form_data = usePage().props.form;
    const form = useForm({
      name: user.name || ``,
      email: user.email || ``,
      gender: form_data.gender || ``,
      religion: form_data.religion || ``,
      birth_date: form_data.birth_date || ``,
      birth_place_city: form_data.birth_place_city || ``,
      birth_place_province: form_data.birth_place_province || ``,
      birth_place_country: form_data.birth_place_country || ``,
      national_id: form_data.national_id
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(_attrs)}><header><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"> Personal Information </h2><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"> Update data diri personal anda. </p></header><form class="mt-6 space-y-6"><div class="grid grid-cols-2 md:grid-cols-4 gap-4"><div class="col-span-2">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "name",
        value: "Nama"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "name",
        type: "text",
        class: "mt-1 block w-full hover:cursor-not-allowed",
        modelValue: unref(form).name,
        "onUpdate:modelValue": ($event) => unref(form).name = $event,
        autofocus: "",
        disabled: "",
        autocomplete: "name"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.name
      }, null, _parent));
      _push(`</div><div class="col-span-2">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "email",
        value: "Email"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "email",
        type: "email",
        class: "mt-1 block w-full hover:cursor-not-allowed",
        modelValue: unref(form).email,
        "onUpdate:modelValue": ($event) => unref(form).email = $event,
        disabled: "",
        autocomplete: "email"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.email
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "gender",
        value: "Jenis Kelamin"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "gender",
        class: "mt-1 block w-full",
        modelValue: unref(form).gender,
        "onUpdate:modelValue": ($event) => unref(form).gender = $event,
        autocomplete: "sex",
        "option-value": [
          { value: "L", text: "Laki-laki" },
          { value: "P", text: "Perempuan" },
          { value: "", text: "Pilih Jenis Kelamin" }
        ]
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.gender
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "religion",
        value: "Agama"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "religion",
        class: "mt-1 block w-full",
        modelValue: unref(form).religion,
        "onUpdate:modelValue": ($event) => unref(form).religion = $event,
        autocomplete: "religion",
        "option-value": [
          { value: "Islam", text: "Islam" },
          { value: "Kristen", text: "Kristen" },
          { value: "Hindu", text: "Hindu" },
          { value: "Buddha", text: "Buddha" },
          { value: "Khonghucu", text: "Khonghucu" },
          { value: "Katholik", text: "Katholik" },
          { value: "", text: "Pilih Agama" }
        ]
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.religion
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "birth_date",
        value: "Tanggal Lahir"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$5, {
        id: "birth_date",
        class: "mt-1 block w-full",
        modelValue: unref(form).birth_date,
        "onUpdate:modelValue": ($event) => unref(form).birth_date = $event,
        autocomplete: "bday"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.birth_date
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "birth_place_city",
        value: "Kota Kelahiran"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "birth_place_city",
        class: "mt-1 block w-full",
        modelValue: unref(form).birth_place_city,
        "onUpdate:modelValue": ($event) => unref(form).birth_place_city = $event,
        autocomplete: "address-level2"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.birth_place_city
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "birth_place_province",
        value: "Provinsi Kelahiran"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "birth_place_province",
        class: "mt-1 block w-full",
        modelValue: unref(form).birth_place_province,
        "onUpdate:modelValue": ($event) => unref(form).birth_place_province = $event,
        autocomplete: "address-level1"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.birth_place_province
      }, null, _parent));
      _push(`</div><div class="col-span-1">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "birth_place_country",
        value: "Negara Kelahiran"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "birth_place_country",
        class: "mt-1 block w-full",
        modelValue: unref(form).birth_place_country,
        "onUpdate:modelValue": ($event) => unref(form).birth_place_country = $event,
        autocomplete: "country"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.birth_place_country
      }, null, _parent));
      _push(`</div><div class="col-span-2">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "national_id",
        value: "Nomor KTP"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "national_id",
        class: "mt-1 block w-full [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none",
        type: "number",
        modelValue: unref(form).national_id,
        "onUpdate:modelValue": ($event) => unref(form).national_id = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.national_id
      }, null, _parent));
      _push(`</div></div>`);
      if (__props.mustVerifyEmail && unref(user).email_verified_at === null) {
        _push(`<div><p class="text-sm mt-2 text-gray-800 dark:text-gray-200"> Your email address is unverified. `);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("verification.send"),
          method: "post",
          as: "button",
          class: "underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Click here to re-send the verification email. `);
            } else {
              return [
                createTextVNode(" Click here to re-send the verification email. ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</p><div style="${ssrRenderStyle(__props.status === "verification-link-sent" ? null : { display: "none" })}" class="mt-2 font-medium text-sm text-green-600 dark:text-green-400"> A new verification link has been sent to your email address. </div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex justify-end gap-4">`);
      _push(ssrRenderComponent(PrimaryButton, {
        disabled: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Save`);
          } else {
            return [
              createTextVNode("Save")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></form></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Form/Partials/Personal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
