import { ref, unref, withCtx, createTextVNode, createVNode, toDisplayString, openBlock, createBlock, createCommentVNode, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { useForm, Head, usePage } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$8 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$4 } from "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$7 } from "./NumberInput-74774052.js";
import { _ as _sfc_main$3 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$5 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$6 } from "./Combobox-8f85dcc2.js";
import Multiselect from "@vueform/multiselect";
/* empty css                                                            */import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Prodi",
  __ssrInlineRender: true,
  props: {
    prodi: {
      type: Object
    },
    knowledges: {
      type: Array
    }
  },
  setup(__props) {
    const form = useForm({
      nama_prodi: "",
      kode_jurusan: "",
      jenjang: "",
      akreditasi: "",
      tes_ujian: false,
      ujian: [],
      tes_wawancara: false,
      tes_kesehatan: false,
      biaya_pendaftaran: 0,
      biaya_registrasi: 0,
      nilai_dibawah: 0,
      status: false
    }).transform((x) => {
      var _a;
      return {
        ...x,
        tes_ujian: x.tes_ujian == "true" ? true : false,
        ujian: x.tes_ujian == "true" ? (_a = x.ujian) == null ? void 0 : _a.join(",") : null,
        tes_wawancara: x.tes_wawancara == "true" ? true : false,
        tes_kesehatan: x.tes_kesehatan == "true" ? true : false,
        biaya_registrasi: parseInt(x.biaya_registrasi),
        nilai_dibawah: parseInt(x.nilai_dibawah) || 0,
        status: x.status == "true" ? true : false
      };
    });
    const dialogCreateProdi = ref(false);
    const dialogEditProdi = ref(false);
    const itemProdi = ref(null);
    const dialogDeleteProdi = ref(false);
    const createProdi = () => {
      if (dialogCreateProdi.value) {
        form.post(route("admin.prodi.store"), {
          preserveScroll: true,
          onSuccess: () => closeModal(),
          onError: () => nama_prodiInput.value.focus(),
          onFinish: () => form.reset()
        });
      } else {
        dialogCreateProdi.value = true;
      }
    };
    const editProdi = (item = null) => {
      var _a;
      if (dialogEditProdi.value) {
        form.patch(route("admin.prodi.update", { id: item }), {
          preserveScroll: true,
          onSuccess: () => closeModal(),
          onError: () => nama_prodiInput.value.focus(),
          onFinish: () => form.reset()
        });
      } else {
        dialogEditProdi.value = true;
        itemProdi.value = item;
        let findProdi = usePage().props.prodi.find(
          (item2) => item2.id == itemProdi.value
        );
        form.akreditasi = findProdi.akreditasi;
        form.kode_jurusan = findProdi.kode_jurusan;
        form.jenjang = findProdi.jenjang;
        form.nama_prodi = findProdi.nama_prodi;
        form.tes_kesehatan = findProdi.tes_kesehatan == 1 ? "true" : "false";
        form.tes_ujian = findProdi.tes_ujian == 1 ? "true" : "false";
        form.ujian = ((_a = findProdi.ujian) == null ? void 0 : _a.split(",")) || [];
        form.tes_wawancara = findProdi.tes_wawancara == 1 ? "true" : "false";
        form.biaya_pendaftaran = findProdi.biaya_pendaftaran;
        form.biaya_registrasi = findProdi.biaya_registrasi;
        form.nilai_dibawah = findProdi.nilai_dibawah || 0;
        form.status = findProdi.status == 1 ? "true" : "false";
      }
    };
    const deleteProdi = (item = null) => {
      if (dialogDeleteProdi.value) {
        form.delete(route("admin.prodi.destroy", { id: item }), {
          preserveScroll: true,
          onSuccess: () => closeModal(),
          onError: () => nama_prodiInput.value.focus(),
          onFinish: () => form.reset()
        });
      } else {
        dialogDeleteProdi.value = true;
        itemProdi.value = item;
      }
    };
    const closeModal = () => {
      dialogCreateProdi.value = false;
      dialogEditProdi.value = false;
      dialogDeleteProdi.value = false;
      itemProdi.value = null;
      form.reset();
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Setting Prodi" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="shadow-md sm:shadow-lg p-4 sm:p-8 bg-white"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}> Program studi </h2></header>`);
            _push2(ssrRenderComponent(PrimaryButton, { onClick: createProdi }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Create`);
                } else {
                  return [
                    createTextVNode("Create")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="relative overflow-x-auto"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}>Name</th><th scope="col" class="px-6 py-3"${_scopeId}> Kode Jurusan </th><th scope="col" class="px-6 py-3"${_scopeId}> Jenjang </th><th scope="col" class="px-6 py-3"${_scopeId}> Akreditasi </th><th scope="col" class="px-6 py-3"${_scopeId}>Ujian</th><th scope="col" class="px-6 py-3"${_scopeId}> Biaya Pendaftaran </th><th scope="col" class="px-6 py-3"${_scopeId}> Biaya Registrasi </th><th scope="col" class="px-6 py-3"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.prodi, (prodi) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(prodi.nama_prodi)}</th><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(prodi.kode_jurusan)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(prodi.jenjang)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(prodi.akreditasi)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(prodi.tes_ujian ? "Ya" : "Tidak")}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(new Intl.NumberFormat("id-ID", {
                style: "currency",
                currency: "IDR"
              }).format(
                prodi.biaya_pendaftaran || 0
              ))}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(new Intl.NumberFormat("id-ID", {
                style: "currency",
                currency: "IDR"
              }).format(
                prodi.biaya_registrasi || 0
              ))}</td><td class="px-6 py-4 flex gap-2"${_scopeId}><button class="text-indigo-600 hover:text-indigo-900"${_scopeId}><i class="fa-solid fa-pencil"${_scopeId}></i></button><button class="text-red-600 hover:text-red-900"${_scopeId}><i class="fa-solid fa-trash"${_scopeId}></i></button></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: dialogCreateProdi.value || dialogEditProdi.value || dialogDeleteProdi.value,
              onClose: closeModal
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId2}>${ssrInterpolate(dialogCreateProdi.value ? "Create" : "Edit")}</h2>`);
                  if (!dialogDeleteProdi.value) {
                    _push3(`<div class="mt-6 grid grid-cols-1 gap-4"${_scopeId2}><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "nama_prodi",
                      value: "Name"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "nama_prodi",
                      ref: "nameInput",
                      modelValue: unref(form).nama_prodi,
                      "onUpdate:modelValue": ($event) => unref(form).nama_prodi = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      placeholder: "Name"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.nama_prodi,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "kode_jurusan",
                      value: "Kode Jurusan"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "kode_jurusan",
                      ref: "kodeJurusanInput",
                      modelValue: unref(form).kode_jurusan,
                      "onUpdate:modelValue": ($event) => unref(form).kode_jurusan = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      placeholder: "Kode Jurusan"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.kode_jurusan,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "jenjang",
                      value: "Jenjang"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "jenjang",
                      ref: "jenjangInput",
                      modelValue: unref(form).jenjang,
                      "onUpdate:modelValue": ($event) => unref(form).jenjang = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      placeholder: "Jenjang"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.jenjang,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "akreditasi",
                      value: "Akreditasi"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "akreditasi",
                      ref: "akreditasiInput",
                      modelValue: unref(form).akreditasi,
                      "onUpdate:modelValue": ($event) => unref(form).akreditasi = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      placeholder: "Akreditasi"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.akreditasi,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "tes_ujian",
                      value: "Tes Ujian"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      id: "tes_ujian",
                      ref: "tes_ujianInput",
                      modelValue: unref(form).tes_ujian,
                      "onUpdate:modelValue": ($event) => unref(form).tes_ujian = $event,
                      class: "mt-1 block w-full",
                      placeholder: "Tes Ujian",
                      "option-value": [
                        {
                          value: true,
                          text: "Ya"
                        },
                        {
                          value: false,
                          text: "Tidak"
                        }
                      ]
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.tes_ujian,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div>`);
                    if (unref(form).tes_ujian == "true") {
                      _push3(`<div${_scopeId2}>`);
                      _push3(ssrRenderComponent(_sfc_main$3, {
                        for: "ujian",
                        value: "Ujian"
                      }, null, _parent3, _scopeId2));
                      _push3(ssrRenderComponent(unref(Multiselect), {
                        id: "ujian",
                        ref: "ujianInput",
                        modelValue: unref(form).ujian,
                        "onUpdate:modelValue": ($event) => unref(form).ujian = $event,
                        class: "mt-1 block w-full",
                        placeholder: "Ujian",
                        options: __props.knowledges,
                        mode: "multiple",
                        "close-on-select": false,
                        "clear-on-select": false,
                        "preserve-search": true,
                        label: "label",
                        "track-by": "label",
                        "preselect-first": true,
                        "hide-selected": false
                      }, null, _parent3, _scopeId2));
                      _push3(ssrRenderComponent(_sfc_main$5, {
                        message: unref(form).errors.ujian,
                        class: "mt-2"
                      }, null, _parent3, _scopeId2));
                      _push3(`</div>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    if (unref(form).tes_ujian == "true") {
                      _push3(`<div${_scopeId2}>`);
                      _push3(ssrRenderComponent(_sfc_main$3, {
                        for: "nilai_dibawah",
                        value: "nilai dibawah rata - rata ijazah",
                        class: "capitalize"
                      }, null, _parent3, _scopeId2));
                      _push3(ssrRenderComponent(_sfc_main$7, {
                        id: "nilai_dibawah",
                        ref: "nilai_dibawahInput",
                        modelValue: unref(form).nilai_dibawah,
                        "onUpdate:modelValue": ($event) => unref(form).nilai_dibawah = $event,
                        class: "mt-1 block w-full",
                        placeholder: "Nilai Dibawah"
                      }, null, _parent3, _scopeId2));
                      _push3(ssrRenderComponent(_sfc_main$5, {
                        message: unref(form).errors.nilai_dibawah,
                        class: "mt-2"
                      }, null, _parent3, _scopeId2));
                      _push3(`</div>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(`<div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "biaya_pendaftaran",
                      value: "Biaya Pendaftaran"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "biaya_pendaftaran",
                      ref: "biaya_pendaftaranInput",
                      modelValue: unref(form).biaya_pendaftaran,
                      "onUpdate:modelValue": ($event) => unref(form).biaya_pendaftaran = $event,
                      type: "number",
                      class: "mt-1 block w-full",
                      placeholder: "Biaya Pendaftaran"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.biaya_pendaftaran,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "biaya_registrasi",
                      value: "Biaya Registrasi"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "biaya_registrasi",
                      ref: "biaya_registrasiInput",
                      modelValue: unref(form).biaya_registrasi,
                      "onUpdate:modelValue": ($event) => unref(form).biaya_registrasi = $event,
                      type: "number",
                      class: "mt-1 block w-full",
                      placeholder: "Biaya Registrasi"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.biaya_registrasi,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "status",
                      value: "Status"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      id: "status",
                      ref: "statusInput",
                      modelValue: unref(form).status,
                      "onUpdate:modelValue": ($event) => unref(form).status = $event,
                      class: "mt-1 block w-full",
                      placeholder: "Status",
                      "option-value": [
                        {
                          value: "true",
                          text: "Aktif"
                        },
                        {
                          value: "false",
                          text: "Tidak Aktif"
                        }
                      ]
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.status,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="mt-6"${_scopeId2}>`);
                    if (dialogCreateProdi.value) {
                      _push3(ssrRenderComponent(PrimaryButton, { onClick: createProdi }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`Create`);
                          } else {
                            return [
                              createTextVNode("Create")
                            ];
                          }
                        }),
                        _: 1
                      }, _parent3, _scopeId2));
                    } else {
                      _push3(`<!---->`);
                    }
                    if (dialogEditProdi.value) {
                      _push3(ssrRenderComponent(PrimaryButton, {
                        onClick: ($event) => editProdi(itemProdi.value)
                      }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`Edit`);
                          } else {
                            return [
                              createTextVNode("Edit")
                            ];
                          }
                        }),
                        _: 1
                      }, _parent3, _scopeId2));
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(ssrRenderComponent(_sfc_main$8, {
                      onClick: closeModal,
                      class: "ml-2"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Cancel `);
                        } else {
                          return [
                            createTextVNode(" Cancel ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  } else {
                    _push3(`<div${_scopeId2}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId2}> Are you sure you want to delete this prodi? </h2><div class="mt-6"${_scopeId2}>`);
                    if (dialogDeleteProdi.value) {
                      _push3(ssrRenderComponent(PrimaryButton, {
                        onClick: ($event) => deleteProdi(itemProdi.value)
                      }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`Delete `);
                          } else {
                            return [
                              createTextVNode("Delete ")
                            ];
                          }
                        }),
                        _: 1
                      }, _parent3, _scopeId2));
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(ssrRenderComponent(_sfc_main$8, {
                      onClick: closeModal,
                      class: "ml-2"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Cancel `);
                        } else {
                          return [
                            createTextVNode(" Cancel ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  }
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(dialogCreateProdi.value ? "Create" : "Edit"), 1),
                      !dialogDeleteProdi.value ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-6 grid grid-cols-1 gap-4"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "nama_prodi",
                            value: "Name"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "nama_prodi",
                            ref: "nameInput",
                            modelValue: unref(form).nama_prodi,
                            "onUpdate:modelValue": ($event) => unref(form).nama_prodi = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Name"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.nama_prodi,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "kode_jurusan",
                            value: "Kode Jurusan"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "kode_jurusan",
                            ref: "kodeJurusanInput",
                            modelValue: unref(form).kode_jurusan,
                            "onUpdate:modelValue": ($event) => unref(form).kode_jurusan = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Kode Jurusan"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.kode_jurusan,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "jenjang",
                            value: "Jenjang"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "jenjang",
                            ref: "jenjangInput",
                            modelValue: unref(form).jenjang,
                            "onUpdate:modelValue": ($event) => unref(form).jenjang = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Jenjang"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.jenjang,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "akreditasi",
                            value: "Akreditasi"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "akreditasi",
                            ref: "akreditasiInput",
                            modelValue: unref(form).akreditasi,
                            "onUpdate:modelValue": ($event) => unref(form).akreditasi = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Akreditasi"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.akreditasi,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "tes_ujian",
                            value: "Tes Ujian"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "tes_ujian",
                            ref: "tes_ujianInput",
                            modelValue: unref(form).tes_ujian,
                            "onUpdate:modelValue": ($event) => unref(form).tes_ujian = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Tes Ujian",
                            "option-value": [
                              {
                                value: true,
                                text: "Ya"
                              },
                              {
                                value: false,
                                text: "Tidak"
                              }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.tes_ujian,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        unref(form).tes_ujian == "true" ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode(_sfc_main$3, {
                            for: "ujian",
                            value: "Ujian"
                          }),
                          createVNode(unref(Multiselect), {
                            id: "ujian",
                            ref: "ujianInput",
                            modelValue: unref(form).ujian,
                            "onUpdate:modelValue": ($event) => unref(form).ujian = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Ujian",
                            options: __props.knowledges,
                            mode: "multiple",
                            "close-on-select": false,
                            "clear-on-select": false,
                            "preserve-search": true,
                            label: "label",
                            "track-by": "label",
                            "preselect-first": true,
                            "hide-selected": false
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "options"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.ujian,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])) : createCommentVNode("", true),
                        unref(form).tes_ujian == "true" ? (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode(_sfc_main$3, {
                            for: "nilai_dibawah",
                            value: "nilai dibawah rata - rata ijazah",
                            class: "capitalize"
                          }),
                          createVNode(_sfc_main$7, {
                            id: "nilai_dibawah",
                            ref: "nilai_dibawahInput",
                            modelValue: unref(form).nilai_dibawah,
                            "onUpdate:modelValue": ($event) => unref(form).nilai_dibawah = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Nilai Dibawah"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.nilai_dibawah,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])) : createCommentVNode("", true),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "biaya_pendaftaran",
                            value: "Biaya Pendaftaran"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "biaya_pendaftaran",
                            ref: "biaya_pendaftaranInput",
                            modelValue: unref(form).biaya_pendaftaran,
                            "onUpdate:modelValue": ($event) => unref(form).biaya_pendaftaran = $event,
                            type: "number",
                            class: "mt-1 block w-full",
                            placeholder: "Biaya Pendaftaran"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.biaya_pendaftaran,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "biaya_registrasi",
                            value: "Biaya Registrasi"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "biaya_registrasi",
                            ref: "biaya_registrasiInput",
                            modelValue: unref(form).biaya_registrasi,
                            "onUpdate:modelValue": ($event) => unref(form).biaya_registrasi = $event,
                            type: "number",
                            class: "mt-1 block w-full",
                            placeholder: "Biaya Registrasi"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.biaya_registrasi,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "status",
                            value: "Status"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "status",
                            ref: "statusInput",
                            modelValue: unref(form).status,
                            "onUpdate:modelValue": ($event) => unref(form).status = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Status",
                            "option-value": [
                              {
                                value: "true",
                                text: "Aktif"
                              },
                              {
                                value: "false",
                                text: "Tidak Aktif"
                              }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.status,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "mt-6" }, [
                          dialogCreateProdi.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 0,
                            onClick: createProdi
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Create")
                            ]),
                            _: 1
                          })) : createCommentVNode("", true),
                          dialogEditProdi.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 1,
                            onClick: ($event) => editProdi(itemProdi.value)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Edit")
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true),
                          createVNode(_sfc_main$8, {
                            onClick: closeModal,
                            class: "ml-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          })
                        ])
                      ])) : (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Are you sure you want to delete this prodi? "),
                        createVNode("div", { class: "mt-6" }, [
                          dialogDeleteProdi.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 0,
                            onClick: ($event) => deleteProdi(itemProdi.value)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Delete ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true),
                          createVNode(_sfc_main$8, {
                            onClick: closeModal,
                            class: "ml-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          })
                        ])
                      ]))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "shadow-md sm:shadow-lg p-4 sm:p-8 bg-white" }, [
                    createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Program studi ")
                      ]),
                      createVNode(PrimaryButton, { onClick: createProdi }, {
                        default: withCtx(() => [
                          createTextVNode("Create")
                        ]),
                        _: 1
                      })
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Name"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Kode Jurusan "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Jenjang "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Akreditasi "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Ujian"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Biaya Pendaftaran "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Biaya Registrasi "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.prodi, (prodi) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: prodi.id
                            }, [
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(prodi.nama_prodi), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(prodi.kode_jurusan), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(prodi.jenjang), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(prodi.akreditasi), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(prodi.tes_ujian ? "Ya" : "Tidak"), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(new Intl.NumberFormat("id-ID", {
                                style: "currency",
                                currency: "IDR"
                              }).format(
                                prodi.biaya_pendaftaran || 0
                              )), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(new Intl.NumberFormat("id-ID", {
                                style: "currency",
                                currency: "IDR"
                              }).format(
                                prodi.biaya_registrasi || 0
                              )), 1),
                              createVNode("td", { class: "px-6 py-4 flex gap-2" }, [
                                createVNode("button", {
                                  onClick: ($event) => editProdi(prodi.id),
                                  class: "text-indigo-600 hover:text-indigo-900"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-pencil" })
                                ], 8, ["onClick"]),
                                createVNode("button", {
                                  onClick: ($event) => deleteProdi(prodi.id),
                                  class: "text-red-600 hover:text-red-900"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-trash" })
                                ], 8, ["onClick"])
                              ])
                            ]);
                          }), 128))
                        ])
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: dialogCreateProdi.value || dialogEditProdi.value || dialogDeleteProdi.value,
                  onClose: closeModal
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(dialogCreateProdi.value ? "Create" : "Edit"), 1),
                      !dialogDeleteProdi.value ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-6 grid grid-cols-1 gap-4"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "nama_prodi",
                            value: "Name"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "nama_prodi",
                            ref: "nameInput",
                            modelValue: unref(form).nama_prodi,
                            "onUpdate:modelValue": ($event) => unref(form).nama_prodi = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Name"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.nama_prodi,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "kode_jurusan",
                            value: "Kode Jurusan"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "kode_jurusan",
                            ref: "kodeJurusanInput",
                            modelValue: unref(form).kode_jurusan,
                            "onUpdate:modelValue": ($event) => unref(form).kode_jurusan = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Kode Jurusan"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.kode_jurusan,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "jenjang",
                            value: "Jenjang"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "jenjang",
                            ref: "jenjangInput",
                            modelValue: unref(form).jenjang,
                            "onUpdate:modelValue": ($event) => unref(form).jenjang = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Jenjang"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.jenjang,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "akreditasi",
                            value: "Akreditasi"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "akreditasi",
                            ref: "akreditasiInput",
                            modelValue: unref(form).akreditasi,
                            "onUpdate:modelValue": ($event) => unref(form).akreditasi = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Akreditasi"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.akreditasi,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "tes_ujian",
                            value: "Tes Ujian"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "tes_ujian",
                            ref: "tes_ujianInput",
                            modelValue: unref(form).tes_ujian,
                            "onUpdate:modelValue": ($event) => unref(form).tes_ujian = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Tes Ujian",
                            "option-value": [
                              {
                                value: true,
                                text: "Ya"
                              },
                              {
                                value: false,
                                text: "Tidak"
                              }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.tes_ujian,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        unref(form).tes_ujian == "true" ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode(_sfc_main$3, {
                            for: "ujian",
                            value: "Ujian"
                          }),
                          createVNode(unref(Multiselect), {
                            id: "ujian",
                            ref: "ujianInput",
                            modelValue: unref(form).ujian,
                            "onUpdate:modelValue": ($event) => unref(form).ujian = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Ujian",
                            options: __props.knowledges,
                            mode: "multiple",
                            "close-on-select": false,
                            "clear-on-select": false,
                            "preserve-search": true,
                            label: "label",
                            "track-by": "label",
                            "preselect-first": true,
                            "hide-selected": false
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "options"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.ujian,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])) : createCommentVNode("", true),
                        unref(form).tes_ujian == "true" ? (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode(_sfc_main$3, {
                            for: "nilai_dibawah",
                            value: "nilai dibawah rata - rata ijazah",
                            class: "capitalize"
                          }),
                          createVNode(_sfc_main$7, {
                            id: "nilai_dibawah",
                            ref: "nilai_dibawahInput",
                            modelValue: unref(form).nilai_dibawah,
                            "onUpdate:modelValue": ($event) => unref(form).nilai_dibawah = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Nilai Dibawah"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.nilai_dibawah,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])) : createCommentVNode("", true),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "biaya_pendaftaran",
                            value: "Biaya Pendaftaran"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "biaya_pendaftaran",
                            ref: "biaya_pendaftaranInput",
                            modelValue: unref(form).biaya_pendaftaran,
                            "onUpdate:modelValue": ($event) => unref(form).biaya_pendaftaran = $event,
                            type: "number",
                            class: "mt-1 block w-full",
                            placeholder: "Biaya Pendaftaran"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.biaya_pendaftaran,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "biaya_registrasi",
                            value: "Biaya Registrasi"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "biaya_registrasi",
                            ref: "biaya_registrasiInput",
                            modelValue: unref(form).biaya_registrasi,
                            "onUpdate:modelValue": ($event) => unref(form).biaya_registrasi = $event,
                            type: "number",
                            class: "mt-1 block w-full",
                            placeholder: "Biaya Registrasi"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.biaya_registrasi,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "status",
                            value: "Status"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "status",
                            ref: "statusInput",
                            modelValue: unref(form).status,
                            "onUpdate:modelValue": ($event) => unref(form).status = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Status",
                            "option-value": [
                              {
                                value: "true",
                                text: "Aktif"
                              },
                              {
                                value: "false",
                                text: "Tidak Aktif"
                              }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.status,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "mt-6" }, [
                          dialogCreateProdi.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 0,
                            onClick: createProdi
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Create")
                            ]),
                            _: 1
                          })) : createCommentVNode("", true),
                          dialogEditProdi.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 1,
                            onClick: ($event) => editProdi(itemProdi.value)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Edit")
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true),
                          createVNode(_sfc_main$8, {
                            onClick: closeModal,
                            class: "ml-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          })
                        ])
                      ])) : (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Are you sure you want to delete this prodi? "),
                        createVNode("div", { class: "mt-6" }, [
                          dialogDeleteProdi.value ? (openBlock(), createBlock(PrimaryButton, {
                            key: 0,
                            onClick: ($event) => deleteProdi(itemProdi.value)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Delete ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true),
                          createVNode(_sfc_main$8, {
                            onClick: closeModal,
                            class: "ml-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          })
                        ])
                      ]))
                    ])
                  ]),
                  _: 1
                }, 8, ["show"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Prodi.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
