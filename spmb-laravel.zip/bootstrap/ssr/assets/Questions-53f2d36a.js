import { ref, unref, withCtx, createVNode, createTextVNode, toDisplayString, withModifiers, openBlock, createBlock, Fragment, renderList, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { useForm, Head, router, usePage } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { _ as _sfc_main$7 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$3 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$5 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$6 } from "./Combobox-8f85dcc2.js";
import { _ as _sfc_main$4 } from "./TextareaInput-ea5736c3.js";
import "@tinymce/tinymce-vue";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Questions",
  __ssrInlineRender: true,
  props: {
    questions: Object,
    exam: Object
  },
  setup(__props) {
    const navigateTo = (url) => {
      if (url === null)
        return;
      return router.visit(url);
    };
    const form = useForm({
      question: "",
      answer: "",
      option_a: "",
      option_b: "",
      option_c: "",
      option_d: "",
      option_e: ""
    }).transform((data) => ({
      ...data,
      question: `${data.question}`
    }));
    const showModal = ref(false);
    const dialogIndex = ref(null);
    const modalItem = ref(null);
    const open = (type, item = null) => {
      if (type === 0) {
        form.reset();
      } else if (type === 1) {
        form.question = item.question;
        form.answer = item.answer;
        form.option_a = item.option_a;
        form.option_b = item.option_b;
        form.option_c = item.option_c;
        form.option_d = item.option_d;
        form.option_e = item.option_e;
      }
      dialogIndex.value = type;
      modalItem.value = item;
      showModal.value = true;
    };
    const close = () => {
      showModal.value = false;
      modalItem.value = null;
      form.reset();
    };
    const save = () => {
      if (dialogIndex.value === 0) {
        form.post(
          route("admin.exams.questions.store", usePage().props.exam.id),
          {
            preserveScroll: true,
            onSuccess: () => {
              close();
            }
          }
        );
      } else if (dialogIndex.value === 1) {
        form.patch(
          route("admin.exams.questions.update", [
            usePage().props.exam.id,
            modalItem.value.id
          ]),
          {
            preserveScroll: true,
            onSuccess: () => {
              close();
            }
          }
        );
      } else if (dialogIndex.value === 2) {
        form.delete(
          route("admin.exams.questions.destroy", [
            usePage().props.exam.id,
            modalItem.value.id
          ]),
          {
            preserveScroll: true,
            onSuccess: () => {
              close();
            }
          }
        );
      }
    };
    const option = {
      A: "option_a",
      B: "option_b",
      C: "option_c",
      D: "option_d",
      E: "option_e"
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard Admin" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="bg-white p-4 shadow-md rounded-lg"${_scopeId}><div class="flex flex-col sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-lg font-bold text-gray-900 dark:text-gray-100"${_scopeId}> Kelola Soal ${ssrInterpolate(__props.exam.name)}</h2></header><div class="flex space-x-2"${_scopeId}>`);
            _push2(ssrRenderComponent(PrimaryButton, {
              onClick: ($event) => open(0)
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<i class="fas fa-plus mr-1"${_scopeId2}></i> Add question `);
                } else {
                  return [
                    createVNode("i", { class: "fas fa-plus mr-1" }),
                    createTextVNode(" Add question ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="relative overflow-x-auto shadow-md sm:rounded-lg"${_scopeId}><table class="w-full text-sm text-left text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col " class="px-3 py-3"${_scopeId}>No</th><th scope="col" class="px-6 py-3"${_scopeId}>Soal</th><th scope="col" class="px-6 py-3 text-end"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.questions.data, (item, index) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><th scope="row" class="px-3 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(index + 1 + (__props.questions.current_page - 1) * __props.questions.per_page)}</th><td class="px-6 py-4 break-all w-2/3"${_scopeId}><div${_scopeId}>${item.question}</div><br${_scopeId}><!--[-->`);
              ssrRenderList(Object.keys(
                option
              ), (value, key) => {
                _push2(`<span class="${ssrRenderClass({
                  "font-bold text-green-400": item.answer == value
                })}"${_scopeId}>`);
                if (item[option[value]] != null || item[option[value]] != "") {
                  _push2(`<span${_scopeId}>${ssrInterpolate(value)}. <span${_scopeId}>${item[option[value]]}</span><br${_scopeId}></span>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</span>`);
              });
              _push2(`<!--]--></td><td class="px-6 py-4"${_scopeId}><div class="flex justify-end gap-2"${_scopeId}><button class="text-indigo-600 hover:text-indigo-900"${_scopeId}><i class="fa-solid fa-pencil"${_scopeId}></i></button><button class="text-red-600 hover:text-red-900"${_scopeId}><i class="fa-solid fa-trash"${_scopeId}></i></button></div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table><div class="py-1 px-4"${_scopeId}><nav class="flex items-center space-x-1"${_scopeId}><!--[-->`);
            ssrRenderList(__props.questions.links, (link) => {
              _push2(`<button type="button" class="min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10" aria-current="page"${ssrIncludeBooleanAttr(link.active) ? " disabled" : ""}${_scopeId}><span${_scopeId}>${link.label}</span></button>`);
            });
            _push2(`<!--]--></nav></div></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: showModal.value,
              onClose: ($event) => close()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100"${_scopeId2}>${ssrInterpolate(dialogIndex.value == 0 ? "Tambah" : dialogIndex.value == 1 ? "Edit" : "Hapus")}</h2><form class="mt-4"${_scopeId2}>`);
                  if (dialogIndex.value != 2) {
                    _push3(`<div class="grid grid-cols-1 gap-6"${_scopeId2}><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "question" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Pertanyaan `);
                        } else {
                          return [
                            createTextVNode(" Pertanyaan ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      modelValue: unref(form).question,
                      "onUpdate:modelValue": ($event) => unref(form).question = $event
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.question
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "answer" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Kunci Jawaban `);
                        } else {
                          return [
                            createTextVNode(" Kunci Jawaban ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      modelValue: unref(form).answer,
                      "onUpdate:modelValue": ($event) => unref(form).answer = $event,
                      id: "answer",
                      class: "mt-1 block w-full",
                      "option-value": [
                        {
                          value: "",
                          text: "--PILIH JAWABAN--"
                        },
                        { value: "A", text: "A" },
                        { value: "B", text: "B" },
                        { value: "C", text: "C" },
                        { value: "D", text: "D" },
                        { value: "E", text: "E" }
                      ]
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.answer
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "option_a" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Pilihan A `);
                        } else {
                          return [
                            createTextVNode(" Pilihan A ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      modelValue: unref(form).option_a,
                      "onUpdate:modelValue": ($event) => unref(form).option_a = $event,
                      id: "option_a",
                      class: "mt-1 block w-full"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.option_a
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "option_b" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Pilihan B `);
                        } else {
                          return [
                            createTextVNode(" Pilihan B ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      modelValue: unref(form).option_b,
                      "onUpdate:modelValue": ($event) => unref(form).option_b = $event,
                      id: "option_b",
                      class: "mt-1 block w-full"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.option_b
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "option_c" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Pilihan C `);
                        } else {
                          return [
                            createTextVNode(" Pilihan C ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      modelValue: unref(form).option_c,
                      "onUpdate:modelValue": ($event) => unref(form).option_c = $event,
                      id: "option_c",
                      class: "mt-1 block w-full"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.option_c
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "option_d" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Pilihan D `);
                        } else {
                          return [
                            createTextVNode(" Pilihan D ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      modelValue: unref(form).option_d,
                      "onUpdate:modelValue": ($event) => unref(form).option_d = $event,
                      id: "option_d",
                      class: "mt-1 block w-full"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.option_d
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "option_e" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Pilihan E `);
                        } else {
                          return [
                            createTextVNode(" Pilihan E ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      modelValue: unref(form).option_e,
                      "onUpdate:modelValue": ($event) => unref(form).option_e = $event,
                      id: "option_e",
                      class: "mt-1 block w-full"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.option_e
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div class="flex justify-end mt-6"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$7, {
                      type: "button",
                      onClick: ($event) => close(),
                      class: "mr-2"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Batal `);
                        } else {
                          return [
                            createTextVNode(" Batal ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(PrimaryButton, { type: "submit" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Simpan `);
                        } else {
                          return [
                            createTextVNode(" Simpan ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  } else {
                    _push3(`<div${_scopeId2}><p${_scopeId2}>Apakah anda yakin ingin menghapus soal ini?</p><div class="flex justify-end mt-6"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$7, {
                      type: "button",
                      onClick: ($event) => close(),
                      class: "mr-2"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Batal `);
                        } else {
                          return [
                            createTextVNode(" Batal ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(PrimaryButton, { type: "submit" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Hapus `);
                        } else {
                          return [
                            createTextVNode(" Hapus ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  }
                  _push3(`</form></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100" }, toDisplayString(dialogIndex.value == 0 ? "Tambah" : dialogIndex.value == 1 ? "Edit" : "Hapus"), 1),
                      createVNode("form", {
                        onSubmit: withModifiers(($event) => save(), ["prevent"]),
                        class: "mt-4"
                      }, [
                        dialogIndex.value != 2 ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "grid grid-cols-1 gap-6"
                        }, [
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "question" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pertanyaan ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).question,
                              "onUpdate:modelValue": ($event) => unref(form).question = $event
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.question
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "answer" }, {
                              default: withCtx(() => [
                                createTextVNode(" Kunci Jawaban ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$6, {
                              modelValue: unref(form).answer,
                              "onUpdate:modelValue": ($event) => unref(form).answer = $event,
                              id: "answer",
                              class: "mt-1 block w-full",
                              "option-value": [
                                {
                                  value: "",
                                  text: "--PILIH JAWABAN--"
                                },
                                { value: "A", text: "A" },
                                { value: "B", text: "B" },
                                { value: "C", text: "C" },
                                { value: "D", text: "D" },
                                { value: "E", text: "E" }
                              ]
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.answer
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "option_a" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pilihan A ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).option_a,
                              "onUpdate:modelValue": ($event) => unref(form).option_a = $event,
                              id: "option_a",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.option_a
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "option_b" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pilihan B ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).option_b,
                              "onUpdate:modelValue": ($event) => unref(form).option_b = $event,
                              id: "option_b",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.option_b
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "option_c" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pilihan C ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).option_c,
                              "onUpdate:modelValue": ($event) => unref(form).option_c = $event,
                              id: "option_c",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.option_c
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "option_d" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pilihan D ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).option_d,
                              "onUpdate:modelValue": ($event) => unref(form).option_d = $event,
                              id: "option_d",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.option_d
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "option_e" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pilihan E ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).option_e,
                              "onUpdate:modelValue": ($event) => unref(form).option_e = $event,
                              id: "option_e",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.option_e
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "flex justify-end mt-6" }, [
                            createVNode(_sfc_main$7, {
                              type: "button",
                              onClick: ($event) => close(),
                              class: "mr-2"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Batal ")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(PrimaryButton, { type: "submit" }, {
                              default: withCtx(() => [
                                createTextVNode(" Simpan ")
                              ]),
                              _: 1
                            })
                          ])
                        ])) : (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode("p", null, "Apakah anda yakin ingin menghapus soal ini?"),
                          createVNode("div", { class: "flex justify-end mt-6" }, [
                            createVNode(_sfc_main$7, {
                              type: "button",
                              onClick: ($event) => close(),
                              class: "mr-2"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Batal ")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(PrimaryButton, { type: "submit" }, {
                              default: withCtx(() => [
                                createTextVNode(" Hapus ")
                              ]),
                              _: 1
                            })
                          ])
                        ]))
                      ], 40, ["onSubmit"])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "bg-white p-4 shadow-md rounded-lg" }, [
                    createVNode("div", { class: "flex flex-col sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-lg font-bold text-gray-900 dark:text-gray-100" }, " Kelola Soal " + toDisplayString(__props.exam.name), 1)
                      ]),
                      createVNode("div", { class: "flex space-x-2" }, [
                        createVNode(PrimaryButton, {
                          onClick: ($event) => open(0)
                        }, {
                          default: withCtx(() => [
                            createVNode("i", { class: "fas fa-plus mr-1" }),
                            createTextVNode(" Add question ")
                          ]),
                          _: 1
                        }, 8, ["onClick"])
                      ])
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg" }, [
                      createVNode("table", { class: "w-full text-sm text-left text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col ",
                              class: "px-3 py-3"
                            }, "No"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Soal"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3 text-end"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.questions.data, (item, index) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: index
                            }, [
                              createVNode("th", {
                                scope: "row",
                                class: "px-3 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(index + 1 + (__props.questions.current_page - 1) * __props.questions.per_page), 1),
                              createVNode("td", { class: "px-6 py-4 break-all w-2/3" }, [
                                createVNode("div", {
                                  innerHTML: item.question
                                }, null, 8, ["innerHTML"]),
                                createVNode("br"),
                                (openBlock(true), createBlock(Fragment, null, renderList(Object.keys(
                                  option
                                ), (value, key) => {
                                  return openBlock(), createBlock("span", {
                                    key,
                                    class: {
                                      "font-bold text-green-400": item.answer == value
                                    }
                                  }, [
                                    item[option[value]] != null || item[option[value]] != "" ? (openBlock(), createBlock("span", { key: 0 }, [
                                      createTextVNode(toDisplayString(value) + ". ", 1),
                                      createVNode("span", {
                                        innerHTML: item[option[value]]
                                      }, null, 8, ["innerHTML"]),
                                      createVNode("br")
                                    ])) : createCommentVNode("", true)
                                  ], 2);
                                }), 128))
                              ]),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex justify-end gap-2" }, [
                                  createVNode("button", {
                                    onClick: ($event) => open(1, item),
                                    class: "text-indigo-600 hover:text-indigo-900"
                                  }, [
                                    createVNode("i", { class: "fa-solid fa-pencil" })
                                  ], 8, ["onClick"]),
                                  createVNode("button", {
                                    onClick: ($event) => open(2, item),
                                    class: "text-red-600 hover:text-red-900"
                                  }, [
                                    createVNode("i", { class: "fa-solid fa-trash" })
                                  ], 8, ["onClick"])
                                ])
                              ])
                            ]);
                          }), 128))
                        ])
                      ]),
                      createVNode("div", { class: "py-1 px-4" }, [
                        createVNode("nav", { class: "flex items-center space-x-1" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.questions.links, (link) => {
                            return openBlock(), createBlock("button", {
                              type: "button",
                              class: "min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10",
                              "aria-current": "page",
                              key: link.label,
                              disabled: link.active,
                              onClick: withModifiers(($event) => navigateTo(link.url), ["prevent"])
                            }, [
                              createVNode("span", {
                                innerHTML: link.label
                              }, null, 8, ["innerHTML"])
                            ], 8, ["disabled", "onClick"]);
                          }), 128))
                        ])
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: showModal.value,
                  onClose: ($event) => close()
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100" }, toDisplayString(dialogIndex.value == 0 ? "Tambah" : dialogIndex.value == 1 ? "Edit" : "Hapus"), 1),
                      createVNode("form", {
                        onSubmit: withModifiers(($event) => save(), ["prevent"]),
                        class: "mt-4"
                      }, [
                        dialogIndex.value != 2 ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "grid grid-cols-1 gap-6"
                        }, [
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "question" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pertanyaan ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).question,
                              "onUpdate:modelValue": ($event) => unref(form).question = $event
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.question
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "answer" }, {
                              default: withCtx(() => [
                                createTextVNode(" Kunci Jawaban ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$6, {
                              modelValue: unref(form).answer,
                              "onUpdate:modelValue": ($event) => unref(form).answer = $event,
                              id: "answer",
                              class: "mt-1 block w-full",
                              "option-value": [
                                {
                                  value: "",
                                  text: "--PILIH JAWABAN--"
                                },
                                { value: "A", text: "A" },
                                { value: "B", text: "B" },
                                { value: "C", text: "C" },
                                { value: "D", text: "D" },
                                { value: "E", text: "E" }
                              ]
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.answer
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "option_a" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pilihan A ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).option_a,
                              "onUpdate:modelValue": ($event) => unref(form).option_a = $event,
                              id: "option_a",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.option_a
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "option_b" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pilihan B ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).option_b,
                              "onUpdate:modelValue": ($event) => unref(form).option_b = $event,
                              id: "option_b",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.option_b
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "option_c" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pilihan C ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).option_c,
                              "onUpdate:modelValue": ($event) => unref(form).option_c = $event,
                              id: "option_c",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.option_c
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "option_d" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pilihan D ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).option_d,
                              "onUpdate:modelValue": ($event) => unref(form).option_d = $event,
                              id: "option_d",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.option_d
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, { for: "option_e" }, {
                              default: withCtx(() => [
                                createTextVNode(" Pilihan E ")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$4, {
                              modelValue: unref(form).option_e,
                              "onUpdate:modelValue": ($event) => unref(form).option_e = $event,
                              id: "option_e",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$5, {
                              message: unref(form).errors.option_e
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "flex justify-end mt-6" }, [
                            createVNode(_sfc_main$7, {
                              type: "button",
                              onClick: ($event) => close(),
                              class: "mr-2"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Batal ")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(PrimaryButton, { type: "submit" }, {
                              default: withCtx(() => [
                                createTextVNode(" Simpan ")
                              ]),
                              _: 1
                            })
                          ])
                        ])) : (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode("p", null, "Apakah anda yakin ingin menghapus soal ini?"),
                          createVNode("div", { class: "flex justify-end mt-6" }, [
                            createVNode(_sfc_main$7, {
                              type: "button",
                              onClick: ($event) => close(),
                              class: "mr-2"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Batal ")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(PrimaryButton, { type: "submit" }, {
                              default: withCtx(() => [
                                createTextVNode(" Hapus ")
                              ]),
                              _: 1
                            })
                          ])
                        ]))
                      ], 40, ["onSubmit"])
                    ])
                  ]),
                  _: 1
                }, 8, ["show", "onClose"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Exams/Questions.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
