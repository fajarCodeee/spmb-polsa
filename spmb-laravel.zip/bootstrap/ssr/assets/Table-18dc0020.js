import { mergeProps, useSSRContext, ref, withCtx, unref, createTextVNode, createVNode, toDisplayString, openBlock, createBlock, createCommentVNode } from "vue";
import { ssrRenderAttrs, ssrRenderClass, ssrRenderList, ssrIncludeBooleanAttr, ssrInterpolate, ssrRenderComponent } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$3 } from "./Modal-14fa9cf8.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$6 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$5 } from "./TextareaInput-ea5736c3.js";
import { _ as _sfc_main$4 } from "./InputLabel-5e383564.js";
const _sfc_main$2 = {
  __name: "IconButton",
  __ssrInlineRender: true,
  props: {
    icon: {
      type: String,
      default: "fas fa-plus"
    },
    color: {
      type: String,
      default: "blue"
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<button${ssrRenderAttrs(mergeProps({
        class: ["flex items-center justify-center w-8 h-8 rounded-full", `text-${__props.color}-500 dark:bg-${__props.color}-500/10 dark:text-${__props.color}-400`]
      }, _attrs))}><i class="${ssrRenderClass(`${__props.icon}`)}"></i></button>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/IconButton.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "Pagination",
  __ssrInlineRender: true,
  props: {
    pages: {
      type: Array,
      required: true
    },
    type: {
      type: String,
      default: "visit"
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs(mergeProps({ "aria-label": "Page navigation example" }, _attrs))}><ul class="inline-flex -space-x-px"><!--[-->`);
      ssrRenderList(__props.pages, (link, index) => {
        _push(`<li><button class="${ssrRenderClass([{
          "cursor-not-allowed": link.active || link.url === null,
          "text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white": link.active === false && link.url !== null,
          "text-blue-600 border border-gray-300 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 dark:border-gray-700 dark:bg-gray-700 dark:text-white": link.active === true,
          "ms-0 border border-e-0 rounded-s-lg": index === 0,
          "me-0 border-e-0 rounded-e-lg": index === __props.pages.length - 1
        }, "flex items-center justify-center px-3 h-8 leading-tight"])}"${ssrIncludeBooleanAttr(link.active || link.url === null) ? " disabled" : ""}><span class="truncate">${link.label}</span></button></li>`);
      });
      _push(`<!--]--></ul></nav>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Pagination.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Table",
  __ssrInlineRender: true,
  props: {
    forms: Object,
    open: Function
  },
  setup(__props) {
    const modal = ref(false);
    const type = ref(null);
    const form = useForm({
      id: "",
      status: "",
      reason: ""
    }).transform((fields) => {
      return {
        ...fields,
        reason: fields.reason || null
      };
    });
    const openModal = (f, t) => {
      modal.value = true;
      type.value = t;
      form.status = t;
      form.id = f.id;
    };
    const closeModal = () => {
      modal.value = false;
      type.value = null;
      form.reset();
    };
    const save = () => {
      console.log("save");
      form.patch(route("admin.end-validation.update", form.id), {
        onSuccess: () => {
          closeModal();
        },
        onFinish: () => {
          closeModal();
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative overflow-x-auto shadow-md sm:rounded-lg mt-4" }, _attrs))}><table class="w-full text-sm text-left text-gray-500 dark:text-gray-400"><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"><tr><th scope="col" class="px-3 py-3">No.</th><th scope="col" class="px-6 py-3">Name</th><th scope="col" class="px-6 py-3 text-center"> Nomor Pendaftaran </th><th scope="col" class="px-6 py-3 text-center"> Pilihan Prodi </th><th scope="col" class="px-6 py-3 text-center"> Status Formulir </th><th scope="col" class="px-6 py-3 text-center">Action</th></tr></thead><tbody><!--[-->`);
      ssrRenderList(__props.forms.data, (form2, index) => {
        _push(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"><td class="w-4 p-4">${ssrInterpolate(index + 1 + (__props.forms.current_page - 1) * __props.forms.per_page)}</td><th scope="row" class="flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"><div><div class="text-base font-semibold">${ssrInterpolate(form2.name)}</div><div class="font-normal text-gray-500">${ssrInterpolate(form2.email)}</div></div></th><td class="px-6 py-4 uppercase text-center">${ssrInterpolate(form2.no_exam)}</td><td class="px-6 py-4 capitalize truncate text-center">${ssrInterpolate(form2.prodi)}</td><td class="px-6 py-4 text-center">${ssrInterpolate(form2.status)}</td><td class="px-6 py-4"><div class="flex justify-center"><div>`);
        _push(ssrRenderComponent(_sfc_main$2, {
          icon: "fas fa-check",
          color: "green",
          onClick: ($event) => openModal(form2, "approved")
        }, null, _parent));
        _push(`</div><div>`);
        _push(ssrRenderComponent(_sfc_main$2, {
          icon: "fas fa-eye",
          color: "yellow",
          onClick: ($event) => __props.open(form2)
        }, null, _parent));
        _push(`</div><div>`);
        _push(ssrRenderComponent(_sfc_main$2, {
          icon: "fas fa-times",
          color: "red",
          onClick: ($event) => openModal(form2, "rejected")
        }, null, _parent));
        _push(`</div></div></td></tr>`);
      });
      _push(`<!--]--></tbody></table>`);
      if (__props.forms.data.length === 0) {
        _push(`<div class="flex items-center justify-center p-4"><p class="text-gray-500 dark:text-gray-400"> Tidak ada yang mengajukan pendaftaran </p></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_sfc_main$3, {
        show: modal.value,
        onClose: closeModal
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-4"${_scopeId}><h2 class="text-xl font-semibold text-gray-700 dark:text-white"${_scopeId}> Konfirmasi </h2><p class="text-gray-500 dark:text-gray-400"${_scopeId}> Apakah anda yakin ingin ${ssrInterpolate(type.value === "approved" ? "menerima" : "menolak")} pendaftaran ini?, data yang sudah diinput tidak dapat dikembalikan </p>`);
            if (unref(form).status == "rejected") {
              _push2(`<div class="mt-4 w-full dark:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$4, null, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Alasan Penolakan `);
                  } else {
                    return [
                      createTextVNode(" Alasan Penolakan ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$5, {
                modelValue: unref(form).reason,
                "onUpdate:modelValue": ($event) => unref(form).reason = $event,
                label: "Alasan Penolakan"
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="mt-4 flex gap-2 justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, { onClick: closeModal }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Tidak `);
                } else {
                  return [
                    createTextVNode(" Tidak ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(PrimaryButton, {
              onClick: save,
              disabled: unref(form).status == "rejected" && !unref(form).reason
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Ya `);
                } else {
                  return [
                    createTextVNode(" Ya ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "p-4" }, [
                createVNode("h2", { class: "text-xl font-semibold text-gray-700 dark:text-white" }, " Konfirmasi "),
                createVNode("p", { class: "text-gray-500 dark:text-gray-400" }, " Apakah anda yakin ingin " + toDisplayString(type.value === "approved" ? "menerima" : "menolak") + " pendaftaran ini?, data yang sudah diinput tidak dapat dikembalikan ", 1),
                unref(form).status == "rejected" ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "mt-4 w-full dark:text-white"
                }, [
                  createVNode(_sfc_main$4, null, {
                    default: withCtx(() => [
                      createTextVNode(" Alasan Penolakan ")
                    ]),
                    _: 1
                  }),
                  createVNode(_sfc_main$5, {
                    modelValue: unref(form).reason,
                    "onUpdate:modelValue": ($event) => unref(form).reason = $event,
                    label: "Alasan Penolakan"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ])) : createCommentVNode("", true),
                createVNode("div", { class: "mt-4 flex gap-2 justify-end" }, [
                  createVNode(_sfc_main$6, { onClick: closeModal }, {
                    default: withCtx(() => [
                      createTextVNode(" Tidak ")
                    ]),
                    _: 1
                  }),
                  createVNode(PrimaryButton, {
                    onClick: save,
                    disabled: unref(form).status == "rejected" && !unref(form).reason
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Ya ")
                    ]),
                    _: 1
                  }, 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Verification/End/Partials/Table.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Table = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main
}, Symbol.toStringTag, { value: "Module" }));
export {
  Table as T,
  _sfc_main as _,
  _sfc_main$1 as a
};
