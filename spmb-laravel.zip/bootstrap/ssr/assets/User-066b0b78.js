import { ref, unref, withCtx, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, createCommentVNode, withDirectives, vModelText, Fragment, renderList, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { useForm, Head, router } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$7 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$4 } from "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$3 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$5 } from "./InputError-83b094c2.js";
import Multiselect from "@vueform/multiselect";
import { _ as _sfc_main$6 } from "./Combobox-8f85dcc2.js";
/* empty css                                                            */import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "User",
  __ssrInlineRender: true,
  props: {
    users: Object
  },
  setup(__props) {
    const search = ref("");
    const searchUser = ref(null);
    const timeoutId = ref(null);
    const formModal = useForm({
      name: "",
      email: "",
      phone: "",
      roles: [],
      is_Banned: false
    }).transform((data) => ({
      ...data,
      is_Banned: data.is_Banned == "1" ? 1 : 0
    }));
    const showModal = ref(false);
    const idModal = ref(null);
    const idItemModal = ref(null);
    const open = (item, id) => {
      idModal.value = id;
      showModal.value = true;
      idItemModal.value = item.id;
      if (id !== 0) {
        formModal.name = item.name || "";
        formModal.email = item.email || "";
        formModal.phone = item.phone || "";
        formModal.roles = item.roles;
        formModal.is_Banned = item.is_Banned;
      }
    };
    const close = () => {
      showModal.value = false;
      idModal.value = null;
      idItemModal.value = null;
      formModal.reset();
    };
    const save = () => {
      if (idModal.value === 1) {
        formModal.patch(route("admin.user.update", idItemModal.value), {
          preserveScroll: true,
          onSuccess: () => {
            close();
          }
        });
      } else {
        formModal.delete(route("admin.user.destroy", idItemModal.value), {
          preserveScroll: true,
          onFinish: () => {
            close();
          }
        });
      }
    };
    const navigateTo = (url) => {
      if (url === null)
        return;
      return router.visit(url);
    };
    const find = () => {
      if (!search.value || search.value == "")
        return searchUser.value = null;
      clearTimeout(timeoutId.value);
      timeoutId.value = setTimeout(async () => {
        if (!search.value || search.value == "")
          return;
        const request = await fetch(
          route("admin.user.search", search.value)
        ).then((response) => response.json());
        searchUser.value = request;
      }, 500);
    };
    const findPage = async (url) => {
      if (!url)
        return;
      const request = await fetch(url).then((response) => response.json());
      searchUser.value = request;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard Admin" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="shadow-md sm:shadow-lg p-4 sm:p-8 bg-white"${_scopeId}><div class="flex items-center justify-end flex-column flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900"${_scopeId}><label for="table-search" class="sr-only"${_scopeId}>Search</label><div class="relative"${_scopeId}><div class="absolute inset-y-0 rtl:inset-r-0 start-0 flex items-center ps-3 pointer-events-none"${_scopeId}><svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20"${_scopeId}><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"${_scopeId}></path></svg></div><input type="text" id="table-search-users"${ssrRenderAttr("value", search.value)} class="block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search for users"${_scopeId}></div></div><div class="relative overflow-x-auto shadow-md sm:rounded-lg"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}>Name</th><th scope="col" class="px-6 py-3"${_scopeId}>Phone</th><th scope="col" class="px-6 py-3"${_scopeId}>Role</th><th scope="col" class="px-6 py-3"${_scopeId}> Status </th><th scope="col" class="px-6 py-3"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(searchUser.value ? searchUser.value.data : __props.users.data, (user) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><th scope="row" class="flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}><div${_scopeId}><div class="text-base font-semibold"${_scopeId}>${ssrInterpolate(user.name || "N/A")}</div><div class="font-normal text-gray-500"${_scopeId}>${ssrInterpolate(user.email)}</div></div></th><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(user.phone || "N/A")}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(user.roles.join(", "))}</td><td class="px-6 py-4"${_scopeId}><span class="${ssrRenderClass([{
                "bg-green-100 text-green-800": user.email_verified_at && !user.is_Banned,
                "bg-red-100 text-red-800": user.is_Banned,
                "bg-yellow-100 text-yellow-800": !user.email_verified_at && !user.is_Banned
              }, "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"])}"${_scopeId}>${ssrInterpolate(user.is_Banned ? "Banned" : user.email_verified_at ? "Active" : "Inactive")}</span></td><td class="px-6 py-4"${_scopeId}><div class="flex gap-2"${_scopeId}><button class="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-600"${_scopeId}><i class="fas fa-edit"${_scopeId}></i></button></div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div><div class="py-1 px-4"${_scopeId}><nav class="flex items-center space-x-1"${_scopeId}><!--[-->`);
            ssrRenderList(((_a = searchUser.value) == null ? void 0 : _a.links) ? searchUser.value.links : __props.users.links, (link) => {
              _push2(`<button class="${ssrRenderClass([{
                "cursor-not-allowed opacity-50": link.active || !link.url
              }, "min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10"])}"${ssrRenderAttr("href", link.url || "")}${ssrIncludeBooleanAttr(link.active) ? " disabled" : ""}${_scopeId}><span class="truncate"${_scopeId}>${link.label}</span></button>`);
            });
            _push2(`<!--]--></nav></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              onClose: close,
              show: showModal.value
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-8"${_scopeId2}><h2 class="text-lg font-semibold text-gray-700 dark:text-white"${_scopeId2}>${ssrInterpolate(idModal.value === 1 ? "Edit" : "Delete")} User </h2><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"${_scopeId2}>${ssrInterpolate(idModal.value === 1 ? "Edit data user " + unref(formModal).name : `Apakah anda yakin ingin menghapus user ${unref(formModal).name}?`)}</p>`);
                  if (idModal.value === 1) {
                    _push3(`<div class="mt-4 grid grid-cols-1"${_scopeId2}><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "name" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Name`);
                        } else {
                          return [
                            createTextVNode("Name")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "name",
                      class: "mt-1 block w-full",
                      modelValue: unref(formModal).name,
                      "onUpdate:modelValue": ($event) => unref(formModal).name = $event,
                      error: unref(formModal).errors.name
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      error: unref(formModal).errors.name
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "email" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Email`);
                        } else {
                          return [
                            createTextVNode("Email")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "email",
                      class: "mt-1 block w-full",
                      modelValue: unref(formModal).email,
                      "onUpdate:modelValue": ($event) => unref(formModal).email = $event,
                      error: unref(formModal).errors.email
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      error: unref(formModal).errors.email
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "phone" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Phone`);
                        } else {
                          return [
                            createTextVNode("Phone")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "phone",
                      class: "mt-1 block w-full",
                      modelValue: unref(formModal).phone,
                      "onUpdate:modelValue": ($event) => unref(formModal).phone = $event,
                      error: unref(formModal).errors.phone
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      error: unref(formModal).errors.phone
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "roles" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Roles`);
                        } else {
                          return [
                            createTextVNode("Roles")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(unref(Multiselect), {
                      id: "roles",
                      modelValue: unref(formModal).roles,
                      "onUpdate:modelValue": ($event) => unref(formModal).roles = $event,
                      mode: "multiple",
                      "close-on-select": false,
                      class: "mt-1 block w-full",
                      "clear-on-select": false,
                      "preserve-search": true,
                      label: "label",
                      "track-by": "label",
                      "preselect-first": true,
                      "hide-selected": false,
                      options: [
                        { value: "admin", label: "Admin" },
                        { value: "user", label: "User" },
                        { value: "keuangan", label: "Keuangan" },
                        { value: "panitia", label: "Panitia" }
                      ],
                      error: unref(formModal).errors.roles
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      error: unref(formModal).errors.roles
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, { for: "is_Banned" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`Banned`);
                        } else {
                          return [
                            createTextVNode("Banned")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      id: "is_Banned",
                      modelValue: unref(formModal).is_Banned,
                      "onUpdate:modelValue": ($event) => unref(formModal).is_Banned = $event,
                      class: "mt-1 block w-full",
                      placeholder: "Select an option",
                      "option-value": [
                        { value: 1, text: "Yes" },
                        { value: 0, text: "No" }
                      ],
                      error: unref(formModal).errors.is_Banned
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      error: unref(formModal).errors.is_Banned
                    }, null, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`<div class="mt-4 flex justify-end space-x-4 items-start"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$7, { onClick: close }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Cancel`);
                      } else {
                        return [
                          createTextVNode("Cancel")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(PrimaryButton, { onClick: save }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${ssrInterpolate(idModal.value === 1 ? "Update" : "Delete")}`);
                      } else {
                        return [
                          createTextVNode(toDisplayString(idModal.value === 1 ? "Update" : "Delete"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-8" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-700 dark:text-white" }, toDisplayString(idModal.value === 1 ? "Edit" : "Delete") + " User ", 1),
                      createVNode("p", { class: "mt-1 text-sm text-gray-600 dark:text-gray-400" }, toDisplayString(idModal.value === 1 ? "Edit data user " + unref(formModal).name : `Apakah anda yakin ingin menghapus user ${unref(formModal).name}?`), 1),
                      idModal.value === 1 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-4 grid grid-cols-1"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "name" }, {
                            default: withCtx(() => [
                              createTextVNode("Name")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "name",
                            class: "mt-1 block w-full",
                            modelValue: unref(formModal).name,
                            "onUpdate:modelValue": ($event) => unref(formModal).name = $event,
                            error: unref(formModal).errors.name
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                          createVNode(_sfc_main$5, {
                            error: unref(formModal).errors.name
                          }, null, 8, ["error"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "email" }, {
                            default: withCtx(() => [
                              createTextVNode("Email")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "email",
                            class: "mt-1 block w-full",
                            modelValue: unref(formModal).email,
                            "onUpdate:modelValue": ($event) => unref(formModal).email = $event,
                            error: unref(formModal).errors.email
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                          createVNode(_sfc_main$5, {
                            error: unref(formModal).errors.email
                          }, null, 8, ["error"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "phone" }, {
                            default: withCtx(() => [
                              createTextVNode("Phone")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "phone",
                            class: "mt-1 block w-full",
                            modelValue: unref(formModal).phone,
                            "onUpdate:modelValue": ($event) => unref(formModal).phone = $event,
                            error: unref(formModal).errors.phone
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                          createVNode(_sfc_main$5, {
                            error: unref(formModal).errors.phone
                          }, null, 8, ["error"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "roles" }, {
                            default: withCtx(() => [
                              createTextVNode("Roles")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(Multiselect), {
                            id: "roles",
                            modelValue: unref(formModal).roles,
                            "onUpdate:modelValue": ($event) => unref(formModal).roles = $event,
                            mode: "multiple",
                            "close-on-select": false,
                            class: "mt-1 block w-full",
                            "clear-on-select": false,
                            "preserve-search": true,
                            label: "label",
                            "track-by": "label",
                            "preselect-first": true,
                            "hide-selected": false,
                            options: [
                              { value: "admin", label: "Admin" },
                              { value: "user", label: "User" },
                              { value: "keuangan", label: "Keuangan" },
                              { value: "panitia", label: "Panitia" }
                            ],
                            error: unref(formModal).errors.roles
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                          createVNode(_sfc_main$5, {
                            error: unref(formModal).errors.roles
                          }, null, 8, ["error"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "is_Banned" }, {
                            default: withCtx(() => [
                              createTextVNode("Banned")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$6, {
                            id: "is_Banned",
                            modelValue: unref(formModal).is_Banned,
                            "onUpdate:modelValue": ($event) => unref(formModal).is_Banned = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Select an option",
                            "option-value": [
                              { value: 1, text: "Yes" },
                              { value: 0, text: "No" }
                            ],
                            error: unref(formModal).errors.is_Banned
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                          createVNode(_sfc_main$5, {
                            error: unref(formModal).errors.is_Banned
                          }, null, 8, ["error"])
                        ])
                      ])) : createCommentVNode("", true),
                      createVNode("div", { class: "mt-4 flex justify-end space-x-4 items-start" }, [
                        createVNode(_sfc_main$7, { onClick: close }, {
                          default: withCtx(() => [
                            createTextVNode("Cancel")
                          ]),
                          _: 1
                        }),
                        createVNode(PrimaryButton, { onClick: save }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(idModal.value === 1 ? "Update" : "Delete"), 1)
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "shadow-md sm:shadow-lg p-4 sm:p-8 bg-white" }, [
                    createVNode("div", { class: "flex items-center justify-end flex-column flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900" }, [
                      createVNode("label", {
                        for: "table-search",
                        class: "sr-only"
                      }, "Search"),
                      createVNode("div", { class: "relative" }, [
                        createVNode("div", { class: "absolute inset-y-0 rtl:inset-r-0 start-0 flex items-center ps-3 pointer-events-none" }, [
                          (openBlock(), createBlock("svg", {
                            class: "w-4 h-4 text-gray-500 dark:text-gray-400",
                            "aria-hidden": "true",
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 20 20"
                          }, [
                            createVNode("path", {
                              stroke: "currentColor",
                              "stroke-linecap": "round",
                              "stroke-linejoin": "round",
                              "stroke-width": "2",
                              d: "m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                            })
                          ]))
                        ]),
                        withDirectives(createVNode("input", {
                          type: "text",
                          id: "table-search-users",
                          "onUpdate:modelValue": ($event) => search.value = $event,
                          class: "block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
                          placeholder: "Search for users",
                          onKeyup: find
                        }, null, 40, ["onUpdate:modelValue"]), [
                          [vModelText, search.value]
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Name"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Phone"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Role"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Status "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(searchUser.value ? searchUser.value.data : __props.users.data, (user) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: user.id
                            }, [
                              createVNode("th", {
                                scope: "row",
                                class: "flex items-center px-6 py-4 text-gray-900 whitespace-nowrap dark:text-white"
                              }, [
                                createVNode("div", null, [
                                  createVNode("div", { class: "text-base font-semibold" }, toDisplayString(user.name || "N/A"), 1),
                                  createVNode("div", { class: "font-normal text-gray-500" }, toDisplayString(user.email), 1)
                                ])
                              ]),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(user.phone || "N/A"), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(user.roles.join(", ")), 1),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("span", {
                                  class: ["inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium", {
                                    "bg-green-100 text-green-800": user.email_verified_at && !user.is_Banned,
                                    "bg-red-100 text-red-800": user.is_Banned,
                                    "bg-yellow-100 text-yellow-800": !user.email_verified_at && !user.is_Banned
                                  }]
                                }, toDisplayString(user.is_Banned ? "Banned" : user.email_verified_at ? "Active" : "Inactive"), 3)
                              ]),
                              createVNode("td", { class: "px-6 py-4" }, [
                                createVNode("div", { class: "flex gap-2" }, [
                                  createVNode("button", {
                                    class: "text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-600",
                                    onClick: ($event) => open(user, 1)
                                  }, [
                                    createVNode("i", { class: "fas fa-edit" })
                                  ], 8, ["onClick"])
                                ])
                              ])
                            ]);
                          }), 128))
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "py-1 px-4" }, [
                      createVNode("nav", { class: "flex items-center space-x-1" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(((_b = searchUser.value) == null ? void 0 : _b.links) ? searchUser.value.links : __props.users.links, (link) => {
                          return openBlock(), createBlock("button", {
                            class: ["min-w-[40px] flex justify-center items-center text-gray-800 hover:bg-gray-100 py-2.5 text-sm rounded-full disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-white/10", {
                              "cursor-not-allowed opacity-50": link.active || !link.url
                            }],
                            key: link.label,
                            href: link.url || "",
                            disabled: link.active,
                            onClick: withModifiers(($event) => searchUser.value ? findPage(link.url) : navigateTo(link.url), ["prevent"])
                          }, [
                            createVNode("span", {
                              innerHTML: link.label,
                              class: "truncate"
                            }, null, 8, ["innerHTML"])
                          ], 10, ["href", "disabled", "onClick"]);
                        }), 128))
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  onClose: close,
                  show: showModal.value
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-8" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-700 dark:text-white" }, toDisplayString(idModal.value === 1 ? "Edit" : "Delete") + " User ", 1),
                      createVNode("p", { class: "mt-1 text-sm text-gray-600 dark:text-gray-400" }, toDisplayString(idModal.value === 1 ? "Edit data user " + unref(formModal).name : `Apakah anda yakin ingin menghapus user ${unref(formModal).name}?`), 1),
                      idModal.value === 1 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-4 grid grid-cols-1"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "name" }, {
                            default: withCtx(() => [
                              createTextVNode("Name")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "name",
                            class: "mt-1 block w-full",
                            modelValue: unref(formModal).name,
                            "onUpdate:modelValue": ($event) => unref(formModal).name = $event,
                            error: unref(formModal).errors.name
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                          createVNode(_sfc_main$5, {
                            error: unref(formModal).errors.name
                          }, null, 8, ["error"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "email" }, {
                            default: withCtx(() => [
                              createTextVNode("Email")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "email",
                            class: "mt-1 block w-full",
                            modelValue: unref(formModal).email,
                            "onUpdate:modelValue": ($event) => unref(formModal).email = $event,
                            error: unref(formModal).errors.email
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                          createVNode(_sfc_main$5, {
                            error: unref(formModal).errors.email
                          }, null, 8, ["error"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "phone" }, {
                            default: withCtx(() => [
                              createTextVNode("Phone")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$4, {
                            id: "phone",
                            class: "mt-1 block w-full",
                            modelValue: unref(formModal).phone,
                            "onUpdate:modelValue": ($event) => unref(formModal).phone = $event,
                            error: unref(formModal).errors.phone
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                          createVNode(_sfc_main$5, {
                            error: unref(formModal).errors.phone
                          }, null, 8, ["error"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "roles" }, {
                            default: withCtx(() => [
                              createTextVNode("Roles")
                            ]),
                            _: 1
                          }),
                          createVNode(unref(Multiselect), {
                            id: "roles",
                            modelValue: unref(formModal).roles,
                            "onUpdate:modelValue": ($event) => unref(formModal).roles = $event,
                            mode: "multiple",
                            "close-on-select": false,
                            class: "mt-1 block w-full",
                            "clear-on-select": false,
                            "preserve-search": true,
                            label: "label",
                            "track-by": "label",
                            "preselect-first": true,
                            "hide-selected": false,
                            options: [
                              { value: "admin", label: "Admin" },
                              { value: "user", label: "User" },
                              { value: "keuangan", label: "Keuangan" },
                              { value: "panitia", label: "Panitia" }
                            ],
                            error: unref(formModal).errors.roles
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                          createVNode(_sfc_main$5, {
                            error: unref(formModal).errors.roles
                          }, null, 8, ["error"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, { for: "is_Banned" }, {
                            default: withCtx(() => [
                              createTextVNode("Banned")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$6, {
                            id: "is_Banned",
                            modelValue: unref(formModal).is_Banned,
                            "onUpdate:modelValue": ($event) => unref(formModal).is_Banned = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Select an option",
                            "option-value": [
                              { value: 1, text: "Yes" },
                              { value: 0, text: "No" }
                            ],
                            error: unref(formModal).errors.is_Banned
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                          createVNode(_sfc_main$5, {
                            error: unref(formModal).errors.is_Banned
                          }, null, 8, ["error"])
                        ])
                      ])) : createCommentVNode("", true),
                      createVNode("div", { class: "mt-4 flex justify-end space-x-4 items-start" }, [
                        createVNode(_sfc_main$7, { onClick: close }, {
                          default: withCtx(() => [
                            createTextVNode("Cancel")
                          ]),
                          _: 1
                        }),
                        createVNode(PrimaryButton, { onClick: save }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(idModal.value === 1 ? "Update" : "Delete"), 1)
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/User.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
