import { ref, unref, withCtx, createTextVNode, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { usePage, useForm, Head, router } from "@inertiajs/vue3";
import { _ as _sfc_main$7 } from "./Modal-14fa9cf8.js";
import { _ as _sfc_main$3 } from "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$2 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$6 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$4 } from "./TextareaInput-ea5736c3.js";
import { _ as _sfc_main$5 } from "./Combobox-8f85dcc2.js";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$8 } from "./SecondaryButton-33aab301.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "User",
  __ssrInlineRender: true,
  props: {
    form: Object,
    user: Object,
    prodi: Object,
    wave: Object,
    image: Object
  },
  setup(__props) {
    const form_data = usePage().props.form;
    const formUpdate = useForm({
      status: form_data.status || "",
      note: form_data.note || "",
      is_via_online: form_data.is_via_online == 1 ? true : false,
      is_submitted: form_data.is_submitted == 1 ? true : false
    }).transform((data) => {
      if (data.status === "approved") {
        data.note = null;
      }
      data.is_submitted = data.is_submitted == "true" ? 1 : 0;
      return data;
    });
    const navigateTo = (url) => {
      if (url === null)
        return;
      return router.visit(url);
    };
    const modalDocument = ref(false);
    const modalItem = ref(null);
    const modalType = ref(null);
    const open = (type, item = null) => {
      modalDocument.value = true;
      modalItem.value = item;
      modalType.value = type;
    };
    const close = () => {
      modalDocument.value = false;
      modalItem.value = null;
      modalType.value = null;
    };
    const save = () => {
      formUpdate.patch(route("admin.verification.user.update", [form_data.id]), {
        preserveScroll: true
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Validasi Formulir" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-6xl mx-auto"${_scopeId}><div class="flex justify-between pb-5"${_scopeId}><div class="flex items-center justify-start"${_scopeId}><button class="inline-flex justify-center items-center w-12 h-12 rounded-full bg-white text-black dark:bg-slate-900/70 dark:text-white mr-3"${_scopeId}><i class="fas fa-arrow-left"${_scopeId}></i></button><h1 class="text-xl leading-tight font-semibold"${_scopeId}>${ssrInterpolate(__props.user.name)}</h1></div></div><div class="bg-white p-4 sm:p-8 shadow-md sm:shadow-lg rounded-lg"${_scopeId}><div class="flex flex-col gap-4"${_scopeId}><div${_scopeId}><header${_scopeId}><h2 class="font-bold text-lg"${_scopeId}>Data Pribadi</h2></header><div class="pt-8 grid grid-cols-4 gap-3"${_scopeId}><div class="col-span-4 md:col-span-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, { for: "name" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Nama`);
                } else {
                  return [
                    createTextVNode("Nama")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.user.name,
              "onUpdate:modelValue": ($event) => __props.user.name = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-4 md:col-span-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "email",
              value: "Email"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.user.email,
              "onUpdate:modelValue": ($event) => __props.user.email = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "phone",
              value: "No. HP"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.user.phone,
              "onUpdate:modelValue": ($event) => __props.user.phone = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "national_id",
              value: "Nomor penduduk"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.national_id,
              "onUpdate:modelValue": ($event) => __props.form.national_id = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "gender",
              value: "Jenis kelamin"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.gender,
              "onUpdate:modelValue": ($event) => __props.form.gender = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "religion",
              value: "Agama"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.religion,
              "onUpdate:modelValue": ($event) => __props.form.religion = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "birth_date",
              value: "Tanggal Lahir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.birth_date,
              "onUpdate:modelValue": ($event) => __props.form.birth_date = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "birth_place_city",
              value: "Kota kelahiran"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.birth_place_city,
              "onUpdate:modelValue": ($event) => __props.form.birth_place_city = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "birth_place_province",
              value: "Provinsi kelahiran"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.birth_place_province,
              "onUpdate:modelValue": ($event) => __props.form.birth_place_province = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "birth_place_country",
              value: "Negara kelahiran"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.birth_place_country,
              "onUpdate:modelValue": ($event) => __props.form.birth_place_country = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><div${_scopeId}><header${_scopeId}><h2 class="font-bold text-lg"${_scopeId}>Alamat</h2></header><div class="pt-8 grid grid-cols-4 gap-3"${_scopeId}><div class="col-span-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "address",
              value: "Alamat"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              type: "text",
              value: __props.form.address ? __props.form.address : "-",
              disabled: "",
              class: "mt-1 block w-full",
              modelValue: __props.form.address,
              "onUpdate:modelValue": ($event) => __props.form.address = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "city",
              value: "Kota"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.city,
              "onUpdate:modelValue": ($event) => __props.form.city = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "province",
              value: "Provinsi"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.province,
              "onUpdate:modelValue": ($event) => __props.form.province = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "subdistrict",
              value: "Kecamatan"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.subdistrict,
              "onUpdate:modelValue": ($event) => __props.form.subdistrict = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "country",
              value: "Negara"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.country,
              "onUpdate:modelValue": ($event) => __props.form.country = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "province",
              value: "Provinsi"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.province,
              "onUpdate:modelValue": ($event) => __props.form.province = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "postal_code",
              value: "Kode pos"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.postal_code,
              "onUpdate:modelValue": ($event) => __props.form.postal_code = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "rt",
              value: "Rt"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.rt,
              "onUpdate:modelValue": ($event) => __props.form.rt = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "rw",
              value: "rw"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.rw,
              "onUpdate:modelValue": ($event) => __props.form.rw = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "phone_number",
              value: "No. HP"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.phone_number,
              "onUpdate:modelValue": ($event) => __props.form.phone_number = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "phone_number_alt",
              value: "No. HP alternatif"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.phone_number_alt,
              "onUpdate:modelValue": ($event) => __props.form.phone_number_alt = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><div${_scopeId}><header${_scopeId}><h2 class="font-bold text-lg"${_scopeId}>Kesehatan</h2></header><div class="pt-8 grid grid-cols-4 gap-3"${_scopeId}><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "is_color_blind",
              value: "Buta warna"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              value: __props.form.is_color_blind ? "Ya" : "Tidak",
              disabled: "",
              class: "mt-1 block w-full",
              modelValue: __props.form.is_color_blind,
              "onUpdate:modelValue": ($event) => __props.form.is_color_blind = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "is_disability",
              value: "Disabilitas"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              value: __props.form.is_disability ? "Ya" : "Tidak",
              disabled: "",
              class: "mt-1 block w-full",
              modelValue: __props.form.is_disability,
              "onUpdate:modelValue": ($event) => __props.form.is_disability = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-4 md:col-span-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "disability_note",
              value: "Catatan disabilitas"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              type: "text",
              value: __props.form.disability_note ? __props.form.disability_note : "-",
              disabled: "",
              class: "mt-1 block w-full",
              modelValue: __props.form.disability_note,
              "onUpdate:modelValue": ($event) => __props.form.disability_note = $event
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><div${_scopeId}><header${_scopeId}><h2 class="font-bold text-lg"${_scopeId}>Pendidikan</h2></header><div class="pt-8 grid grid-cols-4 gap-3"${_scopeId}><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "last_education",
              value: "Pendidikan terakhir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.last_education,
              "onUpdate:modelValue": ($event) => __props.form.last_education = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "education_number",
              value: "Nomor siswa / mahasiswa"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.education_number,
              "onUpdate:modelValue": ($event) => __props.form.education_number = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "education_name",
              value: "Nama sekolah / perguruan tinggi"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.education_name,
              "onUpdate:modelValue": ($event) => __props.form.education_name = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "education_graduation_year",
              value: "Tahun lulus"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.education_graduation_year,
              "onUpdate:modelValue": ($event) => __props.form.education_graduation_year = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "education_city",
              value: "Kota"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.education_city,
              "onUpdate:modelValue": ($event) => __props.form.education_city = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "education_province",
              value: "Provinsi"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.education_province,
              "onUpdate:modelValue": ($event) => __props.form.education_province = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "education_subdistrict",
              value: "Kecamatan"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.education_subdistrict,
              "onUpdate:modelValue": ($event) => __props.form.education_subdistrict = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "education_country",
              value: "Negara"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.education_country,
              "onUpdate:modelValue": ($event) => __props.form.education_country = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "education_postal_code",
              value: "Kode pos"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.education_postal_code,
              "onUpdate:modelValue": ($event) => __props.form.education_postal_code = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "education_major",
              value: "Jurusan"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.education_major,
              "onUpdate:modelValue": ($event) => __props.form.education_major = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "education_grade",
              value: "Nilai akhir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.education_grade,
              "onUpdate:modelValue": ($event) => __props.form.education_grade = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><div${_scopeId}><header${_scopeId}><h2 class="font-bold text-lg"${_scopeId}> Orang Tua/Wali </h2></header><div class="flex flex-col gap-4 pt-8"${_scopeId}><div${_scopeId}><header${_scopeId}><h2 class="font-semibold text-base"${_scopeId}> Ayah </h2></header><div class="pt-3 grid grid-cols-4 gap-3"${_scopeId}><div class="col-span-4 md:col-span-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "father_name",
              value: "Nama"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.father_name,
              "onUpdate:modelValue": ($event) => __props.form.father_name = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "father_birth_date",
              value: "Tanggal lahir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.father_birth_date,
              "onUpdate:modelValue": ($event) => __props.form.father_birth_date = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "father_place",
              value: "Tempat lahir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.father_place,
              "onUpdate:modelValue": ($event) => __props.form.father_place = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "father_last_education",
              value: "Pendidikan terakhir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.father_last_education,
              "onUpdate:modelValue": ($event) => __props.form.father_last_education = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "father_job",
              value: "Pekerjaan"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.father_job,
              "onUpdate:modelValue": ($event) => __props.form.father_job = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "father_phone",
              value: "No. HP"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.father_phone,
              "onUpdate:modelValue": ($event) => __props.form.father_phone = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "father_email",
              value: "Email"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.father_email,
              "onUpdate:modelValue": ($event) => __props.form.father_email = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><div${_scopeId}><header${_scopeId}><h2 class="font-semibold text-base"${_scopeId}> Ibu </h2></header><div class="pt-3 grid grid-cols-4 gap-3"${_scopeId}><div class="col-span-4 md:col-span-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "mother_name",
              value: "Nama"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.mother_name,
              "onUpdate:modelValue": ($event) => __props.form.mother_name = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "mother_birth_date",
              value: "Tanggal lahir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.mother_birth_date,
              "onUpdate:modelValue": ($event) => __props.form.mother_birth_date = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "mother_place",
              value: "Tempat lahir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.mother_place,
              "onUpdate:modelValue": ($event) => __props.form.mother_place = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "mother_last_education",
              value: "Pendidikan terakhir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.mother_last_education,
              "onUpdate:modelValue": ($event) => __props.form.mother_last_education = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "mother_job",
              value: "Pekerjaan"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.mother_job,
              "onUpdate:modelValue": ($event) => __props.form.mother_job = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "mother_phone",
              value: "No. HP"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.mother_phone,
              "onUpdate:modelValue": ($event) => __props.form.mother_phone = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "mother_email",
              value: "Email"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.mother_email,
              "onUpdate:modelValue": ($event) => __props.form.mother_email = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><div${_scopeId}><header${_scopeId}><h2 class="font-semibold text-base"${_scopeId}> Wali </h2></header><div class="pt-3 grid grid-cols-4 gap-3"${_scopeId}><div class="col-span-4 md:col-span-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "guardian_name",
              value: "Nama"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.guardian_name,
              "onUpdate:modelValue": ($event) => __props.form.guardian_name = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "guardian_birth_date",
              value: "Tanggal lahir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.guardian_birth_date,
              "onUpdate:modelValue": ($event) => __props.form.guardian_birth_date = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "guardian_place",
              value: "Tempat lahir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.guardian_place,
              "onUpdate:modelValue": ($event) => __props.form.guardian_place = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "guardian_last_education",
              value: "Pendidikan terakhir"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.guardian_last_education,
              "onUpdate:modelValue": ($event) => __props.form.guardian_last_education = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "guardian_job",
              value: "Pekerjaan"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.guardian_job,
              "onUpdate:modelValue": ($event) => __props.form.guardian_job = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "guardian_phone",
              value: "No. HP"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.guardian_phone,
              "onUpdate:modelValue": ($event) => __props.form.guardian_phone = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "guardian_email",
              value: "Email"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "text",
              modelValue: __props.form.guardian_email,
              "onUpdate:modelValue": ($event) => __props.form.guardian_email = $event,
              disabled: "",
              class: "mt-1 block w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div></div></div><div${_scopeId}><header${_scopeId}><h2 class="font-bold text-lg"${_scopeId}>Dokumen</h2></header><div class="pt-8 grid grid-cols-2 gap-3"${_scopeId}><!--[-->`);
            ssrRenderList(__props.image, (document, index) => {
              _push2(`<div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4"${_scopeId}><header${_scopeId}><h3 class="font-semibold text-gray-900 dark:text-gray-100 capitalize"${_scopeId}>${ssrInterpolate(index.replace("_", " "))}</h3></header><button class="mt-4 h-40 w-full hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg overflow-hidden"${_scopeId}>`);
              if (document) {
                _push2(`<img${ssrRenderAttr("src", document)}${ssrRenderAttr("alt", index)} class="overflow-hidden object-cover w-full h-full rounded-lg"${_scopeId}>`);
              } else {
                _push2(`<div class="flex items-center justify-center h-full"${_scopeId}><p class="text-gray-400"${_scopeId}> Belum ada ${ssrInterpolate(index.replace("_", " "))} yang diunggah </p></div>`);
              }
              _push2(`</button></div>`);
            });
            _push2(`<!--]--></div></div><div${_scopeId}><header${_scopeId}><h2 class="font-bold text-lg"${_scopeId}> Status Formulir </h2></header><div class="pt-8 grid grid-cols-4 gap-3"${_scopeId}><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "status",
              value: "Status"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "status",
              ref: "status",
              modelValue: unref(formUpdate).status,
              "onUpdate:modelValue": ($event) => unref(formUpdate).status = $event,
              class: "mt-1 block w-full",
              placeholder: "Pilih status",
              "option-value": [
                {
                  value: "approved",
                  text: "Approved"
                },
                {
                  value: "rejected",
                  text: "Rejected"
                }
              ]
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              message: unref(formUpdate).errors.status,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "is_via_online",
              value: "Pendaftaran online"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "is_via_online",
              ref: "is_via_online",
              modelValue: unref(formUpdate).is_via_online,
              "onUpdate:modelValue": ($event) => unref(formUpdate).is_via_online = $event,
              class: "mt-1 block w-full",
              placeholder: "Pilih status",
              "option-value": [
                {
                  value: true,
                  text: "Ya"
                },
                {
                  value: false,
                  text: "Tidak"
                }
              ]
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              message: unref(formUpdate).errors.is_via_online,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-2 md:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "is_submitted",
              value: "Di kumpul"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "is_submitted",
              ref: "is_submitted",
              modelValue: unref(formUpdate).is_submitted,
              "onUpdate:modelValue": ($event) => unref(formUpdate).is_submitted = $event,
              class: "mt-1 block w-full",
              placeholder: "Pilih status",
              "option-value": [
                {
                  value: "true",
                  text: "Ya"
                },
                {
                  value: "false",
                  text: "Tidak"
                }
              ]
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              message: unref(formUpdate).errors.is_submitted,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            if (unref(formUpdate).status !== "approved") {
              _push2(`<div class="col-span-4 md:col-span-4"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for: "note",
                value: "Catatan"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$4, {
                type: "text",
                value: unref(formUpdate).note ? unref(formUpdate).note : "-",
                class: "mt-1 block w-full",
                modelValue: unref(formUpdate).note,
                "onUpdate:modelValue": ($event) => unref(formUpdate).note = $event
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$6, {
                message: unref(formUpdate).errors.note,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="flex justify-end pt-3"${_scopeId}>`);
            _push2(ssrRenderComponent(PrimaryButton, {
              onClick: ($event) => save()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Submit`);
                } else {
                  return [
                    createTextVNode("Submit")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$7, {
              show: modalDocument.value,
              onClose: ($event) => close()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 capitalize"${_scopeId2}> View ${ssrInterpolate(modalType.value.replace("_", " "))}</h2><img${ssrRenderAttr("src", modalItem.value)}${ssrRenderAttr("alt", `Bukti pembayaran ${modalType.value}`)} class="mt-4 w-full h-full rounded-lg object-cover overflow-hidden"${_scopeId2}><div class="mt-6"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$8, {
                    onClick: close,
                    class: "ml-2"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Close `);
                      } else {
                        return [
                          createTextVNode(" Close ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100 capitalize" }, " View " + toDisplayString(modalType.value.replace("_", " ")), 1),
                      createVNode("img", {
                        src: modalItem.value,
                        alt: `Bukti pembayaran ${modalType.value}`,
                        class: "mt-4 w-full h-full rounded-lg object-cover overflow-hidden"
                      }, null, 8, ["src", "alt"]),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode(_sfc_main$8, {
                          onClick: close,
                          class: "ml-2"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Close ")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-6xl mx-auto" }, [
                  createVNode("div", { class: "flex justify-between pb-5" }, [
                    createVNode("div", { class: "flex items-center justify-start" }, [
                      createVNode("button", {
                        class: "inline-flex justify-center items-center w-12 h-12 rounded-full bg-white text-black dark:bg-slate-900/70 dark:text-white mr-3",
                        onClick: ($event) => navigateTo(_ctx.route("admin.verification"))
                      }, [
                        createVNode("i", { class: "fas fa-arrow-left" })
                      ], 8, ["onClick"]),
                      createVNode("h1", { class: "text-xl leading-tight font-semibold" }, toDisplayString(__props.user.name), 1)
                    ])
                  ]),
                  createVNode("div", { class: "bg-white p-4 sm:p-8 shadow-md sm:shadow-lg rounded-lg" }, [
                    createVNode("div", { class: "flex flex-col gap-4" }, [
                      createVNode("div", null, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "font-bold text-lg" }, "Data Pribadi")
                        ]),
                        createVNode("div", { class: "pt-8 grid grid-cols-4 gap-3" }, [
                          createVNode("div", { class: "col-span-4 md:col-span-2" }, [
                            createVNode(_sfc_main$2, { for: "name" }, {
                              default: withCtx(() => [
                                createTextVNode("Nama")
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.user.name,
                              "onUpdate:modelValue": ($event) => __props.user.name = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-4 md:col-span-2" }, [
                            createVNode(_sfc_main$2, {
                              for: "email",
                              value: "Email"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.user.email,
                              "onUpdate:modelValue": ($event) => __props.user.email = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "phone",
                              value: "No. HP"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.user.phone,
                              "onUpdate:modelValue": ($event) => __props.user.phone = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "national_id",
                              value: "Nomor penduduk"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.national_id,
                              "onUpdate:modelValue": ($event) => __props.form.national_id = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "gender",
                              value: "Jenis kelamin"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.gender,
                              "onUpdate:modelValue": ($event) => __props.form.gender = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "religion",
                              value: "Agama"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.religion,
                              "onUpdate:modelValue": ($event) => __props.form.religion = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "birth_date",
                              value: "Tanggal Lahir"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.birth_date,
                              "onUpdate:modelValue": ($event) => __props.form.birth_date = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "birth_place_city",
                              value: "Kota kelahiran"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.birth_place_city,
                              "onUpdate:modelValue": ($event) => __props.form.birth_place_city = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "birth_place_province",
                              value: "Provinsi kelahiran"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.birth_place_province,
                              "onUpdate:modelValue": ($event) => __props.form.birth_place_province = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "birth_place_country",
                              value: "Negara kelahiran"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.birth_place_country,
                              "onUpdate:modelValue": ($event) => __props.form.birth_place_country = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ])
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "font-bold text-lg" }, "Alamat")
                        ]),
                        createVNode("div", { class: "pt-8 grid grid-cols-4 gap-3" }, [
                          createVNode("div", { class: "col-span-4" }, [
                            createVNode(_sfc_main$2, {
                              for: "address",
                              value: "Alamat"
                            }),
                            createVNode(_sfc_main$4, {
                              type: "text",
                              value: __props.form.address ? __props.form.address : "-",
                              disabled: "",
                              class: "mt-1 block w-full",
                              modelValue: __props.form.address,
                              "onUpdate:modelValue": ($event) => __props.form.address = $event
                            }, null, 8, ["value", "modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "city",
                              value: "Kota"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.city,
                              "onUpdate:modelValue": ($event) => __props.form.city = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "province",
                              value: "Provinsi"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.province,
                              "onUpdate:modelValue": ($event) => __props.form.province = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "subdistrict",
                              value: "Kecamatan"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.subdistrict,
                              "onUpdate:modelValue": ($event) => __props.form.subdistrict = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "country",
                              value: "Negara"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.country,
                              "onUpdate:modelValue": ($event) => __props.form.country = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "province",
                              value: "Provinsi"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.province,
                              "onUpdate:modelValue": ($event) => __props.form.province = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "postal_code",
                              value: "Kode pos"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.postal_code,
                              "onUpdate:modelValue": ($event) => __props.form.postal_code = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "rt",
                              value: "Rt"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.rt,
                              "onUpdate:modelValue": ($event) => __props.form.rt = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "rw",
                              value: "rw"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.rw,
                              "onUpdate:modelValue": ($event) => __props.form.rw = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "phone_number",
                              value: "No. HP"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.phone_number,
                              "onUpdate:modelValue": ($event) => __props.form.phone_number = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "phone_number_alt",
                              value: "No. HP alternatif"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.phone_number_alt,
                              "onUpdate:modelValue": ($event) => __props.form.phone_number_alt = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ])
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "font-bold text-lg" }, "Kesehatan")
                        ]),
                        createVNode("div", { class: "pt-8 grid grid-cols-4 gap-3" }, [
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "is_color_blind",
                              value: "Buta warna"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              value: __props.form.is_color_blind ? "Ya" : "Tidak",
                              disabled: "",
                              class: "mt-1 block w-full",
                              modelValue: __props.form.is_color_blind,
                              "onUpdate:modelValue": ($event) => __props.form.is_color_blind = $event
                            }, null, 8, ["value", "modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "is_disability",
                              value: "Disabilitas"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              value: __props.form.is_disability ? "Ya" : "Tidak",
                              disabled: "",
                              class: "mt-1 block w-full",
                              modelValue: __props.form.is_disability,
                              "onUpdate:modelValue": ($event) => __props.form.is_disability = $event
                            }, null, 8, ["value", "modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-4 md:col-span-4" }, [
                            createVNode(_sfc_main$2, {
                              for: "disability_note",
                              value: "Catatan disabilitas"
                            }),
                            createVNode(_sfc_main$4, {
                              type: "text",
                              value: __props.form.disability_note ? __props.form.disability_note : "-",
                              disabled: "",
                              class: "mt-1 block w-full",
                              modelValue: __props.form.disability_note,
                              "onUpdate:modelValue": ($event) => __props.form.disability_note = $event
                            }, null, 8, ["value", "modelValue", "onUpdate:modelValue"])
                          ])
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "font-bold text-lg" }, "Pendidikan")
                        ]),
                        createVNode("div", { class: "pt-8 grid grid-cols-4 gap-3" }, [
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "last_education",
                              value: "Pendidikan terakhir"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.last_education,
                              "onUpdate:modelValue": ($event) => __props.form.last_education = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "education_number",
                              value: "Nomor siswa / mahasiswa"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.education_number,
                              "onUpdate:modelValue": ($event) => __props.form.education_number = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "education_name",
                              value: "Nama sekolah / perguruan tinggi"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.education_name,
                              "onUpdate:modelValue": ($event) => __props.form.education_name = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "education_graduation_year",
                              value: "Tahun lulus"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.education_graduation_year,
                              "onUpdate:modelValue": ($event) => __props.form.education_graduation_year = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "education_city",
                              value: "Kota"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.education_city,
                              "onUpdate:modelValue": ($event) => __props.form.education_city = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "education_province",
                              value: "Provinsi"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.education_province,
                              "onUpdate:modelValue": ($event) => __props.form.education_province = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "education_subdistrict",
                              value: "Kecamatan"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.education_subdistrict,
                              "onUpdate:modelValue": ($event) => __props.form.education_subdistrict = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "education_country",
                              value: "Negara"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.education_country,
                              "onUpdate:modelValue": ($event) => __props.form.education_country = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "education_postal_code",
                              value: "Kode pos"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.education_postal_code,
                              "onUpdate:modelValue": ($event) => __props.form.education_postal_code = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "education_major",
                              value: "Jurusan"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.education_major,
                              "onUpdate:modelValue": ($event) => __props.form.education_major = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "education_grade",
                              value: "Nilai akhir"
                            }),
                            createVNode(_sfc_main$3, {
                              type: "text",
                              modelValue: __props.form.education_grade,
                              "onUpdate:modelValue": ($event) => __props.form.education_grade = $event,
                              disabled: "",
                              class: "mt-1 block w-full"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ])
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "font-bold text-lg" }, " Orang Tua/Wali ")
                        ]),
                        createVNode("div", { class: "flex flex-col gap-4 pt-8" }, [
                          createVNode("div", null, [
                            createVNode("header", null, [
                              createVNode("h2", { class: "font-semibold text-base" }, " Ayah ")
                            ]),
                            createVNode("div", { class: "pt-3 grid grid-cols-4 gap-3" }, [
                              createVNode("div", { class: "col-span-4 md:col-span-2" }, [
                                createVNode(_sfc_main$2, {
                                  for: "father_name",
                                  value: "Nama"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.father_name,
                                  "onUpdate:modelValue": ($event) => __props.form.father_name = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "father_birth_date",
                                  value: "Tanggal lahir"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.father_birth_date,
                                  "onUpdate:modelValue": ($event) => __props.form.father_birth_date = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "father_place",
                                  value: "Tempat lahir"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.father_place,
                                  "onUpdate:modelValue": ($event) => __props.form.father_place = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "father_last_education",
                                  value: "Pendidikan terakhir"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.father_last_education,
                                  "onUpdate:modelValue": ($event) => __props.form.father_last_education = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "father_job",
                                  value: "Pekerjaan"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.father_job,
                                  "onUpdate:modelValue": ($event) => __props.form.father_job = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "father_phone",
                                  value: "No. HP"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.father_phone,
                                  "onUpdate:modelValue": ($event) => __props.form.father_phone = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "father_email",
                                  value: "Email"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.father_email,
                                  "onUpdate:modelValue": ($event) => __props.form.father_email = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ])
                            ])
                          ]),
                          createVNode("div", null, [
                            createVNode("header", null, [
                              createVNode("h2", { class: "font-semibold text-base" }, " Ibu ")
                            ]),
                            createVNode("div", { class: "pt-3 grid grid-cols-4 gap-3" }, [
                              createVNode("div", { class: "col-span-4 md:col-span-2" }, [
                                createVNode(_sfc_main$2, {
                                  for: "mother_name",
                                  value: "Nama"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.mother_name,
                                  "onUpdate:modelValue": ($event) => __props.form.mother_name = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "mother_birth_date",
                                  value: "Tanggal lahir"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.mother_birth_date,
                                  "onUpdate:modelValue": ($event) => __props.form.mother_birth_date = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "mother_place",
                                  value: "Tempat lahir"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.mother_place,
                                  "onUpdate:modelValue": ($event) => __props.form.mother_place = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "mother_last_education",
                                  value: "Pendidikan terakhir"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.mother_last_education,
                                  "onUpdate:modelValue": ($event) => __props.form.mother_last_education = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "mother_job",
                                  value: "Pekerjaan"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.mother_job,
                                  "onUpdate:modelValue": ($event) => __props.form.mother_job = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "mother_phone",
                                  value: "No. HP"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.mother_phone,
                                  "onUpdate:modelValue": ($event) => __props.form.mother_phone = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "mother_email",
                                  value: "Email"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.mother_email,
                                  "onUpdate:modelValue": ($event) => __props.form.mother_email = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ])
                            ])
                          ]),
                          createVNode("div", null, [
                            createVNode("header", null, [
                              createVNode("h2", { class: "font-semibold text-base" }, " Wali ")
                            ]),
                            createVNode("div", { class: "pt-3 grid grid-cols-4 gap-3" }, [
                              createVNode("div", { class: "col-span-4 md:col-span-2" }, [
                                createVNode(_sfc_main$2, {
                                  for: "guardian_name",
                                  value: "Nama"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.guardian_name,
                                  "onUpdate:modelValue": ($event) => __props.form.guardian_name = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "guardian_birth_date",
                                  value: "Tanggal lahir"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.guardian_birth_date,
                                  "onUpdate:modelValue": ($event) => __props.form.guardian_birth_date = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "guardian_place",
                                  value: "Tempat lahir"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.guardian_place,
                                  "onUpdate:modelValue": ($event) => __props.form.guardian_place = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "guardian_last_education",
                                  value: "Pendidikan terakhir"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.guardian_last_education,
                                  "onUpdate:modelValue": ($event) => __props.form.guardian_last_education = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "guardian_job",
                                  value: "Pekerjaan"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.guardian_job,
                                  "onUpdate:modelValue": ($event) => __props.form.guardian_job = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "guardian_phone",
                                  value: "No. HP"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.guardian_phone,
                                  "onUpdate:modelValue": ($event) => __props.form.guardian_phone = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                                createVNode(_sfc_main$2, {
                                  for: "guardian_email",
                                  value: "Email"
                                }),
                                createVNode(_sfc_main$3, {
                                  type: "text",
                                  modelValue: __props.form.guardian_email,
                                  "onUpdate:modelValue": ($event) => __props.form.guardian_email = $event,
                                  disabled: "",
                                  class: "mt-1 block w-full"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ])
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "font-bold text-lg" }, "Dokumen")
                        ]),
                        createVNode("div", { class: "pt-8 grid grid-cols-2 gap-3" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.image, (document, index) => {
                            return openBlock(), createBlock("div", {
                              class: "bg-white dark:bg-gray-800 rounded-lg shadow-md p-4",
                              key: index
                            }, [
                              createVNode("header", null, [
                                createVNode("h3", { class: "font-semibold text-gray-900 dark:text-gray-100 capitalize" }, toDisplayString(index.replace("_", " ")), 1)
                              ]),
                              createVNode("button", {
                                class: "mt-4 h-40 w-full hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg overflow-hidden",
                                onClick: ($event) => open(index, document)
                              }, [
                                document ? (openBlock(), createBlock("img", {
                                  key: 0,
                                  src: document,
                                  alt: index,
                                  class: "overflow-hidden object-cover w-full h-full rounded-lg"
                                }, null, 8, ["src", "alt"])) : (openBlock(), createBlock("div", {
                                  key: 1,
                                  class: "flex items-center justify-center h-full"
                                }, [
                                  createVNode("p", { class: "text-gray-400" }, " Belum ada " + toDisplayString(index.replace("_", " ")) + " yang diunggah ", 1)
                                ]))
                              ], 8, ["onClick"])
                            ]);
                          }), 128))
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "font-bold text-lg" }, " Status Formulir ")
                        ]),
                        createVNode("div", { class: "pt-8 grid grid-cols-4 gap-3" }, [
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "status",
                              value: "Status"
                            }),
                            createVNode(_sfc_main$5, {
                              id: "status",
                              ref: "status",
                              modelValue: unref(formUpdate).status,
                              "onUpdate:modelValue": ($event) => unref(formUpdate).status = $event,
                              class: "mt-1 block w-full",
                              placeholder: "Pilih status",
                              "option-value": [
                                {
                                  value: "approved",
                                  text: "Approved"
                                },
                                {
                                  value: "rejected",
                                  text: "Rejected"
                                }
                              ]
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$6, {
                              message: unref(formUpdate).errors.status,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "is_via_online",
                              value: "Pendaftaran online"
                            }),
                            createVNode(_sfc_main$5, {
                              id: "is_via_online",
                              ref: "is_via_online",
                              modelValue: unref(formUpdate).is_via_online,
                              "onUpdate:modelValue": ($event) => unref(formUpdate).is_via_online = $event,
                              class: "mt-1 block w-full",
                              placeholder: "Pilih status",
                              "option-value": [
                                {
                                  value: true,
                                  text: "Ya"
                                },
                                {
                                  value: false,
                                  text: "Tidak"
                                }
                              ]
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$6, {
                              message: unref(formUpdate).errors.is_via_online,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "col-span-2 md:col-span-1" }, [
                            createVNode(_sfc_main$2, {
                              for: "is_submitted",
                              value: "Di kumpul"
                            }),
                            createVNode(_sfc_main$5, {
                              id: "is_submitted",
                              ref: "is_submitted",
                              modelValue: unref(formUpdate).is_submitted,
                              "onUpdate:modelValue": ($event) => unref(formUpdate).is_submitted = $event,
                              class: "mt-1 block w-full",
                              placeholder: "Pilih status",
                              "option-value": [
                                {
                                  value: "true",
                                  text: "Ya"
                                },
                                {
                                  value: "false",
                                  text: "Tidak"
                                }
                              ]
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$6, {
                              message: unref(formUpdate).errors.is_submitted,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ]),
                          unref(formUpdate).status !== "approved" ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "col-span-4 md:col-span-4"
                          }, [
                            createVNode(_sfc_main$2, {
                              for: "note",
                              value: "Catatan"
                            }),
                            createVNode(_sfc_main$4, {
                              type: "text",
                              value: unref(formUpdate).note ? unref(formUpdate).note : "-",
                              class: "mt-1 block w-full",
                              modelValue: unref(formUpdate).note,
                              "onUpdate:modelValue": ($event) => unref(formUpdate).note = $event
                            }, null, 8, ["value", "modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$6, {
                              message: unref(formUpdate).errors.note,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ])) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "flex justify-end pt-3" }, [
                          createVNode(PrimaryButton, {
                            onClick: withModifiers(($event) => save(), ["prevent"])
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Submit")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ])
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$7, {
                  show: modalDocument.value,
                  onClose: ($event) => close()
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100 capitalize" }, " View " + toDisplayString(modalType.value.replace("_", " ")), 1),
                      createVNode("img", {
                        src: modalItem.value,
                        alt: `Bukti pembayaran ${modalType.value}`,
                        class: "mt-4 w-full h-full rounded-lg object-cover overflow-hidden"
                      }, null, 8, ["src", "alt"]),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode(_sfc_main$8, {
                          onClick: close,
                          class: "ml-2"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Close ")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show", "onClose"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Verification/User.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
