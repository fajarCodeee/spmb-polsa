import { ref, unref, withCtx, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import { _ as _sfc_main$2 } from "./Modal-14fa9cf8.js";
import { useForm, Head } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import { _ as _sfc_main$8 } from "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$4 } from "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$3 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$5 } from "./InputError-83b094c2.js";
import { _ as _sfc_main$6 } from "./DateInput-00587317.js";
import { _ as _sfc_main$7 } from "./Combobox-8f85dcc2.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "Wave",
  __ssrInlineRender: true,
  props: {
    wave: {
      type: Object
    }
  },
  setup(__props) {
    const form = useForm({
      code: "",
      gelombang: "",
      tahun_akademik: "",
      awal_daftar: "",
      akhir_daftar: "",
      tes_tulis: "",
      tes_kesehatan: "",
      wawancara: "",
      active: "false"
    }).transform((data) => ({
      ...data,
      active: data.active == "true" ? true : false
    }));
    const itemIndex = ref(null);
    const dialog = ref(false);
    const dialogItem = ref(null);
    const save = () => {
      if (dialog.value) {
        if (itemIndex.value == 0) {
          form.post(route("admin.wave.store"), {
            preserveScroll: true,
            onSuccess: () => close(),
            onError: () => gelombangInput.value.focus()
            // onFinish: () => form.reset(),
          });
        } else if (itemIndex.value == 1) {
          form.patch(route("admin.wave.update", { id: dialogItem.value }), {
            preserveScroll: true,
            onSuccess: () => close(),
            onError: () => gelombangInput.value.focus(),
            onFinish: () => form.reset()
          });
        } else if (itemIndex.value == 2) {
          form.delete(route("admin.wave.destroy", { id: dialogItem.value }), {
            preserveScroll: true,
            onSuccess: () => close(),
            onError: () => gelombangInput.value.focus(),
            onFinish: () => form.reset()
          });
        }
      } else {
        dialog.value = true;
      }
    };
    const openDialog = (index, item = null) => {
      itemIndex.value = index;
      if (itemIndex.value == 0) {
        form.reset();
      } else if (itemIndex.value == 1) {
        dialogItem.value = item.id;
        form.code = item.code;
        form.gelombang = item.gelombang;
        form.tahun_akademik = item.tahun_akademik;
        form.awal_daftar = item.awal_daftar;
        form.akhir_daftar = item.akhir_daftar;
        form.tes_tulis = item.tes_tulis;
        form.tes_kesehatan = item.tes_kesehatan;
        form.wawancara = item.wawancara;
        form.active = item.active ? "true" : "false";
      } else if (itemIndex.value == 2) {
        dialogItem.value = item.id;
      }
      dialog.value = true;
    };
    const close = () => {
      dialog.value = false;
      itemIndex.value = null;
      dialogItem.value = null;
      form.reset();
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Setting Prodi" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="max-w-7xl mx-auto"${_scopeId}><div class="shadow-md sm:shadow-lg p-4 sm:p-8 bg-white"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4"${_scopeId}><header${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}> Gelombang </h2></header>`);
            _push2(ssrRenderComponent(PrimaryButton, {
              onClick: ($event) => openDialog(0)
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Create`);
                } else {
                  return [
                    createTextVNode(" Create")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="relative overflow-x-auto"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}>Code</th><th scope="col" class="px-6 py-3"${_scopeId}> Gelombang </th><th scope="col" class="px-6 py-3"${_scopeId}> Tahun Akademik </th><th scope="col" class="px-6 py-3"${_scopeId}> Awal Pendaftaran </th><th scope="col" class="px-6 py-3"${_scopeId}> Akhir Pendaftaran </th><th scope="col" class="px-6 py-3"${_scopeId}> Is_Active </th><th scope="col" class="px-6 py-3"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.wave, (item) => {
              _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(item.code)}</th><td class="px-6 py-4 truncate"${_scopeId}>${ssrInterpolate(item.gelombang)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(item.tahun_akademik)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(item.awal_daftar)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(item.akhir_daftar)}</td><td class="px-6 py-4"${_scopeId}>`);
              if (item.active) {
                _push2(`<i class="fas fa-check text-green-500"${_scopeId}></i>`);
              } else {
                _push2(`<i class="fas fa-times text-red-500"${_scopeId}></i>`);
              }
              _push2(`</td><td class="px-6 py-4 flex gap-2"${_scopeId}><button class="text-indigo-600 hover:text-indigo-900"${_scopeId}><i class="fa-solid fa-pencil"${_scopeId}></i></button><button class="text-red-600 hover:text-red-900"${_scopeId}><i class="fa-solid fa-trash"${_scopeId}></i></button></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: dialog.value,
              onClose: ($event) => close()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId2}>${ssrInterpolate(itemIndex.value == 0 ? "Create" : itemIndex.value == 1 ? "Edit" : "Delete")}</h2>`);
                  if (itemIndex.value != 2) {
                    _push3(`<div class="mt-6 grid grid-cols-1 gap-4"${_scopeId2}><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "code",
                      value: "Code"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "code",
                      ref: "codeInput",
                      modelValue: unref(form).code,
                      "onUpdate:modelValue": ($event) => unref(form).code = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      placeholder: "Code"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.code,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "gelombang",
                      value: "Gelombang"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "gelombang",
                      ref: "gelombangInput",
                      modelValue: unref(form).gelombang,
                      "onUpdate:modelValue": ($event) => unref(form).gelombang = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      placeholder: "Gelombang"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.gelombang,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "tahun_akademik",
                      value: "Tahun Akademik"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      id: "tahun_akademik",
                      ref: "tahun_akademikInput",
                      modelValue: unref(form).tahun_akademik,
                      "onUpdate:modelValue": ($event) => unref(form).tahun_akademik = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      placeholder: "Tahun Akademik"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.tahun_akademik,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "awal_daftar",
                      value: "Awal Daftar"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      id: "awal_daftar",
                      ref: "awal_daftarInput",
                      modelValue: unref(form).awal_daftar,
                      "onUpdate:modelValue": ($event) => unref(form).awal_daftar = $event,
                      class: "mt-1 block w-full",
                      placeholder: "Awal Daftar"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.awal_daftar,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "akhir_daftar",
                      value: "Akhir Daftar"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$6, {
                      id: "akhir_daftar",
                      modelValue: unref(form).akhir_daftar,
                      "onUpdate:modelValue": ($event) => unref(form).akhir_daftar = $event,
                      class: "mt -1 block w-full"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.akhir_daftar,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_sfc_main$3, {
                      for: "active",
                      value: "Active"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$7, {
                      id: "active",
                      modelValue: unref(form).active,
                      "onUpdate:modelValue": ($event) => unref(form).active = $event,
                      class: "mt-1 block w-full",
                      "option-value": [
                        { value: "true", text: "Yes" },
                        { value: "false", text: "No" },
                        { value: "null", text: "Select" }
                      ]
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_sfc_main$5, {
                      message: unref(form).errors.active,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  } else {
                    _push3(`<div${_scopeId2}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId2}> Are you sure you want to delete this wave? </h2></div>`);
                  }
                  _push3(`<div class="mt-6"${_scopeId2}>`);
                  _push3(ssrRenderComponent(PrimaryButton, {
                    onClick: ($event) => save()
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${ssrInterpolate(itemIndex.value == 0 ? "Create" : itemIndex.value == 1 ? "Edit" : "Delete")}`);
                      } else {
                        return [
                          createTextVNode(toDisplayString(itemIndex.value == 0 ? "Create" : itemIndex.value == 1 ? "Edit" : "Delete"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$8, {
                    onClick: close,
                    class: "ml-2"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Cancel `);
                      } else {
                        return [
                          createTextVNode(" Cancel ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(itemIndex.value == 0 ? "Create" : itemIndex.value == 1 ? "Edit" : "Delete"), 1),
                      itemIndex.value != 2 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-6 grid grid-cols-1 gap-4"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "code",
                            value: "Code"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "code",
                            ref: "codeInput",
                            modelValue: unref(form).code,
                            "onUpdate:modelValue": ($event) => unref(form).code = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Code"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.code,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "gelombang",
                            value: "Gelombang"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "gelombang",
                            ref: "gelombangInput",
                            modelValue: unref(form).gelombang,
                            "onUpdate:modelValue": ($event) => unref(form).gelombang = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Gelombang"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.gelombang,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "tahun_akademik",
                            value: "Tahun Akademik"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "tahun_akademik",
                            ref: "tahun_akademikInput",
                            modelValue: unref(form).tahun_akademik,
                            "onUpdate:modelValue": ($event) => unref(form).tahun_akademik = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Tahun Akademik"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.tahun_akademik,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "awal_daftar",
                            value: "Awal Daftar"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "awal_daftar",
                            ref: "awal_daftarInput",
                            modelValue: unref(form).awal_daftar,
                            "onUpdate:modelValue": ($event) => unref(form).awal_daftar = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Awal Daftar"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.awal_daftar,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "akhir_daftar",
                            value: "Akhir Daftar"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "akhir_daftar",
                            modelValue: unref(form).akhir_daftar,
                            "onUpdate:modelValue": ($event) => unref(form).akhir_daftar = $event,
                            class: "mt -1 block w-full"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.akhir_daftar,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "active",
                            value: "Active"
                          }),
                          createVNode(_sfc_main$7, {
                            id: "active",
                            modelValue: unref(form).active,
                            "onUpdate:modelValue": ($event) => unref(form).active = $event,
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: "true", text: "Yes" },
                              { value: "false", text: "No" },
                              { value: "null", text: "Select" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.active,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ])) : (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Are you sure you want to delete this wave? ")
                      ])),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode(PrimaryButton, {
                          onClick: ($event) => save()
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(itemIndex.value == 0 ? "Create" : itemIndex.value == 1 ? "Edit" : "Delete"), 1)
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_sfc_main$8, {
                          onClick: close,
                          class: "ml-2"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Cancel ")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "max-w-7xl mx-auto" }, [
                  createVNode("div", { class: "shadow-md sm:shadow-lg p-4 sm:p-8 bg-white" }, [
                    createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between pb-4" }, [
                      createVNode("header", null, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Gelombang ")
                      ]),
                      createVNode(PrimaryButton, {
                        onClick: ($event) => openDialog(0)
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Create")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ]),
                    createVNode("div", { class: "relative overflow-x-auto" }, [
                      createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, "Code"),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Gelombang "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Tahun Akademik "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Awal Pendaftaran "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Akhir Pendaftaran "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Is_Active "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3"
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.wave, (item) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: item.id
                            }, [
                              createVNode("th", {
                                scope: "row",
                                class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                              }, toDisplayString(item.code), 1),
                              createVNode("td", { class: "px-6 py-4 truncate" }, toDisplayString(item.gelombang), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(item.tahun_akademik), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(item.awal_daftar), 1),
                              createVNode("td", { class: "px-6 py-4" }, toDisplayString(item.akhir_daftar), 1),
                              createVNode("td", { class: "px-6 py-4" }, [
                                item.active ? (openBlock(), createBlock("i", {
                                  key: 0,
                                  class: "fas fa-check text-green-500"
                                })) : (openBlock(), createBlock("i", {
                                  key: 1,
                                  class: "fas fa-times text-red-500"
                                }))
                              ]),
                              createVNode("td", { class: "px-6 py-4 flex gap-2" }, [
                                createVNode("button", {
                                  onClick: ($event) => openDialog(1, item),
                                  class: "text-indigo-600 hover:text-indigo-900"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-pencil" })
                                ], 8, ["onClick"]),
                                createVNode("button", {
                                  onClick: ($event) => openDialog(2, item),
                                  class: "text-red-600 hover:text-red-900"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-trash" })
                                ], 8, ["onClick"])
                              ])
                            ]);
                          }), 128))
                        ])
                      ])
                    ])
                  ])
                ]),
                createVNode(_sfc_main$2, {
                  show: dialog.value,
                  onClose: ($event) => close()
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(itemIndex.value == 0 ? "Create" : itemIndex.value == 1 ? "Edit" : "Delete"), 1),
                      itemIndex.value != 2 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mt-6 grid grid-cols-1 gap-4"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "code",
                            value: "Code"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "code",
                            ref: "codeInput",
                            modelValue: unref(form).code,
                            "onUpdate:modelValue": ($event) => unref(form).code = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Code"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.code,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "gelombang",
                            value: "Gelombang"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "gelombang",
                            ref: "gelombangInput",
                            modelValue: unref(form).gelombang,
                            "onUpdate:modelValue": ($event) => unref(form).gelombang = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Gelombang"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.gelombang,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "tahun_akademik",
                            value: "Tahun Akademik"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "tahun_akademik",
                            ref: "tahun_akademikInput",
                            modelValue: unref(form).tahun_akademik,
                            "onUpdate:modelValue": ($event) => unref(form).tahun_akademik = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            placeholder: "Tahun Akademik"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.tahun_akademik,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "awal_daftar",
                            value: "Awal Daftar"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "awal_daftar",
                            ref: "awal_daftarInput",
                            modelValue: unref(form).awal_daftar,
                            "onUpdate:modelValue": ($event) => unref(form).awal_daftar = $event,
                            class: "mt-1 block w-full",
                            placeholder: "Awal Daftar"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.awal_daftar,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "akhir_daftar",
                            value: "Akhir Daftar"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "akhir_daftar",
                            modelValue: unref(form).akhir_daftar,
                            "onUpdate:modelValue": ($event) => unref(form).akhir_daftar = $event,
                            class: "mt -1 block w-full"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.akhir_daftar,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$3, {
                            for: "active",
                            value: "Active"
                          }),
                          createVNode(_sfc_main$7, {
                            id: "active",
                            modelValue: unref(form).active,
                            "onUpdate:modelValue": ($event) => unref(form).active = $event,
                            class: "mt-1 block w-full",
                            "option-value": [
                              { value: "true", text: "Yes" },
                              { value: "false", text: "No" },
                              { value: "null", text: "Select" }
                            ]
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$5, {
                            message: unref(form).errors.active,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ])) : (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Are you sure you want to delete this wave? ")
                      ])),
                      createVNode("div", { class: "mt-6" }, [
                        createVNode(PrimaryButton, {
                          onClick: ($event) => save()
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(itemIndex.value == 0 ? "Create" : itemIndex.value == 1 ? "Edit" : "Delete"), 1)
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_sfc_main$8, {
                          onClick: close,
                          class: "ml-2"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Cancel ")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["show", "onClose"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Wave.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
