import { unref, withCtx, openBlock, createBlock, createVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-fbd10370.js";
import "./Modal-14fa9cf8.js";
import { usePage, useForm, Head } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-373a10a0.js";
import "./SecondaryButton-33aab301.js";
import { _ as _sfc_main$3 } from "./TextInput-f08fe8c3.js";
import { _ as _sfc_main$2 } from "./InputLabel-5e383564.js";
import { _ as _sfc_main$4 } from "./InputError-83b094c2.js";
import "./DateInput-00587317.js";
import "./Combobox-8f85dcc2.js";
import { _ as _sfc_main$5 } from "./TextareaInput-ea5736c3.js";
import "./FileInput-6748ff0d.js";
import "./ApplicationLogo-9c97dc09.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
import "./ResponsiveNavLink-f6fd3af7.js";
import "uuid";
import "axios";
const _sfc_main = {
  __name: "WebSetting",
  __ssrInlineRender: true,
  props: {
    webSettings: {
      type: Object,
      default: () => ({
        name: "",
        title_home: "",
        institution_short_name: "",
        institution_synopsis: "",
        institution_vision_mission: "",
        institution_history: "",
        title_dashboard: "",
        title_exam: "",
        footer: "",
        contact_telp: "",
        contact_email: "",
        contact_fax: "",
        contact_address: "",
        contact_maps: "",
        contact_facebook: "",
        contact_whatsapp: "",
        payment_bank: "",
        payment_account: "",
        payment_name: "",
        contact_instagram: "",
        contact_twitter: "",
        contact_youtube: "",
        link_univ: ""
      })
    }
  },
  setup(__props) {
    const websetting = usePage().props.webSettings;
    const form = useForm({
      name: websetting.name || "",
      title_home: websetting.title_home || "",
      institution_short_name: websetting.institution_short_name || "",
      institution_synopsis: websetting.institution_synopsis || "",
      institution_vision_mission: websetting.institution_vision_mission || "",
      institution_history: websetting.institution_history || "",
      title_dashboard: websetting.title_dashboard || "",
      title_exam: websetting.title_exam || "",
      footer: websetting.footer || "",
      payment_bank: websetting.payment_bank || "",
      payment_account: websetting.payment_account || "",
      payment_name: websetting.payment_name || "",
      contact_telp: websetting.contact_telp || "",
      contact_email: websetting.contact_email || "",
      contact_fax: websetting.contact_fax || "",
      contact_address: websetting.contact_address || "",
      contact_maps: websetting.contact_maps || "",
      contact_facebook: websetting.contact_facebook || "",
      contact_whatsapp: websetting.contact_whatsapp || "",
      contact_instagram: websetting.contact_instagram || "",
      contact_twitter: websetting.contact_twitter || "",
      contact_youtube: websetting.contact_youtube || "",
      link_univ: websetting.link_univ || "",
      path_brosur: websetting.path_brosur || "",
      path_rincian_biaya: websetting.path_rincian_biaya || ""
    });
    const formbackup = useForm({});
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Web Setting" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="pt-8 flex flex-col gap-4"${_scopeId}><div class="mx-auto w-full"${_scopeId}><div class="shadow-md sm:shadow-lg p-4 sm:p-8 bg-white"${_scopeId}><div class="flex flex-col"${_scopeId}><header${_scopeId}><h2 class="text-2xl font-semibold text-gray-900 dark:text-gray-100"${_scopeId}> Setting Site </h2></header><form${_scopeId}><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "name",
              value: "Nama Website"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "name",
              class: "mt-1 block w-full",
              modelValue: unref(form).name,
              "onUpdate:modelValue": ($event) => unref(form).name = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.name
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "institution_short_name",
              value: "Singkatan Nama Kampus"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "institution_short_name",
              class: "mt-1 block w-full",
              modelValue: unref(form).institution_short_name,
              "onUpdate:modelValue": ($event) => unref(form).institution_short_name = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.institution_short_name
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "title_home",
              value: "Judul Halaman Depan"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "title_home",
              class: "mt-1 block w-full",
              modelValue: unref(form).title_home,
              "onUpdate:modelValue": ($event) => unref(form).title_home = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.title_home
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "title_dashboard",
              value: "Judul Halaman Dashboard"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "title_dashboard",
              class: "mt-1 block w-full",
              modelValue: unref(form).title_dashboard,
              "onUpdate:modelValue": ($event) => unref(form).title_dashboard = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.title_dashboard
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "title_exam",
              value: "Judul Halaman Ujian"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "title_exam",
              class: "mt-1 block w-full",
              modelValue: unref(form).title_exam,
              "onUpdate:modelValue": ($event) => unref(form).title_exam = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.title_exam
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "contact_telp",
              value: "Kontak Telepon"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "contact_telp",
              class: "mt-1 block w-full",
              modelValue: unref(form).contact_telp,
              "onUpdate:modelValue": ($event) => unref(form).contact_telp = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.contact_telp
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "contact_email",
              value: "Kontak Email"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "contact_email",
              class: "mt-1 block w-full",
              modelValue: unref(form).contact_email,
              "onUpdate:modelValue": ($event) => unref(form).contact_email = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.contact_email
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "contact_fax",
              value: "Kontak Fax"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "contact_fax",
              class: "mt-1 block w-full",
              modelValue: unref(form).contact_fax,
              "onUpdate:modelValue": ($event) => unref(form).contact_fax = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.contact_fax
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "contact_address",
              value: "Kontak Alamat"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "contact_address",
              class: "mt-1 block w-full",
              modelValue: unref(form).contact_address,
              "onUpdate:modelValue": ($event) => unref(form).contact_address = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.contact_address
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "footer",
              value: "Footer"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "footer",
              class: "mt-1 block w-full",
              modelValue: unref(form).footer,
              "onUpdate:modelValue": ($event) => unref(form).footer = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.footer
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "institution_synopsis",
              value: "Sinopsis"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "institution_synopsis",
              class: "mt-1 block w-full",
              modelValue: unref(form).institution_synopsis,
              "onUpdate:modelValue": ($event) => unref(form).institution_synopsis = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.institution_synopsis
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "institution_vision_mission",
              value: "Visi & Misi"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "institution_vision_mission",
              class: "mt-1 block w-full",
              modelValue: unref(form).institution_vision_mission,
              "onUpdate:modelValue": ($event) => unref(form).institution_vision_mission = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.institution_vision_mission
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "contact_facebook",
              value: "Kontak Facebook"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "contact_facebook",
              class: "mt-1 block w-full",
              modelValue: unref(form).contact_facebook,
              "onUpdate:modelValue": ($event) => unref(form).contact_facebook = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.contact_facebook
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "contact_whatsapp",
              value: "Kontak Whatsapp"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "contact_whatsapp",
              class: "mt-1 block w-full",
              modelValue: unref(form).contact_whatsapp,
              "onUpdate:modelValue": ($event) => unref(form).contact_whatsapp = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.contact_whatsapp
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "contact_instagram",
              value: "Kontak Instagram"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "contact_instagram",
              class: "mt-1 block w-full",
              modelValue: unref(form).contact_instagram,
              "onUpdate:modelValue": ($event) => unref(form).contact_instagram = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.contact_instagram
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "contact_twitter",
              value: "Kontak Twitter"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "contact_twitter",
              class: "mt-1 block w-full",
              modelValue: unref(form).contact_twitter,
              "onUpdate:modelValue": ($event) => unref(form).contact_twitter = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.contact_twitter
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "contact_youtube",
              value: "Kontak Youtube"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "contact_youtube",
              class: "mt-1 block w-full",
              modelValue: unref(form).contact_youtube,
              "onUpdate:modelValue": ($event) => unref(form).contact_youtube = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.contact_youtube
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "link_univ",
              value: "Link Universitas"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "link_univ",
              class: "mt-1 block w-full",
              modelValue: unref(form).link_univ,
              "onUpdate:modelValue": ($event) => unref(form).link_univ = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.link_univ
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "payment_bank",
              value: "BANK"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "payment_bank",
              class: "mt-1 block w-full",
              modelValue: unref(form).payment_bank,
              "onUpdate:modelValue": ($event) => unref(form).payment_bank = $event,
              placholder: "Bank BNI"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.payment_bank
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "payment_account",
              value: "Nomer Rekening"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "payment_account",
              class: "mt-1 block w-full",
              modelValue: unref(form).payment_account,
              "onUpdate:modelValue": ($event) => unref(form).payment_account = $event,
              placeholder: "Cth: 00323-01-30-000028-7"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.payment_account
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "payment_name",
              value: "Nama Pemilik Akun Bank"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "payment_name",
              class: "mt-1 block w-full",
              modelValue: unref(form).payment_name,
              "onUpdate:modelValue": ($event) => unref(form).payment_name = $event,
              placeholder: "Nama Lengkap Pemiliki Bank"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.payment_name
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex justify-end gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(PrimaryButton, {
              type: "submit",
              class: "mt-4",
              disabled: unref(form).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (unref(form).processing) {
                    _push3(`<span${_scopeId2}> Processing </span>`);
                  } else {
                    _push3(`<span${_scopeId2}>Simpan</span>`);
                  }
                } else {
                  return [
                    unref(form).processing ? (openBlock(), createBlock("span", { key: 0 }, " Processing ")) : (openBlock(), createBlock("span", { key: 1 }, "Simpan"))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form></div></div></div><div class="w-1/2 mx-auto"${_scopeId}><div class="shadow-md sm:shadow-lg p-4 sm:p-8 bg-white"${_scopeId}><div class="flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between"${_scopeId}><header${_scopeId}><h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100"${_scopeId}> Backup Project </h2></header></div><form class="mt-6 space-y-6"${_scopeId}><div class="flex justify-start"${_scopeId}>`);
            _push2(ssrRenderComponent(PrimaryButton, {
              type: "submit",
              class: "mt-4",
              disabled: unref(formbackup).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (unref(formbackup).processing) {
                    _push3(`<span${_scopeId2}> Processing </span>`);
                  } else {
                    _push3(`<span${_scopeId2}>backup sekarang</span>`);
                  }
                } else {
                  return [
                    unref(formbackup).processing ? (openBlock(), createBlock("span", { key: 0 }, " Processing ")) : (openBlock(), createBlock("span", { key: 1 }, "backup sekarang"))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form></div></div></div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "pt-8 flex flex-col gap-4" }, [
                  createVNode("div", { class: "mx-auto w-full" }, [
                    createVNode("div", { class: "shadow-md sm:shadow-lg p-4 sm:p-8 bg-white" }, [
                      createVNode("div", { class: "flex flex-col" }, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "text-2xl font-semibold text-gray-900 dark:text-gray-100" }, " Setting Site ")
                        ]),
                        createVNode("form", {
                          onSubmit: withModifiers(($event) => unref(form).patch(
                            _ctx.route("admin.web-setting.update")
                          ), ["prevent"])
                        }, [
                          createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "name",
                                value: "Nama Website"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "name",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).name,
                                "onUpdate:modelValue": ($event) => unref(form).name = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.name
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "institution_short_name",
                                value: "Singkatan Nama Kampus"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "institution_short_name",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).institution_short_name,
                                "onUpdate:modelValue": ($event) => unref(form).institution_short_name = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.institution_short_name
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "title_home",
                                value: "Judul Halaman Depan"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "title_home",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).title_home,
                                "onUpdate:modelValue": ($event) => unref(form).title_home = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.title_home
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "title_dashboard",
                                value: "Judul Halaman Dashboard"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "title_dashboard",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).title_dashboard,
                                "onUpdate:modelValue": ($event) => unref(form).title_dashboard = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.title_dashboard
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "title_exam",
                                value: "Judul Halaman Ujian"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "title_exam",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).title_exam,
                                "onUpdate:modelValue": ($event) => unref(form).title_exam = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.title_exam
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "contact_telp",
                                value: "Kontak Telepon"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "contact_telp",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).contact_telp,
                                "onUpdate:modelValue": ($event) => unref(form).contact_telp = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.contact_telp
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "contact_email",
                                value: "Kontak Email"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "contact_email",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).contact_email,
                                "onUpdate:modelValue": ($event) => unref(form).contact_email = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.contact_email
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "contact_fax",
                                value: "Kontak Fax"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "contact_fax",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).contact_fax,
                                "onUpdate:modelValue": ($event) => unref(form).contact_fax = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.contact_fax
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "contact_address",
                                value: "Kontak Alamat"
                              }),
                              createVNode(_sfc_main$5, {
                                id: "contact_address",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).contact_address,
                                "onUpdate:modelValue": ($event) => unref(form).contact_address = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.contact_address
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "footer",
                                value: "Footer"
                              }),
                              createVNode(_sfc_main$5, {
                                id: "footer",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).footer,
                                "onUpdate:modelValue": ($event) => unref(form).footer = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.footer
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "institution_synopsis",
                                value: "Sinopsis"
                              }),
                              createVNode(_sfc_main$5, {
                                id: "institution_synopsis",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).institution_synopsis,
                                "onUpdate:modelValue": ($event) => unref(form).institution_synopsis = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.institution_synopsis
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "institution_vision_mission",
                                value: "Visi & Misi"
                              }),
                              createVNode(_sfc_main$5, {
                                id: "institution_vision_mission",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).institution_vision_mission,
                                "onUpdate:modelValue": ($event) => unref(form).institution_vision_mission = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.institution_vision_mission
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "contact_facebook",
                                value: "Kontak Facebook"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "contact_facebook",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).contact_facebook,
                                "onUpdate:modelValue": ($event) => unref(form).contact_facebook = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.contact_facebook
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "contact_whatsapp",
                                value: "Kontak Whatsapp"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "contact_whatsapp",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).contact_whatsapp,
                                "onUpdate:modelValue": ($event) => unref(form).contact_whatsapp = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.contact_whatsapp
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "contact_instagram",
                                value: "Kontak Instagram"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "contact_instagram",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).contact_instagram,
                                "onUpdate:modelValue": ($event) => unref(form).contact_instagram = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.contact_instagram
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "contact_twitter",
                                value: "Kontak Twitter"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "contact_twitter",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).contact_twitter,
                                "onUpdate:modelValue": ($event) => unref(form).contact_twitter = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.contact_twitter
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "contact_youtube",
                                value: "Kontak Youtube"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "contact_youtube",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).contact_youtube,
                                "onUpdate:modelValue": ($event) => unref(form).contact_youtube = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.contact_youtube
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "link_univ",
                                value: "Link Universitas"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "link_univ",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).link_univ,
                                "onUpdate:modelValue": ($event) => unref(form).link_univ = $event
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.link_univ
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "payment_bank",
                                value: "BANK"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "payment_bank",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).payment_bank,
                                "onUpdate:modelValue": ($event) => unref(form).payment_bank = $event,
                                placholder: "Bank BNI"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.payment_bank
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "payment_account",
                                value: "Nomer Rekening"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "payment_account",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).payment_account,
                                "onUpdate:modelValue": ($event) => unref(form).payment_account = $event,
                                placeholder: "Cth: 00323-01-30-000028-7"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.payment_account
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "col-span-1" }, [
                              createVNode(_sfc_main$2, {
                                for: "payment_name",
                                value: "Nama Pemilik Akun Bank"
                              }),
                              createVNode(_sfc_main$3, {
                                id: "payment_name",
                                class: "mt-1 block w-full",
                                modelValue: unref(form).payment_name,
                                "onUpdate:modelValue": ($event) => unref(form).payment_name = $event,
                                placeholder: "Nama Lengkap Pemiliki Bank"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_sfc_main$4, {
                                class: "mt-2",
                                message: unref(form).errors.payment_name
                              }, null, 8, ["message"])
                            ])
                          ]),
                          createVNode("div", { class: "flex justify-end gap-4" }, [
                            createVNode(PrimaryButton, {
                              type: "submit",
                              class: "mt-4",
                              disabled: unref(form).processing
                            }, {
                              default: withCtx(() => [
                                unref(form).processing ? (openBlock(), createBlock("span", { key: 0 }, " Processing ")) : (openBlock(), createBlock("span", { key: 1 }, "Simpan"))
                              ]),
                              _: 1
                            }, 8, ["disabled"])
                          ])
                        ], 40, ["onSubmit"])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "w-1/2 mx-auto" }, [
                    createVNode("div", { class: "shadow-md sm:shadow-lg p-4 sm:p-8 bg-white" }, [
                      createVNode("div", { class: "flex flex-column sm:flex-row flex-wrap space-y-4 sm:space-y-0 items-center justify-between" }, [
                        createVNode("header", null, [
                          createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100" }, " Backup Project ")
                        ])
                      ]),
                      createVNode("form", {
                        onSubmit: withModifiers(($event) => unref(formbackup).patch(
                          _ctx.route("admin.web-setting.backup")
                        ), ["prevent"]),
                        class: "mt-6 space-y-6"
                      }, [
                        createVNode("div", { class: "flex justify-start" }, [
                          createVNode(PrimaryButton, {
                            type: "submit",
                            class: "mt-4",
                            disabled: unref(formbackup).processing
                          }, {
                            default: withCtx(() => [
                              unref(formbackup).processing ? (openBlock(), createBlock("span", { key: 0 }, " Processing ")) : (openBlock(), createBlock("span", { key: 1 }, "backup sekarang"))
                            ]),
                            _: 1
                          }, 8, ["disabled"])
                        ])
                      ], 40, ["onSubmit"])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/WebSetting.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
