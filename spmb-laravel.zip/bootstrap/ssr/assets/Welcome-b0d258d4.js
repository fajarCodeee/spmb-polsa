import { mergeProps, unref, useSSRContext, ref, onMounted, nextTick, onBeforeUnmount, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrInterpolate, ssrRenderSlot, ssrRenderAttr, ssrRenderList } from "vue/server-renderer";
import { Link, Head } from "@inertiajs/vue3";
import { A as ApplicationLogo } from "./ApplicationLogo-9c97dc09.js";
import { b as _sfc_main$3 } from "./ResponsiveNavLink-f6fd3af7.js";
import { DotLottieVue } from "@lottiefiles/dotlottie-vue";
import "vue3-carousel";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main$2 = {
  __name: "Loading",
  __ssrInlineRender: true,
  props: {
    loading: {
      type: Boolean,
      default: true
    },
    remove: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      if (!__props.remove) {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: ["fixed top-0 z-50 h-screen w-screen flex justify-center items-center bg-white opacity-100 transition-opacity duration-1000 ease-in-out cursor-progress", { "opacity-5": !__props.loading }]
        }, _attrs))}>`);
        _push(ssrRenderComponent(unref(DotLottieVue), {
          style: { "height": "250px", "width": "250px" },
          autoplay: "",
          loop: "",
          src: "/assets/lottie/loading.lottie"
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Loading.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "HomeLayout",
  __ssrInlineRender: true,
  props: {
    canLogin: {
      type: Boolean
    }
  },
  setup(__props) {
    const loading = ref(true);
    const remove = ref(false);
    const scrollY = ref(0);
    const handleHeader = () => {
      scrollY.value = window.scrollY || 0;
    };
    onMounted(() => {
      window.addEventListener("scroll", handleHeader);
      nextTick(() => {
        setTimeout(() => {
          loading.value = false;
        }, 3500);
        setTimeout(() => {
          remove.value = true;
        }, 4200);
      });
    });
    onBeforeUnmount(() => {
      window.removeEventListener("scroll", handleHeader);
    });
    const showingNavigationDropdown = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_sfc_main$2, {
        loading: loading.value,
        remove: remove.value
      }, null, _parent));
      _push(`<div class="flex flex-col min-h-screen bg-gray-100"><nav class="${ssrRenderClass([{
        "bg-opacity-90 border-b drop-shadow-md top-0 h-20": scrollY.value >= 270,
        "h-24": scrollY.value <= 270
      }, "fixed w-full z-20 top-0 start-0 bg-gray-100 transition-all duration-500"])}"><div class="mx-auto px-4 sm:px-6 lg:px-8 h-full flex justify-between"><div class="flex flex-row"><div class="flex-shrink-0 flex items-center gap-3">`);
      _push(ssrRenderComponent(unref(Link), { href: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(ApplicationLogo, { class: "block h-9 w-auto" }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(ApplicationLogo, { class: "block h-9 w-auto" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<h1 class="text-md w-1/2 md:w-full md:text-2xl inline-flex items-center font-black text-gray-900 px-3 leading-relaxed">${ssrInterpolate(_ctx.$page.props.web_settings.title_home)}</h1></div></div><div class="hidden sm:flex sm:items-center sm:ms-6"><div class="flex justify-center gap-2">`);
      if (!_ctx.$page.props.auth.user) {
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("login"),
          class: "inline-flex items-center text-gray-900 hover:text-blue-500 font-bold capitalize"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Masuk `);
            } else {
              return [
                createTextVNode(" Masuk ")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      if (!_ctx.$page.props.auth.user) {
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("register"),
          class: "inline-flex items-center p-2 text-left border-transparent text-xs uppercase text-white font-bold bg-blue-500 rounded-lg dark:text-gray-800 tracking-widest hover:bg-blue-700 dark:hover:bg-blue-500 focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition duration-150 ease-in-out shadow-md"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` daftar`);
            } else {
              return [
                createTextVNode(" daftar")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      if (_ctx.$page.props.auth.user) {
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("dashboard"),
          class: "inline-flex items-center p-2 text-left border-transparent text-xs uppercase text-white font-bold bg-blue-500 rounded-lg dark:text-gray-800 tracking-widest hover:bg-blue-700 dark:hover:bg-blue-500 focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition duration-150 ease-in-out shadow-md"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Dashboard`);
            } else {
              return [
                createTextVNode(" Dashboard")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="-me-2 flex items-center sm:hidden"><button class="inline-flex items-center justify-center p-2 rounded-md text-black dark:text-gray-500 hover:text-gray-500 dark:hover:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none focus:bg-gray-100 dark:focus:bg-gray-900 focus:text-gray-500 dark:focus:text-gray-400 transition duration-150 ease-in-out"><svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24"><path class="${ssrRenderClass({
        hidden: showingNavigationDropdown.value,
        "inline-flex": !showingNavigationDropdown.value
      })}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path><path class="${ssrRenderClass({
        hidden: !showingNavigationDropdown.value,
        "inline-flex": showingNavigationDropdown.value
      })}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button></div></div><div class="${ssrRenderClass([{
        block: showingNavigationDropdown.value,
        hidden: !showingNavigationDropdown.value,
        "bg-opacity-90": scrollY.value >= 270 && showingNavigationDropdown.value
      }, "sm:hidden bg-gray-100 border-b border-gray-200 shadow-md"])}">`);
      if (_ctx.$page.props.auth.user) {
        _push(`<div class="pt-2 pb-3 space-y-1 px-4">`);
        _push(ssrRenderComponent(_sfc_main$3, {
          href: _ctx.route("dashboard")
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Dashboard `);
            } else {
              return [
                createTextVNode("Dashboard ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<div class="pt-2 pb-3 space-y-1 px-4">`);
        _push(ssrRenderComponent(_sfc_main$3, {
          href: _ctx.route("login")
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fa-solid fa-user-graduate pr-2"${_scopeId}></i> Masuk `);
            } else {
              return [
                createVNode("i", { class: "fa-solid fa-user-graduate pr-2" }),
                createTextVNode(" Masuk ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_sfc_main$3, {
          href: _ctx.route("register")
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fa-solid fa-right-to-bracket pr-2"${_scopeId}></i> Daftar `);
            } else {
              return [
                createVNode("i", { class: "fa-solid fa-right-to-bracket pr-2" }),
                createTextVNode(" Daftar ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      }
      _push(`</div></nav><main class="flex-grow w-full bg-gray-100 pt-10 md:pt-0">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</main><footer data-aos="fade-up" data-aos-duration="2000" class="py-10 px-6 md:px-16 lg:px-12 xl:px-16 bg-gray-100"><div class="mx-auto max-w-full"><div class="grid grid-cols-1 md:grid-cols-8 gap-4 text-sm"><div class="flex flex-col gap-3 col-span-1 md:col-span-3"><div class="flex gap-2 items-center">`);
      _push(ssrRenderComponent(ApplicationLogo, { class: "block h-9 w-auto" }, null, _parent));
      _push(`<h3 class="font-bold text-lg">${ssrInterpolate(_ctx.$page.props.web_settings.title_home)}</h3></div><ul class="list-none list-outside"><li><i class="fa-solid fa-location-dot pr-2"></i> ${ssrInterpolate(_ctx.$page.props.web_settings.contact_address)}</li><li><i class="fa-solid fa-envelope pr-2"></i> ${ssrInterpolate(_ctx.$page.props.web_settings.contact_email)}</li><li><i class="fa-solid fa-phone pr-2"></i>+ 0761 33815 </li><li><i class="fa-solid fa-print pr-2"></i>+ 0761 33815 </li></ul></div></div><hr class="border-t-2 border-gray-300 my-4 mt-10"><div class="flex flex-col md:flex-row justify-between items-center gap-4 text-gray-500 text-center md:text-left"><p class="text-sm tracking-wide"><span>${_ctx.$page.props.web_settings.footer}</span></p><div class="flex gap-3">`);
      if (_ctx.$page.props.web_settings.contact_facebook) {
        _push(`<a${ssrRenderAttr(
          "href",
          _ctx.$page.props.web_settings.contact_facebook
        )} target="_blank" class="text-gray-500 hover:text-blue-500"><i class="fa-brands fa-facebook-f"></i></a>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.$page.props.web_settings.contact_instagram) {
        _push(`<a${ssrRenderAttr(
          "href",
          _ctx.$page.props.web_settings.contact_instagram
        )} target="_blank" class="text-gray-500 hover:text-red-500"><i class="fa-brands fa-instagram"></i></a>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.$page.props.web_settings.contact_youtube) {
        _push(`<a${ssrRenderAttr("href", _ctx.$page.props.web_settings.contact_youtube)} target="_blank" class="text-gray-500 hover:text-red-500"><i class="fa-brands fa-youtube"></i></a>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.$page.props.web_settings.contact_twitter) {
        _push(`<a${ssrRenderAttr("href", _ctx.$page.props.web_settings.contact_twitter)} target="_blank" class="text-gray-500 hover:text-gray-500"><i class="fa-brands fa-twitter"></i></a>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></footer></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/HomeLayout.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const carousel = "";
const _sfc_main = {
  __name: "Welcome",
  __ssrInlineRender: true,
  props: {
    canLogin: {
      type: Boolean
    },
    canRegister: {
      type: Boolean
    },
    brosur: String,
    rincian_biaya: String
  },
  setup(__props) {
    const primacy = [
      {
        title: "Kampus Nyaman",
        description: "Kampus yang nyaman dan asri"
      },
      {
        title: "Fasilitas Lengkap",
        description: "Fasilitas yang lengkap dan modern"
      },
      {
        title: "Kampus Merdeka",
        description: "Mendukung kemandirian mahasiswa"
      },
      {
        title: "Tenaga Pengajar",
        description: "Tenaga pengajar yang mumpuni"
      },
      {
        title: "Lokasi Strategis",
        description: "Lokasi kampus yang strategis berada di pusat kota"
      },
      {
        title: "Kurikulum Terkini",
        description: "Kurikulum yang terkini dan relevan dengan kebutuhan industri"
      },
      {
        title: "Beasiswa",
        description: "Beasiswa yang dapat diakses oleh mahasiswa"
      },
      {
        title: "Kegiatan Mahasiswa",
        description: "Kegiatan mahasiswa yang beragam"
      },
      {
        title: "Kemahasiswaan",
        description: "Kemahasiswaan yang aktif dan berprestasi"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<title${_scopeId}>
            Penerimaan Mahasiswa Baru
            ${ssrInterpolate(_ctx.$page.props.web_settings.institution_name)}
        </title><meta head-key="description" name="description" content="Penerimaan Mahasiswa Baru {{ $page.props.web_settings.institution_name }}"${_scopeId}><link rel="icon" type="image/x-icon" href="/assets/img/logo-polsa.png"${_scopeId}>`);
          } else {
            return [
              createVNode("title", null, "\n            Penerimaan Mahasiswa Baru\n            " + toDisplayString(_ctx.$page.props.web_settings.institution_name) + "\n        ", 1),
              createVNode("meta", {
                "head-key": "description",
                name: "description",
                content: "Penerimaan Mahasiswa Baru {{ $page.props.web_settings.institution_name }}"
              }),
              createVNode("link", {
                rel: "icon",
                type: "image/x-icon",
                href: "/assets/img/logo-polsa.png"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<section class="min-h-screen p-6 md:p-16 lg:p-12 xl:p-16 flex items-center"${_scopeId}><div class="container px-6 lg:px-8 mx-auto"${_scopeId}><div class="grid grid-cols-1 lg:grid-cols-2 items-center gap-3"${_scopeId}><div class="w-full hidden lg:block"${_scopeId}><img class="mx-auto" src="/images/500x500.png" alt="Cover Pmb Hang Tuah
                        Pekanbaru"${_scopeId}></div><div class="w-full text-gray-900 text-center md:text-left"${_scopeId}><h2 class="text-2xl md:text-5xl font-extrabold pb-3"${_scopeId}> Penerimaan Mahasiwa Baru </h2><div class="pb-3"${_scopeId}><span class="bg-gradient-to-r from-primary-700 to-primary bg-clip-text font-[800]"${_scopeId}>${ssrInterpolate(_ctx.$page.props.web_settings.institution_name)}</span><p class="leading-relaxed"${_scopeId}>${ssrInterpolate(_ctx.$page.props.web_settings.institution_synopsis)}</p><div class="flex gap-3 pt-4 items-center justify-center md:justify-start"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("register"),
              class: "inline-flex items-center py-2.5 px-5 bg-yellow-600 dark:bg-yellow-200 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:text-gray-900 focus:text-gray-900 active:text-gray-900 hover:bg-gray-100 hover:ring-2 hover:ring-gray-500 focus:bg-gray-100 active:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<i class="fa-solid fa-user-graduate pr-2"${_scopeId2}></i> Daftar sekarang `);
                } else {
                  return [
                    createVNode("i", { class: "fa-solid fa-user-graduate pr-2" }),
                    createTextVNode(" Daftar sekarang ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div></div></div></section><section class="py-6 md:p-16 lg:p-12 xl:p-16 bg-yellow-500"${_scopeId}><div class="container mx-auto" data-aos="fade-up" data-aos-duration="2000"${_scopeId}><h2 class="text-2xl md:text-3xl text-white text-center font-bold pb-5 mb-10 capitalize"${_scopeId}><span class="relative inline-block"${_scopeId}><span class="relative"${_scopeId}> Keunggulan </span></span> ${ssrInterpolate(_ctx.$page.props.web_settings.institution_short_name)}</h2><div class="owl-carousel owl-theme"${_scopeId}><!--[-->`);
            ssrRenderList(primacy, (x, index) => {
              _push2(`<div class="p-5 bg-white rounded-xl shadow-lg h-32 flex flex-col items-center justify-center"${_scopeId}><header class="font-bold text-lg text-center"${_scopeId}>${ssrInterpolate(x.title)}</header><p class="text-center font-semibold"${_scopeId}>${ssrInterpolate(x.description)}</p></div>`);
            });
            _push2(`<!--]--></div></div></section><section class="p-6 md:p-16 lg:p-12 xl:p-16"${_scopeId}><div class="container mx-auto p-6" data-aos="fade-up" data-aos-duration="2000"${_scopeId}><h2 class="text-2xl md:text-3xl text-black text-center font-bold pb-5 mb-10 capitalize"${_scopeId}> Sekilas Tentang <span class="relative inline-block"${_scopeId}><span class="absolute inline-block w-full h-2 bg-yellow-500 bottom-1.5"${_scopeId}></span><span class="relative"${_scopeId}>${ssrInterpolate(_ctx.$page.props.web_settings.institution_short_name)}</span></span></h2><div class="grid grid-cols-1 md:grid-cols-1 gap-5"${_scopeId}><div${_scopeId}><h3 class="text-xl font-bold pb-3 text-center"${_scopeId}> Visi dan Misi </h3><p class="text-sm md:text-base font-normal indent-8 text-pretty text-center"${_scopeId}>${ssrInterpolate(_ctx.$page.props.web_settings.institution_vision_mission)}</p></div></div></div></section><section class="p-6 md:p-16 lg:p-12 xl:p-16 bg-yellow-500 flex justify-center" data-aos="fade-up" data-aos-duration="2000"${_scopeId}><div class="container mx-auto"${_scopeId}><h2 class="text-2xl md:text-3xl text-white text-center font-bold pb-5 mb-10 capitalize"${_scopeId}> Panduan Singkat Pendaftaran </h2><div class="grid grid-cols-1 md:grid-cols-4 gap-5"${_scopeId}><div class="flex flex-col items-center bg-white rounded-lg p-5 shadow-md"${_scopeId}><h3 class="text-xl font-bold pb-3 text-center"${_scopeId}> Langkah 1 </h3><p class="text-sm md:text-base font-normal text-pretty text-center"${_scopeId}> Login atau daftar akun terlebih dahulu untuk memulai pendaftaran PMB </p></div><div class="flex flex-col items-center bg-white rounded-lg p-5 shadow-md"${_scopeId}><h3 class="text-xl font-bold pb-3 text-center"${_scopeId}> Langkah 2 </h3><p class="text-sm md:text-base font-normal text-pretty text-center"${_scopeId}> Pilih program studi yang diinginkan dan lengkapi dan lakukan pembayaran, kemudian isi formulir pendaftaran </p></div><div class="flex flex-col items-center bg-white rounded-lg p-5 shadow-md"${_scopeId}><h3 class="text-xl font-bold pb-3 text-center"${_scopeId}> Langkah 3 </h3><p class="text-sm md:text-base font-normal text-pretty text-center"${_scopeId}> Cek status pendaftaran dan lakukan verifikasi dokumen </p></div><div class="flex flex-col items-center bg-white rounded-lg p-5 shadow-md"${_scopeId}><h3 class="text-xl font-bold pb-3 text-center"${_scopeId}> Langkah 4 </h3><p class="text-sm md:text-base font-normal text-pretty text-center"${_scopeId}> Lihat hasil seleksi dan lakukan pembayaran pendaftaran </p></div></div></div></section><section class="p-6 md:p-16 lg:p-12 xl:p-16"${_scopeId}><div class="text-white" data-aos="fade-up" data-aos-duration="2000"${_scopeId}><div class="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div class="flex flex-wrap gap-2 justify-between bg-yellow-600 container mx-auto rounded-lg p-6"${_scopeId}><div${_scopeId}><h5 class="text-2xl font-bold text-left pb-3 leading-relaxed"${_scopeId}> Punya pertanyaan seputar PMB <span class="animate-pulse"${_scopeId}>?</span></h5><p class="text-left font-normal"${_scopeId}> Jika anda memiliki sebuah pertanyaan atau kendala silahkan hubungi kami atau dapat membaca panduan pendaftaran </p></div><div class="flex"${_scopeId}><div class="flex flex-row gap-3 items-center sm:flex-row sm:gap-5 sm:justify-end sm:items-center"${_scopeId}><a class="p-2 bg-transparent ring-2 ring-white rounded-lg hover:bg-yellow-700 text-xs sm:text-base"${ssrRenderAttr("href", `https://wa.me/${_ctx.$page.props.web_settings.contact_whatsapp}`)} target="_blank"${_scopeId}><span class="flex items-center justify-center"${_scopeId}><i class="fa-brands fa-whatsapp pr-2"${_scopeId}></i> Whatsapp </span></a>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: "",
              class: "p-2 bg-transparent ring-2 ring-white rounded-lg hover:bg-yellow-700 text-xs sm:text-base"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="flex items-center justify-center"${_scopeId2}><i class="fa-solid fa-book-bookmark pr-2"${_scopeId2}></i> Panduan </span>`);
                } else {
                  return [
                    createVNode("span", { class: "flex items-center justify-center" }, [
                      createVNode("i", { class: "fa-solid fa-book-bookmark pr-2" }),
                      createTextVNode(" Panduan ")
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div><div class="flex flex-wrap gap-2 justify-between bg-yellow-600 container mx-auto rounded-lg p-6"${_scopeId}><div${_scopeId}><h5 class="text-2xl font-bold text-left pb-3 leading-relaxed"${_scopeId}> Brosur dan Rincian Biaya </h5><p class="text-left font-normal"${_scopeId}> Kami menyediakan brosur dan rincian biaya pendaftaran, silahkan unduh brosur dan rincian biaya </p></div><div class="flex"${_scopeId}><div class="flex flex-row gap-3 items-center sm:flex-row sm:gap-5 sm:justify-end sm:items-center"${_scopeId}><a${ssrRenderAttr("href", `${__props.brosur}`)} target="_blank" class="p-2 bg-transparent ring-2 ring-white rounded-lg hover:bg-yellow-700 text-xs sm:text-base"${_scopeId}><span class="flex items-center justify-center"${_scopeId}><i class="fa-solid fa-image pr-2"${_scopeId}></i> Brosur </span></a><a${ssrRenderAttr("href", `${__props.rincian_biaya}`)} target="_blank" class="p-2 bg-transparent ring-2 ring-white rounded-lg hover:bg-yellow-700 text-xs sm:text-base"${_scopeId}><span class="flex items-center justify-center"${_scopeId}><i class="fa-solid fa-money-bill pr-2"${_scopeId}></i> Rincian </span></a></div></div></div></div></div></section>`);
          } else {
            return [
              createVNode("section", { class: "min-h-screen p-6 md:p-16 lg:p-12 xl:p-16 flex items-center" }, [
                createVNode("div", { class: "container px-6 lg:px-8 mx-auto" }, [
                  createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-2 items-center gap-3" }, [
                    createVNode("div", { class: "w-full hidden lg:block" }, [
                      createVNode("img", {
                        class: "mx-auto",
                        src: "/images/500x500.png",
                        alt: "Cover Pmb Hang Tuah\n                        Pekanbaru"
                      })
                    ]),
                    createVNode("div", { class: "w-full text-gray-900 text-center md:text-left" }, [
                      createVNode("h2", { class: "text-2xl md:text-5xl font-extrabold pb-3" }, " Penerimaan Mahasiwa Baru "),
                      createVNode("div", { class: "pb-3" }, [
                        createVNode("span", { class: "bg-gradient-to-r from-primary-700 to-primary bg-clip-text font-[800]" }, toDisplayString(_ctx.$page.props.web_settings.institution_name), 1),
                        createVNode("p", { class: "leading-relaxed" }, toDisplayString(_ctx.$page.props.web_settings.institution_synopsis), 1),
                        createVNode("div", { class: "flex gap-3 pt-4 items-center justify-center md:justify-start" }, [
                          createVNode(unref(Link), {
                            href: _ctx.route("register"),
                            class: "inline-flex items-center py-2.5 px-5 bg-yellow-600 dark:bg-yellow-200 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:text-gray-900 focus:text-gray-900 active:text-gray-900 hover:bg-gray-100 hover:ring-2 hover:ring-gray-500 focus:bg-gray-100 active:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150"
                          }, {
                            default: withCtx(() => [
                              createVNode("i", { class: "fa-solid fa-user-graduate pr-2" }),
                              createTextVNode(" Daftar sekarang ")
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ])
                      ])
                    ])
                  ])
                ])
              ]),
              createVNode("section", { class: "py-6 md:p-16 lg:p-12 xl:p-16 bg-yellow-500" }, [
                createVNode("div", {
                  class: "container mx-auto",
                  "data-aos": "fade-up",
                  "data-aos-duration": "2000"
                }, [
                  createVNode("h2", { class: "text-2xl md:text-3xl text-white text-center font-bold pb-5 mb-10 capitalize" }, [
                    createVNode("span", { class: "relative inline-block" }, [
                      createVNode("span", { class: "relative" }, " Keunggulan ")
                    ]),
                    createTextVNode(" " + toDisplayString(_ctx.$page.props.web_settings.institution_short_name), 1)
                  ]),
                  createVNode("div", { class: "owl-carousel owl-theme" }, [
                    (openBlock(), createBlock(Fragment, null, renderList(primacy, (x, index) => {
                      return createVNode("div", {
                        key: index,
                        class: "p-5 bg-white rounded-xl shadow-lg h-32 flex flex-col items-center justify-center"
                      }, [
                        createVNode("header", { class: "font-bold text-lg text-center" }, toDisplayString(x.title), 1),
                        createVNode("p", { class: "text-center font-semibold" }, toDisplayString(x.description), 1)
                      ]);
                    }), 64))
                  ])
                ])
              ]),
              createVNode("section", { class: "p-6 md:p-16 lg:p-12 xl:p-16" }, [
                createVNode("div", {
                  class: "container mx-auto p-6",
                  "data-aos": "fade-up",
                  "data-aos-duration": "2000"
                }, [
                  createVNode("h2", { class: "text-2xl md:text-3xl text-black text-center font-bold pb-5 mb-10 capitalize" }, [
                    createTextVNode(" Sekilas Tentang "),
                    createVNode("span", { class: "relative inline-block" }, [
                      createVNode("span", { class: "absolute inline-block w-full h-2 bg-yellow-500 bottom-1.5" }),
                      createVNode("span", { class: "relative" }, toDisplayString(_ctx.$page.props.web_settings.institution_short_name), 1)
                    ])
                  ]),
                  createVNode("div", { class: "grid grid-cols-1 md:grid-cols-1 gap-5" }, [
                    createVNode("div", null, [
                      createVNode("h3", { class: "text-xl font-bold pb-3 text-center" }, " Visi dan Misi "),
                      createVNode("p", { class: "text-sm md:text-base font-normal indent-8 text-pretty text-center" }, toDisplayString(_ctx.$page.props.web_settings.institution_vision_mission), 1)
                    ])
                  ])
                ])
              ]),
              createVNode("section", {
                class: "p-6 md:p-16 lg:p-12 xl:p-16 bg-yellow-500 flex justify-center",
                "data-aos": "fade-up",
                "data-aos-duration": "2000"
              }, [
                createVNode("div", { class: "container mx-auto" }, [
                  createVNode("h2", { class: "text-2xl md:text-3xl text-white text-center font-bold pb-5 mb-10 capitalize" }, " Panduan Singkat Pendaftaran "),
                  createVNode("div", { class: "grid grid-cols-1 md:grid-cols-4 gap-5" }, [
                    createVNode("div", { class: "flex flex-col items-center bg-white rounded-lg p-5 shadow-md" }, [
                      createVNode("h3", { class: "text-xl font-bold pb-3 text-center" }, " Langkah 1 "),
                      createVNode("p", { class: "text-sm md:text-base font-normal text-pretty text-center" }, " Login atau daftar akun terlebih dahulu untuk memulai pendaftaran PMB ")
                    ]),
                    createVNode("div", { class: "flex flex-col items-center bg-white rounded-lg p-5 shadow-md" }, [
                      createVNode("h3", { class: "text-xl font-bold pb-3 text-center" }, " Langkah 2 "),
                      createVNode("p", { class: "text-sm md:text-base font-normal text-pretty text-center" }, " Pilih program studi yang diinginkan dan lengkapi dan lakukan pembayaran, kemudian isi formulir pendaftaran ")
                    ]),
                    createVNode("div", { class: "flex flex-col items-center bg-white rounded-lg p-5 shadow-md" }, [
                      createVNode("h3", { class: "text-xl font-bold pb-3 text-center" }, " Langkah 3 "),
                      createVNode("p", { class: "text-sm md:text-base font-normal text-pretty text-center" }, " Cek status pendaftaran dan lakukan verifikasi dokumen ")
                    ]),
                    createVNode("div", { class: "flex flex-col items-center bg-white rounded-lg p-5 shadow-md" }, [
                      createVNode("h3", { class: "text-xl font-bold pb-3 text-center" }, " Langkah 4 "),
                      createVNode("p", { class: "text-sm md:text-base font-normal text-pretty text-center" }, " Lihat hasil seleksi dan lakukan pembayaran pendaftaran ")
                    ])
                  ])
                ])
              ]),
              createVNode("section", { class: "p-6 md:p-16 lg:p-12 xl:p-16" }, [
                createVNode("div", {
                  class: "text-white",
                  "data-aos": "fade-up",
                  "data-aos-duration": "2000"
                }, [
                  createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 gap-4" }, [
                    createVNode("div", { class: "flex flex-wrap gap-2 justify-between bg-yellow-600 container mx-auto rounded-lg p-6" }, [
                      createVNode("div", null, [
                        createVNode("h5", { class: "text-2xl font-bold text-left pb-3 leading-relaxed" }, [
                          createTextVNode(" Punya pertanyaan seputar PMB "),
                          createVNode("span", { class: "animate-pulse" }, "?")
                        ]),
                        createVNode("p", { class: "text-left font-normal" }, " Jika anda memiliki sebuah pertanyaan atau kendala silahkan hubungi kami atau dapat membaca panduan pendaftaran ")
                      ]),
                      createVNode("div", { class: "flex" }, [
                        createVNode("div", { class: "flex flex-row gap-3 items-center sm:flex-row sm:gap-5 sm:justify-end sm:items-center" }, [
                          createVNode("a", {
                            class: "p-2 bg-transparent ring-2 ring-white rounded-lg hover:bg-yellow-700 text-xs sm:text-base",
                            href: `https://wa.me/${_ctx.$page.props.web_settings.contact_whatsapp}`,
                            target: "_blank"
                          }, [
                            createVNode("span", { class: "flex items-center justify-center" }, [
                              createVNode("i", { class: "fa-brands fa-whatsapp pr-2" }),
                              createTextVNode(" Whatsapp ")
                            ])
                          ], 8, ["href"]),
                          createVNode(unref(Link), {
                            href: "",
                            class: "p-2 bg-transparent ring-2 ring-white rounded-lg hover:bg-yellow-700 text-xs sm:text-base"
                          }, {
                            default: withCtx(() => [
                              createVNode("span", { class: "flex items-center justify-center" }, [
                                createVNode("i", { class: "fa-solid fa-book-bookmark pr-2" }),
                                createTextVNode(" Panduan ")
                              ])
                            ]),
                            _: 1
                          })
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "flex flex-wrap gap-2 justify-between bg-yellow-600 container mx-auto rounded-lg p-6" }, [
                      createVNode("div", null, [
                        createVNode("h5", { class: "text-2xl font-bold text-left pb-3 leading-relaxed" }, " Brosur dan Rincian Biaya "),
                        createVNode("p", { class: "text-left font-normal" }, " Kami menyediakan brosur dan rincian biaya pendaftaran, silahkan unduh brosur dan rincian biaya ")
                      ]),
                      createVNode("div", { class: "flex" }, [
                        createVNode("div", { class: "flex flex-row gap-3 items-center sm:flex-row sm:gap-5 sm:justify-end sm:items-center" }, [
                          createVNode("a", {
                            href: `${__props.brosur}`,
                            target: "_blank",
                            class: "p-2 bg-transparent ring-2 ring-white rounded-lg hover:bg-yellow-700 text-xs sm:text-base"
                          }, [
                            createVNode("span", { class: "flex items-center justify-center" }, [
                              createVNode("i", { class: "fa-solid fa-image pr-2" }),
                              createTextVNode(" Brosur ")
                            ])
                          ], 8, ["href"]),
                          createVNode("a", {
                            href: `${__props.rincian_biaya}`,
                            target: "_blank",
                            class: "p-2 bg-transparent ring-2 ring-white rounded-lg hover:bg-yellow-700 text-xs sm:text-base"
                          }, [
                            createVNode("span", { class: "flex items-center justify-center" }, [
                              createVNode("i", { class: "fa-solid fa-money-bill pr-2" }),
                              createTextVNode(" Rincian ")
                            ])
                          ], 8, ["href"])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Welcome.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
