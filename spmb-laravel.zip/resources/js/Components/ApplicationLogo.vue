<template>
    <img src="/assets/img/logo-polsa.png" :alt="`Logo ${$page.props.web_settings.institution_name}`" />
</template>
