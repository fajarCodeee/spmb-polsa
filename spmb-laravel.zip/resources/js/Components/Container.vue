<template>
    <div
        class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6 w-full flex flex-col gap-4"
    >
        <slot />
    </div>
</template>
