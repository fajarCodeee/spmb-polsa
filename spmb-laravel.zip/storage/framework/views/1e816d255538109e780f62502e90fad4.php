<?php echo e($slot); ?>

<?php /**PATH D:\projek_laravel\spmb-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>